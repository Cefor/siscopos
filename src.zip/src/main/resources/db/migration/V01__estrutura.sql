CREATE TABLE estado (
    codigo BIGINT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    sigla VARCHAR(2) NOT NULL
);


CREATE TABLE cidade (
    codigo BIGINT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    codigo_estado BIGINT NOT NULL,
    FOREIGN KEY (codigo_estado) REFERENCES estado(codigo)
);

ALTER TABLE cidade ADD INDEX(nome);


CREATE TABLE pessoa (
    codigo BIGINT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(80) NOT NULL,
    sexo VARCHAR(1) NOT NULL,
    data_nascimento DATE NOT NULL,
    nacionalidade VARCHAR(80) NOT NULL DEFAULT 'Brasileira',
    codigo_naturalidade BIGINT,
    nome_pai VARCHAR(80),
    nome_mae VARCHAR(80),
    estado_civil INT,
    escolaridade INT,
    profissao VARCHAR(80),
    cpf VARCHAR(11) NOT NULL,
    tipo_documento INT,
    numero_documento VARCHAR(40),
    orgao_expedidor VARCHAR(20),
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(250),
    url_lattes VARCHAR(100),
    logradouro VARCHAR(50),
    numero VARCHAR(15),
    complemento VARCHAR(100),
    cep VARCHAR(15),
    codigo_cidade BIGINT,
    completo BIT(1) NOT NULL DEFAULT FALSE,
    FOREIGN KEY (codigo_cidade) REFERENCES cidade(codigo),
    FOREIGN KEY (codigo_naturalidade) REFERENCES cidade(codigo)
);


# Aplicar depois quando não tivermos mais CPFs em branco
ALTER TABLE pessoa ADD UNIQUE INDEX(cpf);	
ALTER TABLE pessoa ADD INDEX(nome);	
	

CREATE TABLE usuario (
    codigo BIGINT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    senha VARCHAR(120) NOT NULL,
    ativo BOOLEAN DEFAULT true NOT NULL,
    codigo_pessoa BIGINT NOT NULL,
    FOREIGN KEY (codigo_pessoa) REFERENCES pessoa(codigo)
);

CREATE TABLE grupo (
    codigo BIGINT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

CREATE TABLE permissao (
    codigo BIGINT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

CREATE TABLE usuario_grupo (
    codigo_usuario BIGINT NOT NULL,
    codigo_grupo BIGINT NOT NULL,
    PRIMARY KEY (codigo_usuario, codigo_grupo),
    FOREIGN KEY (codigo_usuario) REFERENCES usuario(codigo),
    FOREIGN KEY (codigo_grupo) REFERENCES grupo(codigo)
);

CREATE TABLE grupo_permissao (
    codigo_grupo BIGINT NOT NULL,
    codigo_permissao BIGINT NOT NULL,
    PRIMARY KEY (codigo_grupo, codigo_permissao),
    FOREIGN KEY (codigo_grupo) REFERENCES grupo(codigo),
    FOREIGN KEY (codigo_permissao) REFERENCES permissao(codigo)
);


CREATE TABLE semestre (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                ano VARCHAR(4) NOT NULL,
                semestre VARCHAR(1) NOT NULL,
                periodo VARCHAR(6) NOT NULL,
                flag_matricula VARCHAR(1) DEFAULT 'N' NOT NULL
);

ALTER TABLE semestre ADD UNIQUE INDEX (ano, semestre);
ALTER TABLE semestre ADD UNIQUE INDEX (periodo);


CREATE TABLE graucurso (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                grau INTEGER NOT NULL,
                nivel INTEGER NOT NULL,
                descricao VARCHAR(20) NOT NULL,
                titulacao VARCHAR(20) NOT NULL,
                titulacao_fem VARCHAR(20) NOT NULL,
                documento VARCHAR(20) NOT NULL
);


CREATE TABLE curso (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                sigla VARCHAR(10) NOT NULL,
                nome VARCHAR(100) NOT NULL,
                codigo VARCHAR(50) NOT NULL,
                area VARCHAR(255) NOT NULL,
                id_grau_curso BIGINT NOT NULL,
                nota_minima FLOAT NOT NULL,
                frequencia_minima FLOAT NOT NULL,
                limite_optativas_especial INTEGER NOT NULL DEFAULT 0,
                limite_optativas_especial_semestre INTEGER NOT NULL DEFAULT 0,
                carga_horaria INTEGER NOT NULL DEFAULT 0,
                prazo_conclusao INTEGER NOT NULL,
                data_inicio DATE NOT NULL,
                data_fim DATE,
                normativo VARCHAR(255) NOT NULL,
                FOREIGN KEY (id_grau_curso) REFERENCES graucurso(id)
);

ALTER TABLE curso ADD INDEX(nome);


CREATE TABLE situacaoprofessor (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                situacao VARCHAR(30) NOT NULL
);


CREATE TABLE linhapesquisa (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                apelido VARCHAR(10) NOT NULL,
                nome VARCHAR(100) NOT NULL,
                descricao VARCHAR(255) NOT NULL
);


CREATE TABLE disciplina (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                tipo VARCHAR(4) NOT NULL,
                sigla VARCHAR(10) NOT NULL,
                nome VARCHAR(100) NOT NULL,
                horas INTEGER NOT NULL,
                id_grau_curso BIGINT NOT NULL,
                FOREIGN KEY (id_grau_curso) REFERENCES graucurso(id)
);

ALTER TABLE disciplina ADD UNIQUE INDEX (id_grau_curso, sigla, horas);
ALTER TABLE disciplina ADD UNIQUE INDEX (id_grau_curso, nome, horas);
ALTER TABLE disciplina ADD INDEX(nome);


CREATE TABLE curso_linhapesquisa (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_curso BIGINT NOT NULL,
                id_linhapesquisa BIGINT NOT NULL,
                FOREIGN KEY (id_curso) REFERENCES curso(id),
                FOREIGN KEY (id_linhapesquisa) REFERENCES linhapesquisa(id)
);

ALTER TABLE curso_linhapesquisa ADD UNIQUE INDEX (id_curso, id_linhapesquisa);


CREATE TABLE curso_disciplina (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_curso BIGINT NOT NULL,
                id_disciplina BIGINT NOT NULL,
                flag_obrigatoria VARCHAR(1) DEFAULT 'N' NOT NULL,
                id_curso_linhapesquisa BIGINT,
                flag_ativa VARCHAR(1) DEFAULT 'N' NOT NULL,
                flag_subtitulo VARCHAR(1) DEFAULT 'N' NOT NULL,
                FOREIGN KEY (id_curso) REFERENCES curso(id),
                FOREIGN KEY (id_disciplina) REFERENCES disciplina(id),
                FOREIGN KEY (id_curso_linhapesquisa) REFERENCES curso_linhapesquisa(id)
);

ALTER TABLE curso_disciplina ADD UNIQUE INDEX (id_curso, id_disciplina);



CREATE TABLE professor (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_curso BIGINT NOT NULL,
                id_pessoa BIGINT NOT NULL,
                FOREIGN KEY (id_pessoa) REFERENCES pessoa(codigo),
                FOREIGN KEY (id_curso) REFERENCES curso(id)
);

ALTER TABLE professor ADD UNIQUE INDEX (id_curso, id_pessoa);


CREATE TABLE professor_situacao (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_professor BIGINT NOT NULL,
                id_situacaoprofessor BIGINT NOT NULL,
                id_curso_linhapesquisa BIGINT NOT NULL,
                data_inicio DATE NOT NULL,
                data_fim DATE,
                observacao VARCHAR(255),
                FOREIGN KEY (id_professor) REFERENCES professor(id),
                FOREIGN KEY (id_situacaoprofessor) REFERENCES situacaoprofessor(id),
                FOREIGN KEY (id_curso_linhapesquisa) REFERENCES curso_linhapesquisa(id)
);



CREATE TABLE aluno (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_curso BIGINT NOT NULL,
                id_pessoa BIGINT NOT NULL,
                FOREIGN KEY (id_curso) REFERENCES curso(id),
                FOREIGN KEY (id_pessoa) REFERENCES pessoa(codigo)
);

ALTER TABLE aluno ADD UNIQUE INDEX (id_curso, id_pessoa);


CREATE TABLE instituicaoparceira (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
				sigla VARCHAR(20) NOT NULL,
                nome VARCHAR(100) NOT NULL,
                cnpj VARCHAR(14) NOT NULL,
                data_vigencia DATE NOT NULL
);

ALTER TABLE instituicaoparceira ADD UNIQUE INDEX (cnpj);


CREATE TABLE vinculocd (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                sigla VARCHAR(10) NOT NULL,
                categoria VARCHAR(30) NOT NULL
);


CREATE TABLE pessoa_vinculo (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_pessoa BIGINT NOT NULL,
                id_instituicaoparceira BIGINT,
                id_vinculocd BIGINT,
                pontoCD VARCHAR(20),
                data_inicio DATE NOT NULL,
                data_fim DATE,
                observacao VARCHAR(255),
                FOREIGN KEY (id_pessoa) REFERENCES pessoa(codigo),
                FOREIGN KEY (id_instituicaoparceira) REFERENCES instituicaoparceira(id),
                FOREIGN KEY (id_vinculocd) REFERENCES vinculocd(id)
);

ALTER TABLE pessoa_vinculo ADD UNIQUE INDEX (id_pessoa, data_inicio);


CREATE TABLE alunoreg (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_aluno BIGINT NOT NULL,
                matricula VARCHAR(20) NOT NULL,
                id_semestre_ingresso BIGINT NOT NULL,
                data_ingresso DATE NOT NULL,
                id_curso_linhapesquisa BIGINT NOT NULL,
                id_orientador BIGINT,
                id_coorientador BIGINT,
                pagante VARCHAR(1) DEFAULT 'N' NOT NULL,
                prazo_conclusao DATE NOT NULL,
                tituloTCC VARCHAR(255),
                data_homologacao DATE,
                data_expedicaodiploma DATE,
                data_desligamento DATE,
                data_reativacao DATE,
                flag_situacao VARCHAR(1) NOT NULL DEFAULT 'X',
                FOREIGN KEY (id_aluno) REFERENCES aluno(id),
                FOREIGN KEY (id_semestre_ingresso) REFERENCES semestre(id),
                FOREIGN KEY (id_curso_linhapesquisa) REFERENCES curso_linhapesquisa(id),
                FOREIGN KEY (id_orientador) REFERENCES professor(id),
                FOREIGN KEY (id_coorientador) REFERENCES pessoa(codigo)
);

ALTER TABLE alunoreg ADD UNIQUE INDEX (id_aluno);
ALTER TABLE alunoreg ADD UNIQUE INDEX (matricula);


CREATE TABLE tipo_ocorrenciareg (
               id BIGINT PRIMARY KEY AUTO_INCREMENT,
               descricao VARCHAR(50) NOT NULL
);


CREATE TABLE ocorrenciareg (
               id BIGINT PRIMARY KEY AUTO_INCREMENT,
               id_alunoreg BIGINT NOT NULL,
               id_tipoocorrenciareg BIGINT NOT NULL,
               data_ocorrencia DATE NOT NULL,
               descricao VARCHAR(255) NOT NULL,
               FOREIGN KEY (id_alunoreg) REFERENCES alunoreg(id),
               FOREIGN KEY (id_tipoocorrenciareg) REFERENCES tipo_ocorrenciareg(id)
);
ALTER TABLE ocorrenciareg ADD UNIQUE INDEX (id_alunoreg, id_tipoocorrenciareg, data_ocorrencia);
ALTER TABLE ocorrenciareg ADD INDEX(id_tipoocorrenciareg);


CREATE TABLE alunoesp (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_aluno BIGINT NOT NULL,
                matricula VARCHAR(20) NOT NULL,
                id_semestre_ingresso BIGINT NOT NULL,
                data_fimrestricao DATE,
                qtd_disciplinas_cursadas INTEGER NOT NULL DEFAULT '0',
                FOREIGN KEY (id_aluno) REFERENCES aluno(id)
);

ALTER TABLE alunoesp ADD UNIQUE INDEX (id_aluno);
ALTER TABLE alunoesp ADD UNIQUE INDEX (matricula);


CREATE TABLE matricula (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_aluno BIGINT NOT NULL,
                id_alunoreg BIGINT,
                id_alunoesp BIGINT,
                id_semestre BIGINT NOT NULL,
                requerimento BLOB,
                data_matricula DATE NOT NULL,
                data_trancamento DATE,
                id_responsavellancamento BIGINT,
                FOREIGN KEY (id_aluno) REFERENCES aluno(id),
                FOREIGN KEY (id_alunoreg) REFERENCES alunoreg(id),
                FOREIGN KEY (id_alunoesp) REFERENCES alunoesp(id),
                FOREIGN KEY (id_semestre) REFERENCES semestre(id),
                FOREIGN KEY (id_responsavellancamento) REFERENCES pessoa(codigo)
);

ALTER TABLE matricula ADD UNIQUE INDEX (id_aluno, id_semestre);


CREATE TABLE oferta (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_curso_disciplina BIGINT NOT NULL,
                id_semestre BIGINT NOT NULL,
                id_curso_disciplina_subtitulo BIGINT,
                turma VARCHAR(1),
                vagas INT,
                planocurso BLOB,
                data_cancelamento DATE,
                FOREIGN KEY (id_curso_disciplina) REFERENCES curso_disciplina(id),
                FOREIGN KEY (id_semestre) REFERENCES semestre(id),
                FOREIGN KEY (id_curso_disciplina_subtitulo) REFERENCES curso_disciplina(id)
);

ALTER TABLE oferta ADD UNIQUE INDEX (id_curso_disciplina, id_semestre, turma);


CREATE TABLE matricula_disciplina (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_matricula BIGINT NOT NULL,
                id_oferta BIGINT NOT NULL,
                nota FLOAT,
                frequencia FLOAT,
                mencao VARCHAR(2),
                data_mencao DATE,
                data_opcaoac DATE,
                creditos_computados FLOAT NOT NULL DEFAULT 0,
                FOREIGN KEY (id_matricula) REFERENCES matricula(id),
                FOREIGN KEY (id_oferta) REFERENCES oferta(id)
);

ALTER TABLE matricula_disciplina ADD UNIQUE INDEX (id_matricula, id_oferta);


CREATE TABLE oferta_professor (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_oferta BIGINT NOT NULL,
                id_professor BIGINT NOT NULL,
                cargahoraria FLOAT,
                FOREIGN KEY (id_oferta) REFERENCES oferta(id),
                FOREIGN KEY (id_professor) REFERENCES professor(id)
);

ALTER TABLE oferta_professor ADD UNIQUE INDEX (id_oferta, id_professor);


CREATE TABLE pessoa_titulo (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                id_pessoa BIGINT NOT NULL,
                id_graucurso BIGINT NOT NULL,
                data_titulacao DATE NOT NULL,
                descricao VARCHAR(255) NOT NULL,
                FOREIGN KEY (id_pessoa) REFERENCES pessoa(codigo),
                FOREIGN KEY (id_graucurso) REFERENCES graucurso(id)
);

ALTER TABLE pessoa_titulo ADD UNIQUE INDEX (id_pessoa, data_titulacao);


