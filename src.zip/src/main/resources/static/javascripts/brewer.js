var Brewer = Brewer || {};

Brewer.MaskMoney = (function() {
	
	class MaskMoney {
        constructor() {
            this.decimal = $('.js-decimal');
            this.plain = $('.js-plain');
        }
        enable() {
            this.decimal.maskMoney({ decimal: '.', thousands: ',', precision: 1, allowZero: true });
            this.plain.maskMoney({ precision: 0, thousands: ',', allowZero: true });
        }
    }
	
	
	return MaskMoney;
	
}());

Brewer.MaskPhoneNumber = (function() {
	
	class MaskPhoneNumber {
        constructor() {
            this.inputPhoneNumber = $('.js-phone-number');
        }
        enable() {
            var maskBehavior = function(val) {
                return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
            };

            var options = {
                onKeyPress: function(_val, _e, field, options) {
                    field.mask(maskBehavior.apply({}, arguments), options);
                }
            };

            this.inputPhoneNumber.mask(maskBehavior, options);
        }
    }
	
	
	return MaskPhoneNumber;
	
}());


Brewer.MaskCpf = (function() {
    
    class MaskCpf {
        constructor() {
            this.inputCpf = $('.js-cpf');
        }

        enable() {
            this.inputCpf.mask('000.000.000-00');
        }

        validarCPF(cpf) {
            cpf = cpf.replace(/[^\d]+/g, ''); // Remove caracteres não numéricos
            if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) {
                return false; // Verifica se o CPF tem 11 dígitos e se todos os dígitos são iguais
            }

            let soma = 0;
            let resto;

            // Valida o primeiro dígito verificador
            for (let i = 1; i <= 9; i++) {
                soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
            }
            resto = (soma * 10) % 11;
            if ((resto === 10) || (resto === 11)) resto = 0;
            if (resto !== parseInt(cpf.substring(9, 10))) return false;

            soma = 0;
            // Valida o segundo dígito verificador
            for (let i = 1; i <= 10; i++) {
                soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
            }
            resto = (soma * 10) % 11;
            if ((resto === 10) || (resto === 11)) resto = 0;
            if (resto !== parseInt(cpf.substring(10, 11))) return false;

            return true;
        }

        exibirAvisoSeCpfInvalido() {
            const cpf = this.inputCpf.val();
            if (!this.validarCPF(cpf)) {
                alert('O CPF informado é inválido.');
            }
        }
    }
    
    return MaskCpf;

}());


Brewer.MaskCnpj = (function() {
	
	class MaskCnpj {
        constructor() {
            this.inputCnpj = $('.js-cnpj');
        }
        enable() {
            this.inputCnpj.mask('AA.AAA.AAA/AAAA-00');
        }
    }
	
	return MaskCnpj;
	
}());


Brewer.MaskCep = (function() {
	
	class MaskCep {
        constructor() {
            this.inputCep = $('.js-cep');
        }
        enable() {
            this.inputCep.mask('00.000-000');
        }
    }
	
	
	return MaskCep;
	
}());


Brewer.MaskDate = (function() {
	
	class MaskDate {
        constructor() {
            this.inputDate = $('.js-date');
        }
        enable() {
            this.inputDate.mask('00/00/0000');
            this.inputDate.datepicker({
                orientation: 'bottom',
                language: 'pt-BR',
                autoclose: true
            }).on('hide.bs.modal', function(event) {
                event.stopPropagation();
            }); // https://github.com/uxsolutions/bootstrap-datepicker/issues/978
        }
    }
	
	
	return MaskDate;
	
}());


Brewer.Security = (function() {
	
	class Security {
        constructor() {
            this.token = $('input[name=_csrf]').val();
            this.header = $('input[name=_csrf_header]').val();
        }
        enable() {
            $(document).ajaxSend(function(_event, jqxhr, _settings) {
                jqxhr.setRequestHeader(this.header, this.token);
            }.bind(this));
        }
    }
	
	
	return Security;
	
}());


numeral.language('pt-br');


Brewer.formatarMoeda = function(valor) {
	return numeral(valor).format('0,0.00');
}


Brewer.recuperarValor = function(valorFormatado) {
	return numeral().unformat(valorFormatado);
}


$(function() {
	var maskMoney = new Brewer.MaskMoney();
	maskMoney.enable();
	
	var maskPhoneNumber = new Brewer.MaskPhoneNumber();
	maskPhoneNumber.enable();
	
	var maskCpf = new Brewer.MaskCpf();
	maskCpf.enable();
	// Adiciona o evento blur (perda de foco) para validar o CPF
    $('.js-cpf').on('blur', function() {
        maskCpf.exibirAvisoSeCpfInvalido();
    });
	
	var maskCnpj = new Brewer.MaskCnpj();
	maskCnpj.enable();
	
	var maskCep = new Brewer.MaskCep();
	maskCep.enable();
	
	var maskDate = new Brewer.MaskDate();
	maskDate.enable();
	
	var security = new Brewer.Security();
	security.enable();
	
});
