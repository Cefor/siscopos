var Brewer = Brewer || {};

Brewer.DialogoExcluir = (function () {

    function DialogoExcluir() {
        this.exclusaoBtn = $('.js-exclusao-btn');
    }

    DialogoExcluir.prototype.iniciar = function () {
        this.exclusaoBtn.on('click', this.onExcluirClicado.bind(this));

        if (window.location.search.includes('excluido')) {
            swal('Pronto!', 'Excluído com sucesso!', 'success');
        }
    };

    DialogoExcluir.prototype.onExcluirClicado = function (evento) {
        evento.preventDefault();
        var botaoClicado = $(evento.currentTarget);
        var url = botaoClicado.data('url');
        var objeto = botaoClicado.data('objeto');

        swal({
            title: 'Tem certeza?',
            text: 'Excluir "' + objeto + '"? Você não poderá recuperar depois.',
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Sim, exclua agora!',
            closeOnConfirm: false
        }, this.onExcluirConfirmado.bind(this, url));
    };

    DialogoExcluir.prototype.onExcluirConfirmado = function (url) {
        $.ajax({
            url: url,
            method: 'DELETE',
            success: this.onExcluidoSucesso.bind(this),
            error: this.onErroExcluir.bind(this)
        });
    };

    DialogoExcluir.prototype.onExcluidoSucesso = function () {
        var urlAtual = window.location.href;
        var separador = urlAtual.includes('?') ? '&' : '?';
        var novaUrl = urlAtual.includes('excluido') ? urlAtual : urlAtual + separador + 'excluido';

        window.location = novaUrl;
    };

    DialogoExcluir.prototype.onErroExcluir = function (e) {
        try {
            var errorResponse = JSON.parse(e.responseText);
            var errorMessage = errorResponse.error || errorResponse.message || 'Erro desconhecido';

            if (errorResponse.error === 'Method Not Allowed') {
                swal('Oops!', 'Você não tem permissão para excluir!', 'error');
            } else {
                swal('Oops!', errorMessage, 'error');
            }

        } catch (error) {
            swal('Oops!', e.responseText, 'error');
        }
    };

    return DialogoExcluir;

}());

$(function () {
    var dialogo = new Brewer.DialogoExcluir();
    dialogo.iniciar();
});
