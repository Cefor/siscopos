document.addEventListener('DOMContentLoaded', (event) => {
    $('#pesquisaArquivos').on('show.bs.modal', function (e) {
        var triggerElement = $(e.relatedTarget);
        var folderPath = triggerElement.data('folder-path'); // Caminho inicial acessado
        var folderOrigem = triggerElement.data('folder-origem');

        var fileList = $('#fileList');
        fileList.empty();

        // Armazena o nível inicial e o nível base
        var initialFolderPath = folderPath;
        // Nível imediatamente acima do inicial, que será o limite
        var baseFolderPath = initialFolderPath.substring(0, initialFolderPath.lastIndexOf('\\'));

        var displayFolderPath = folderOrigem.replace(/\\\\/g, '\\');
        $('#folderPathDisplay').text(displayFolderPath);

        var basePath = window.location.pathname.substring(0, window.location.pathname.indexOf("/", 2));

        function loadFiles(path) {
            $.ajax({
                url: basePath + '/files/list',
                method: 'GET',
                data: { folder: path },
                success: function (files) {
                    folderPath = path; // Atualiza o folderPath com o novo caminho
                    if (files.length === 0) {
                        fileList.append('<li>Nenhum arquivo encontrado nesta pasta.</li>');
                    } else {
                        fileList.empty();
                        files.forEach(function (file) {
                            var li = $('<li/>');
                            var a = $('<a/>', {
                                text: file,
                                href: '#',
                                click: function(e) {
                                    e.preventDefault();
                                    var newPath = path + '\\' + file;
                                    checkIfDirectory(newPath, file);
                                }
                            });
                            li.append(a);
                            fileList.append(li);
                        });
                    }
                    $('#folderPathDisplay').text(path.replace(/\\\\/g, '\\'));
                },
                error: function () {
                    fileList.append('<li>Erro ao carregar a lista de arquivos ou pasta não encontrada.</li>');
                }
            });
        }

        function checkIfDirectory(path, fileName) {
            $.ajax({
                url: basePath + '/files/check',
                method: 'GET',
                data: { folder: path },
                success: function (isDirectory) {
                    if (isDirectory) {
                        loadFiles(path);
                    } else {
                        window.location.href = basePath + '/files/download?folder=' + encodeURIComponent(path.replace('\\' + fileName, '')) + '&filename=' + encodeURIComponent(fileName);
                    }
                },
                error: function () {
                    alert('Erro ao verificar se é uma pasta.');
                }
            });
        }

        // Função para subir um nível na pasta, com restrição de nível máximo
        function goUpOneLevel() {
            if (folderPath !== baseFolderPath) {  // Permite subir até o nível base
                var newPath = folderPath.substring(0, folderPath.lastIndexOf('\\'));
                // Verifica se o novo caminho é maior ou igual ao nível base
                if (newPath.length >= baseFolderPath.length) {
                    loadFiles(newPath);
                } else {
                    alert('Você já está no nível mais alto permitido.');
                }
            } else {
                alert('Você já está no nível mais alto permitido.');
            }
        }

        // Adiciona o evento para o botão "Subir um nível"
        $('#upOneLevel').off('click').on('click', function() {
            goUpOneLevel();
        });

        loadFiles(folderPath);
    });
});


