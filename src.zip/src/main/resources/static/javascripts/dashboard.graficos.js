var Copos = Copos || {};

Copos.Grafico = (function() {
    function Grafico(selector) {
        this.ctx = $(selector)[0].getContext('2d');
    }

    Grafico.prototype.iniciar = function() {
        var canvas = this.ctx.canvas;
        var atributos = canvas.getAttribute('atributos');

        try {
            const jsonArray = JSON.parse(atributos);

            // Certifique-se de que jsonArray tem o formato esperado
            if (Array.isArray(jsonArray) && jsonArray.length === 8) {
                // Acesse os elementos do array
                const tipoGrafico = jsonArray[0];
                const labelsX = jsonArray[1].split(',');
                const titulo1 = jsonArray[2];
                const dados1 = jsonArray[3].split(',');
                const corFundo1 = jsonArray[4];
                const titulo2 = jsonArray[5];
                const dados2 = jsonArray[6].split(',');
                const corFundo2 = jsonArray[7];

                // Função para criar um objeto de conjunto de dados
                function criarDataset(label, corFundo, dados) {
                    var dataset = {
                        label: label,
                        borderWidth: 2,
                        data: dados
                    };

                    // Adicione backgroundColor se corFundo estiver definido
                    if (corFundo !== "undefined") {
                        dataset.backgroundColor = corFundo;
                    }

                    return dataset;
                }

                // Crie os conjuntos de dados dinamicamente
                var datasets = [
                    criarDataset(titulo1, corFundo1, dados1),
                    criarDataset(titulo2, corFundo2, dados2)
                ];

                var grafico = new Chart(this.ctx, {
                    type: tipoGrafico,
                    data: {
                        labels: labelsX,
                        datasets: datasets
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            } else {
                console.error('O formato do JSON não é o esperado.');
            }
        } catch (error) {
            console.error('Erro ao fazer parse do JSON:', error);
        }
    };

    return Grafico;
}());

$(function() {
    var graficoAlunoRegular = new Copos.Grafico('#graficoAlunoRegular');
    graficoAlunoRegular.iniciar();
    
    var graficoAlunoEspecial = new Copos.Grafico('#graficoAlunoEspecial');
    graficoAlunoEspecial.iniciar();
});

