package br.leg.camara.copos.service;

import br.leg.camara.copos.model.bridge.AlunoRegMatricula;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;

public interface MatriculaAlunoRegService {
	
	public void salvar(AlunoRegMatricula alunoRegMatricula);

	void excluir(MatriculaDisciplina matriculaDisciplina);

	void salvarDataTrancamento(Matricula matricula);

}
