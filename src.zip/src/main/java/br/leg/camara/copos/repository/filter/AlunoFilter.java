package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.Curso;

public class AlunoFilter {

	private Curso curso;
	private String nome;
	private String cpf;
	
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
}
