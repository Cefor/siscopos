package br.leg.camara.copos.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.Matriculas;
import br.leg.camara.copos.repository.MatriculasDisciplinas;
import br.leg.camara.copos.service.DashboardService;
import br.leg.camara.copos.service.grafico.GraficoAtributos;

@Service
public class DashboardServiceImpl implements DashboardService{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private AlunosReg alunosReg;

	@Autowired
	private MatriculasDisciplinas matriculasDisciplinas;
	
	@Autowired
	private Matriculas matriculas;

	
	@Transactional(readOnly = true)
	@Override
	public int regularesAtivos(Curso curso) {
		return alunosReg.findByAlunoCursoAndSituacaoAlunoReg(curso, SituacaoAlunoReg.A).size();
	}

	
	@Transactional(readOnly = true)
	@Override
	public int regularesEgressos(Curso curso) {
		return alunosReg.findByAlunoCursoAndSituacaoAlunoReg(curso, SituacaoAlunoReg.E).size();
	}
	
	
	@Transactional(readOnly = true)
	@Override
	public int regularesDesligados(Curso curso) {
		return alunosReg.findByAlunoCursoAndDataHomologacaoIsNullAndDataDesligamentoIsNotNullAndDataReativacaoIsNull(curso).size();
	}	
	
	
	@Transactional(readOnly = true)
	@Override
	public String regularesAtivosPrazoEncerrado(Curso curso) {
		List<AlunoReg> lista = alunosReg.findByAlunoCursoAndSituacaoAlunoRegAndPrazoConclusaoLessThan(curso, SituacaoAlunoReg.A, LocalDate.now());
		
	    List<String> nomes = new ArrayList<>();
	    for (AlunoReg alunoReg : lista) {
	        nomes.add((String) alunoReg.getAluno().getPessoa().getNome() + " (" + alunoReg.getMatricula() + ")");
	    }

	    if(!nomes.isEmpty()) {
	    	return nomes.stream().sorted().collect(Collectors.joining("\n")); 
	    } else {
	    	return "";	
	    }
	}	

	
	@Transactional(readOnly = true)
	@Override
	public int regularesTotal(Curso curso) {
		return alunosReg.findByAlunoCurso(curso).size();
	}
	

	@Transactional(readOnly = true)
	@Override
	public String regularesAtivosQualificados(Curso curso) {
		List<MatriculaDisciplina> lista1 = matriculasDisciplinas.findByMatriculaAlunoCursoAndMatriculaAlunoRegIsNotNullAndMatriculaAlunoRegSituacaoAlunoRegAndOfertaCursoDisciplinaDisciplinaSiglaAndMencao(curso, SituacaoAlunoReg.A, "EQUALI", "AP");
		List<MatriculaDisciplina> lista2 = matriculasDisciplinas.findByMatriculaAlunoCursoAndMatriculaAlunoRegIsNotNullAndMatriculaAlunoRegSituacaoAlunoRegAndOfertaCursoDisciplinaDisciplinaSiglaAndMencao(curso, SituacaoAlunoReg.A, "DEFESA", "AP");

		// retira da lista1 os alunos da lista2 
		Iterator<MatriculaDisciplina> iterador1 = lista1.iterator();
		while (iterador1.hasNext()) {
			MatriculaDisciplina matriculaDisciplina1 = iterador1.next();

			Iterator<MatriculaDisciplina> iterador2 = lista2.iterator();
		    while (iterador2.hasNext()) {
		    	MatriculaDisciplina matriculaDisciplina2 = iterador2.next();

		        if (matriculaDisciplina1.getMatricula().getAluno().getId() == matriculaDisciplina2.getMatricula().getAluno().getId()) {
		            iterador1.remove();
		            break;
		        }
		    }
		}
		
		List<String> nomes = new ArrayList<>();
	    for (MatriculaDisciplina matriculaDisciplina : lista1) {
	        nomes.add((String) 
	        		matriculaDisciplina.getMatricula().getAluno().getPessoa().getNome() + " (" + matriculaDisciplina.getMatricula().getAlunoReg().getMatricula() + ")");
	    }

	    if(!nomes.isEmpty()) {
	    	return nomes.stream().sorted().collect(Collectors.joining("\n")); 
	    } else {
	    	return "";	
	    }
		
	}
	

	@Transactional(readOnly = true)
	@Override
	public String regularesEmHomologacao(Curso curso) {
		List<MatriculaDisciplina> lista = matriculasDisciplinas.findByMatriculaAlunoCursoAndMatriculaAlunoRegIsNotNullAndOfertaCursoDisciplinaDisciplinaSiglaAndMencaoAndMatriculaAlunoRegDataHomologacaoIsNull(curso, "DEFESA", "AP");
		
	    List<String> nomes = new ArrayList<>();
	    for (MatriculaDisciplina matriculaDisciplina : lista) {
	        nomes.add((String) 
	        		matriculaDisciplina.getMatricula().getAluno().getPessoa().getNome() + " (" + matriculaDisciplina.getMatricula().getAlunoReg().getMatricula() + ")");
	    }

	    if(!nomes.isEmpty()) {
	    	return nomes.stream().sorted().collect(Collectors.joining("\n")); 
	    } else {
	    	return "";	
	    }
	}

	
	
	@Transactional(readOnly = true)
	@Override
	public String regularesTrancados(Curso curso) {
		List<Matricula> lista = matriculas.findByAlunoCursoAndAlunoRegSituacaoAlunoRegOrderByAlunoRegAscSemestrePeriodoDesc(curso, SituacaoAlunoReg.A);
		
		Long id = -1L; 
		
		Iterator<Matricula> iterator = lista.iterator();
		while (iterator.hasNext()) {
			Matricula matricula = iterator.next();
			
			if(matricula.getAlunoReg().getId() != id) {
				id = matricula.getAlunoReg().getId();
				
				if(matricula.getDataTrancamento() == null) {
					iterator.remove();
				}

			} else {
				iterator.remove();
			}
		}
				
	    List<String> nomes = new ArrayList<>();
	    for (Matricula matricula : lista) {
	        nomes.add((String) matricula.getAluno().getPessoa().getNome() + " (" + matricula.getAlunoReg().getMatricula() + ")");
	    }

	    if(!nomes.isEmpty()) {
	    	return nomes.stream().sorted().collect(Collectors.joining("\n")); 
	    } else {
	    	return "";	
	    }
	}
	
	
	@Transactional(readOnly = true)
	@Override
	public String graficoRegulares(Curso curso) {

		List<Object[]> lista1 = contarAlunosPorSemestre(curso, "Reg");
		List<String> qtdAlunos = criarStrings(lista1);
		
		List<Object[]> lista2 = contarMatriculasDisciplinasPorSemestre(curso, "Reg");
		List<String> qtdMatriculasDisciplinas = criarStrings(lista2);
		
		GraficoAtributos graficoAtributos = new GraficoAtributos();
		graficoAtributos.setTipoGrafico("line");
		graficoAtributos.setLabels_x(qtdAlunos.get(0));
		graficoAtributos.setTitulo1("Alunos matriculados");
		graficoAtributos.setDados1(qtdAlunos.get(1));
		graficoAtributos.setCorFundo1("undefined");
		graficoAtributos.setTitulo2("Matrículas em disciplinas");
		graficoAtributos.setDados2(qtdMatriculasDisciplinas.get(1));
		graficoAtributos.setCorFundo2("undefined");
		
		return graficoAtributos.toJSON();
	}

	
	@Transactional(readOnly = true)
	@Override
	public String graficoEspeciais(Curso curso) {

		List<Object[]> lista1 = contarAlunosPorSemestre(curso, "Esp");
		List<String> qtdAlunos = criarStrings(lista1);
		
		List<Object[]> lista2 = contarMatriculasDisciplinasPorSemestre(curso, "Esp");
		List<String> qtdMatriculasDisciplinas = criarStrings(lista2);
		
		GraficoAtributos graficoAtributos = new GraficoAtributos();
		graficoAtributos.setTipoGrafico("line");
		graficoAtributos.setLabels_x(qtdAlunos.get(0));
		graficoAtributos.setTitulo1("Alunos matriculados");
		graficoAtributos.setDados1(qtdAlunos.get(1));
		graficoAtributos.setCorFundo1("rgba(0,100,148,0.5)");
		graficoAtributos.setTitulo2("Matrículas em disciplinas");
		graficoAtributos.setDados2(qtdMatriculasDisciplinas.get(1));
		graficoAtributos.setCorFundo2("rgba(26,179,148,0.5)");
		
		return graficoAtributos.toJSON();

	}
	
	
	
	
	public List<Object[]> contarAlunosPorSemestre(Curso curso, String tipoAluno) {
	    CriteriaBuilder builder = entityManager.getCriteriaBuilder();
	    CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
	    Root<Matricula> root = query.from(Matricula.class);

	    Path<String> semestrePeriodoPath = root.get("semestre").get("periodo");
	    Path<Aluno> alunoPath = root.get("aluno");

	    query.multiselect(semestrePeriodoPath.alias("semestre"), builder.count(root).alias("quantidadeAlunos"));
	    query.groupBy(root.get("semestre"));

	    Predicate predicate = tipoAluno.equals("Reg")
	            ? builder.and(
	                    builder.isNotNull(root.get("alunoReg").get("id")),
	                    builder.equal(alunoPath.get("curso"), curso)
	                )
	            : builder.and(
	                    builder.isNotNull(root.get("alunoEsp").get("id")),
	                    builder.equal(alunoPath.get("curso"), curso)
	                );

	    query.where(predicate);

	    Order orderBySemestreAsc = builder.asc(semestrePeriodoPath);
	    query.orderBy(orderBySemestreAsc);

	    TypedQuery<Object[]> typedQuery = entityManager.createQuery(query);
	    return typedQuery.getResultList();
	}
    
    
    public List<Object[]> contarMatriculasDisciplinasPorSemestre(Curso curso, String tipoAluno) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
        Root<MatriculaDisciplina> root = query.from(MatriculaDisciplina.class);

        Path<String> semestrePeriodoPath = root.get("oferta").get("semestre").get("periodo");
        Path<Aluno> alunoPath = root.get("matricula").get("aluno");

        query.multiselect(semestrePeriodoPath.alias("semestre"), builder.count(root).alias("quantidadeAlunos"));
        query.groupBy(semestrePeriodoPath);

        Predicate predicate = tipoAluno.equals("Reg")
                ? builder.and(
                        builder.isNotNull(root.get("matricula").get("alunoReg").get("id")),
                        builder.equal(alunoPath.get("curso"), curso)
                    )
                : builder.and(
                        builder.isNotNull(root.get("matricula").get("alunoEsp").get("id")),
                        builder.equal(alunoPath.get("curso"), curso)
                    );
        
        query.where(predicate);
        
        Order orderBySemestreAsc = builder.asc(semestrePeriodoPath);
        query.orderBy(orderBySemestreAsc);

        TypedQuery<Object[]> typedQuery = entityManager.createQuery(query);
        return typedQuery.getResultList();
    }
    
    
    
    public List<String> criarStrings(List<Object[]> mapa) {
        StringBuilder nomesSemestres = new StringBuilder();
        StringBuilder valores = new StringBuilder();

        for (Object[] resultado : mapa) {
            String nomeSemestre = (String) resultado[0]; // Assumindo que o nome do semestre está na primeira posição do array
            Long quantidadeAlunos = (Long) resultado[1]; // Assumindo que a quantidade de alunos está na segunda posição do array

            // Concatenar os nomes dos semestres
            nomesSemestres.append(nomeSemestre).append(",");

            // Concatenar os valores
            valores.append(quantidadeAlunos).append(",");
        }

        // Remover a vírgula extra no final das strings, se houver
        if (nomesSemestres.length() > 0) {
            nomesSemestres.deleteCharAt(nomesSemestres.length() - 1);
        }
        if (valores.length() > 0) {
            valores.deleteCharAt(valores.length() - 1);
        }

        // Imprimir ou utilizar as strings conforme necessário
        /*
        System.out.println("Nomes dos semestres: " + nomesSemestres.toString());
        System.out.println("Valores: " + valores.toString());
        System.out.println("Valeu");
        */
        return Arrays.asList(nomesSemestres.toString(), valores.toString());
    }
	
	
	
	
}
