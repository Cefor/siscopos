package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;

@Entity
@Table(name = "alunoreg")
public class AlunoReg{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_aluno")
	private Aluno aluno;
	
	@Column(name = "matricula", length = 20)
	@NotBlank(message = "Matrícula obrigatória")
	private String matricula;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_semestre_ingresso")
	private SemestrePeriodo semestre;
	
	@NotNull(message = "Data de ingresso obrigatória")
	@Column(name = "data_ingresso")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataIngresso;
	
	@NotNull(message = "Linha é obrigatória")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_curso_linhapesquisa")
	private CursoLinhaPesquisa cursoLinhaPesquisa;
	
	@OneToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_orientador")
	private Professor orientador;
	
	@OneToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_coorientador")
	private Pessoa coorientador;
	
	@NotNull(message = "Informação de pagante obrigatória")
	@Column(name = "pagante", length = 1)
	@Enumerated(EnumType.STRING)
	private SimNao pagante;	
	
	//@NotNull(message = "Prazo de conclusão obrigatório")
	@Column(name = "prazo_conclusao")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate prazoConclusao;
	
	@Column(name = "tituloTCC", length = 255)
	private String tituloTCC;
	
	@Column(name = "data_homologacao")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataHomologacao;
	
	@Column(name = "data_expedicaodiploma")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataExpedicaoDiploma;

	@Column(name = "data_desligamento")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataDesligamento;
	
	@Column(name = "data_reativacao")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataReativacao;
	
	@Column(name = "flag_situacao", length = 1)
	@Enumerated(EnumType.STRING)
	private SituacaoAlunoReg situacaoAlunoReg;
	
	@PrePersist @PreUpdate
	private void prePersistPreUpdate() {
		// aluno regular ativo
		if(    (this.dataHomologacao == null &&
				this.dataDesligamento == null &&
				this.dataReativacao == null) 
				||
			   (this.dataHomologacao == null &&
				this.dataDesligamento != null &&
				this.dataReativacao != null)	)  {
			
			this.situacaoAlunoReg = SituacaoAlunoReg.A;
			
		} else if( // aluno egresso
				this.dataHomologacao != null ) {
				
				this.situacaoAlunoReg = SituacaoAlunoReg.E;			
				
		} else if( // aluno desligado
				
			   (this.dataDesligamento != null &&
				this.dataReativacao == null && 
				this.dataHomologacao == null)
				) {
			
			this.situacaoAlunoReg = SituacaoAlunoReg.D;			
			
		} else { // situacao desconhecida
				
			this.situacaoAlunoReg = SituacaoAlunoReg.X;
		}
				
	}
	
	public AlunoReg() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AlunoReg(Aluno aluno, String matricula, SemestrePeriodo semestre, LocalDate dataIngresso,
			CursoLinhaPesquisa cursoLinhaPesquisa, Professor orientador, Pessoa coorientador, SimNao pagante,
			LocalDate prazoConclusao, String tituloTCC, LocalDate dataHomologacao, LocalDate dataExpedicaoDiploma, 
			LocalDate dataDesligamento, LocalDate dataReativacao) {
		super();
		this.aluno = aluno;
		this.matricula = matricula;
		this.semestre = semestre;
		this.dataIngresso = dataIngresso;
		this.cursoLinhaPesquisa = cursoLinhaPesquisa;
		this.orientador = orientador;
		this.coorientador = coorientador;
		this.pagante = pagante;
		this.prazoConclusao = prazoConclusao;
		this.tituloTCC = tituloTCC;
		this.dataHomologacao = dataHomologacao;
		this.dataExpedicaoDiploma = dataExpedicaoDiploma;
		this.dataDesligamento = dataDesligamento;
		this.dataReativacao = dataReativacao;
	}

	public boolean isAlunoNovo() {
		return aluno == null;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public SemestrePeriodo getSemestre() {
		return semestre;
	}

	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}

	public LocalDate getDataIngresso() {
		return dataIngresso;
	}

	public void setDataIngresso(LocalDate dataIngresso) {
		this.dataIngresso = dataIngresso;
	}

	public CursoLinhaPesquisa getCursoLinhaPesquisa() {
		return cursoLinhaPesquisa;
	}

	public void setCursoLinhaPesquisa(CursoLinhaPesquisa cursoLinhaPesquisa) {
		this.cursoLinhaPesquisa = cursoLinhaPesquisa;
	}

	public Professor getOrientador() {
		return orientador;
	}

	public void setOrientador(Professor orientador) {
		this.orientador = orientador;
	}

	public Pessoa getCoorientador() {
		return coorientador;
	}

	public void setCoorientador(Pessoa coorientador) {
		this.coorientador = coorientador;
	}

	public SimNao getPagante() {
		return pagante;
	}

	public void setPagante(SimNao pagante) {
		this.pagante = pagante;
	}

	public LocalDate getPrazoConclusao() {
		return prazoConclusao;
	}

	public void setPrazoConclusao(LocalDate prazoConclusao) {
		this.prazoConclusao = prazoConclusao;
	}

	public String getTituloTCC() {
		return tituloTCC;
	}

	public void setTituloTCC(String tituloTCC) {
		this.tituloTCC = tituloTCC;
	}

	public LocalDate getDataHomologacao() {
		return dataHomologacao;
	}

	public void setDataHomologacao(LocalDate dataHomologacao) {
		this.dataHomologacao = dataHomologacao;
	}

	public LocalDate getDataExpedicaoDiploma() {
		return dataExpedicaoDiploma;
	}

	public void setDataExpedicaoDiploma(LocalDate dataExpedicaoDiploma) {
		this.dataExpedicaoDiploma = dataExpedicaoDiploma;
	}

	public LocalDate getDataDesligamento() {
		return dataDesligamento;
	}

	public void setDataDesligamento(LocalDate dataDesligamento) {
		this.dataDesligamento = dataDesligamento;
	}

	public LocalDate getDataReativacao() {
		return dataReativacao;
	}

	public void setDataReativacao(LocalDate dataReativacao) {
		this.dataReativacao = dataReativacao;
	}

	public SituacaoAlunoReg getSituacaoAlunoReg() {
		return situacaoAlunoReg;
	}

	public void setSituacaoAlunoReg(SituacaoAlunoReg situacaoAlunoReg) {
		this.situacaoAlunoReg = situacaoAlunoReg;
	}

	@Override
	public String toString() {
		return "AlunoReg [id=" + id + ", aluno=" + aluno + ", matricula=" + matricula + ", semestre=" + semestre
				+ ", dataIngresso=" + dataIngresso + ", cursoLinhaPesquisa=" + cursoLinhaPesquisa + ", orientador="
				+ orientador + ", coorientador=" + coorientador + ", pagante=" + pagante + ", prazoConclusao="
				+ prazoConclusao + ", tituloTCC=" + tituloTCC + ", dataHomologacao=" + dataHomologacao
				+ ", dataExpedicaoDiploma=" + dataExpedicaoDiploma + ", dataDesligamento=" + dataDesligamento
				+ ", dataReativacao=" + dataReativacao + ", situacaoAlunoReg=" + situacaoAlunoReg + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(aluno, coorientador, cursoLinhaPesquisa, dataDesligamento, dataExpedicaoDiploma,
				dataHomologacao, dataIngresso, dataReativacao, id, matricula, orientador, pagante, prazoConclusao,
				semestre, situacaoAlunoReg, tituloTCC);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlunoReg other = (AlunoReg) obj;
		return Objects.equals(aluno, other.aluno) && Objects.equals(coorientador, other.coorientador)
				&& Objects.equals(cursoLinhaPesquisa, other.cursoLinhaPesquisa)
				&& Objects.equals(dataDesligamento, other.dataDesligamento)
				&& Objects.equals(dataExpedicaoDiploma, other.dataExpedicaoDiploma)
				&& Objects.equals(dataHomologacao, other.dataHomologacao)
				&& Objects.equals(dataIngresso, other.dataIngresso)
				&& Objects.equals(dataReativacao, other.dataReativacao) && Objects.equals(id, other.id)
				&& Objects.equals(matricula, other.matricula) && Objects.equals(orientador, other.orientador)
				&& pagante == other.pagante && Objects.equals(prazoConclusao, other.prazoConclusao)
				&& Objects.equals(semestre, other.semestre) && situacaoAlunoReg == other.situacaoAlunoReg
				&& Objects.equals(tituloTCC, other.tituloTCC);
	}

				
}