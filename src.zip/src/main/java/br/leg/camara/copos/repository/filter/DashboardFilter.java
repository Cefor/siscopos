package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.Curso;

public class DashboardFilter {

	private Curso curso;
	
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
		
}
