package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.GrauCurso;

public class CursoFilter {

	private String sigla;
	private String nome;
	private GrauCurso grau;
	
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public GrauCurso getGrau() {
		return grau;
	}
	public void setGrau(GrauCurso grau) {
		this.grau = grau;
	}
	
	
	
}
