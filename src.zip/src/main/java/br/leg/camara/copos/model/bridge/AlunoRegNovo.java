package br.leg.camara.copos.model.bridge;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.CursoLinhaPesquisa;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.Professor;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SimNao;

public class AlunoRegNovo {

	private Long id;
	private Curso curso;
	private Pessoa pessoa;
	private String matricula;
	private SemestrePeriodo semestre;
	
	@NotNull(message = "Data de ingresso obrigatória")
	private LocalDate dataIngresso;
	
	private CursoLinhaPesquisa cursoLinhaPesquisa;
	private Professor orientador;
	private Pessoa coorientador;
	private SimNao pagante;	
	private LocalDate prazoConclusao;
	private LocalDate dataAtividadecomplementar;
	private LocalDate dataQualificacao;
	private LocalDate dataDefesa;
	private String tituloTCC;
	private LocalDate dataHomologacao;
	private LocalDate dataExpedicaoDiploma;
	private LocalDate dataDesligamento;
	private LocalDate dataReativacao;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public Pessoa getPessoa() {
		return pessoa;
	}
	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public SemestrePeriodo getSemestre() {
		return semestre;
	}
	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}
	public LocalDate getDataIngresso() {
		return dataIngresso;
	}
	public void setDataIngresso(LocalDate dataIngresso) {
		this.dataIngresso = dataIngresso;
	}
	public CursoLinhaPesquisa getCursoLinhaPesquisa() {
		return cursoLinhaPesquisa;
	}
	public void setCursoLinhaPesquisa(CursoLinhaPesquisa cursoLinhaPesquisa) {
		this.cursoLinhaPesquisa = cursoLinhaPesquisa;
	}
	public Professor getOrientador() {
		return orientador;
	}
	public void setOrientador(Professor orientador) {
		this.orientador = orientador;
	}
	public Pessoa getCoorientador() {
		return coorientador;
	}
	public void setCoorientador(Pessoa coorientador) {
		this.coorientador = coorientador;
	}
	public SimNao getPagante() {
		return pagante;
	}
	public void setPagante(SimNao pagante) {
		this.pagante = pagante;
	}
	public LocalDate getPrazoConclusao() {
		return prazoConclusao;
	}
	public void setPrazoConclusao(LocalDate prazoConclusao) {
		this.prazoConclusao = prazoConclusao;
	}
	public LocalDate getDataAtividadecomplementar() {
		return dataAtividadecomplementar;
	}
	public void setDataAtividadecomplementar(LocalDate dataAtividadecomplementar) {
		this.dataAtividadecomplementar = dataAtividadecomplementar;
	}
	public LocalDate getDataQualificacao() {
		return dataQualificacao;
	}
	public void setDataQualificacao(LocalDate dataQualificacao) {
		this.dataQualificacao = dataQualificacao;
	}
	public LocalDate getDataDefesa() {
		return dataDefesa;
	}
	public void setDataDefesa(LocalDate dataDefesa) {
		this.dataDefesa = dataDefesa;
	}
	public String getTituloTCC() {
		return tituloTCC;
	}
	public void setTituloTCC(String tituloTCC) {
		this.tituloTCC = tituloTCC;
	}
	public LocalDate getDataHomologacao() {
		return dataHomologacao;
	}
	public void setDataHomologacao(LocalDate dataHomologacao) {
		this.dataHomologacao = dataHomologacao;
	}
	public LocalDate getDataExpedicaoDiploma() {
		return dataExpedicaoDiploma;
	}
	public void setDataExpedicaoDiploma(LocalDate dataExpedicaoDiploma) {
		this.dataExpedicaoDiploma = dataExpedicaoDiploma;
	}
	public LocalDate getDataDesligamento() {
		return dataDesligamento;
	}
	public void setDataDesligamento(LocalDate dataDesligamento) {
		this.dataDesligamento = dataDesligamento;
	}
	public LocalDate getDataReativacao() {
		return dataReativacao;
	}
	public void setDataReativacao(LocalDate dataReativacao) {
		this.dataReativacao = dataReativacao;
	}
	
}
