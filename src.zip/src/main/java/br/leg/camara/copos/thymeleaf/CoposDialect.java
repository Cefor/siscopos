package br.leg.camara.copos.thymeleaf;

import java.util.HashSet;
import java.util.Set;

import org.thymeleaf.dialect.AbstractDialect;
import org.thymeleaf.processor.IProcessor;

import br.leg.camara.copos.thymeleaf.processor.ClassForErrorAttributeTagProcessor;
import br.leg.camara.copos.thymeleaf.processor.MenuAttributeTagProcessor;
import br.leg.camara.copos.thymeleaf.processor.MessageElementTagProcessor;
import br.leg.camara.copos.thymeleaf.processor.OrderElementTagProcessor;
import br.leg.camara.copos.thymeleaf.processor.PaginationElementTagProcessor;

// http://www.thymeleaf.org/doc/tutorials/2.1/extendingthymeleaf.html
public class CoposDialect extends AbstractDialect {

	@Override
	public String getPrefix() {
		return "copos";
	}

    @Override
    public Set<IProcessor> getProcessors() {
        final Set<IProcessor> processors = new HashSet<IProcessor>();
        processors.add(new ClassForErrorAttributeTagProcessor());
        processors.add(new MessageElementTagProcessor());
        processors.add(new OrderElementTagProcessor());
        processors.add(new PaginationElementTagProcessor());
        processors.add(new MenuAttributeTagProcessor());
        return processors;
    }

}