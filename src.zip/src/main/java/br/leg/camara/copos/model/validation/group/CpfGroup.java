package br.leg.camara.copos.model.validation.group;

public interface CpfGroup {

}
