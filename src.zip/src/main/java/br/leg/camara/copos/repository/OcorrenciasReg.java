package br.leg.camara.copos.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.OcorrenciaReg;
import br.leg.camara.copos.model.entity.TipoOcorrenciaReg;

public interface OcorrenciasReg extends JpaRepository<OcorrenciaReg, Long> {

	List<OcorrenciaReg> findByAlunoRegOrderByDataOcorrenciaDesc(AlunoReg alunoReg);
	
	Optional<OcorrenciaReg> findByAlunoRegAndTipoOcorrenciaRegAndDataOcorrencia(AlunoReg alunoReg, TipoOcorrenciaReg tipoOcorrenciaReg, LocalDate dataOcorrencia);
	
	List<OcorrenciaReg> findByAlunoRegOrderByDataOcorrencia(AlunoReg alunoReg);
}
