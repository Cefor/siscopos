package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.br.CNPJ;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

import br.leg.camara.copos.model.validation.group.CnpjGroup;

@Entity
@Table(name = "instituicaoparceira")
public class InstituicaoParceira {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "sigla")
	@NotBlank(message = "Sigla obrigatória")
	private String sigla;
	
	@Column(name = "nome")
	@NotBlank(message = "Nome obrigatório")
	private String nome;
	
	@Column(name = "cnpj")
	@NotBlank(message = "CNPJ obrigatório")
	@CNPJ(groups = CnpjGroup.class)
	private String cnpj;
	
	@Column(name = "data_vigencia")
	@NotNull(message = "Data de vigência do acordo obrigatória")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataVigencia;
	
	
	@PrePersist @PreUpdate
	private void prePersistPreUpdate() {
			this.cnpj = retornaCnpjSemFormatacao();
	}
	
	public String retornaCnpjSemFormatacao() {
		return this.cnpj.replaceAll("[/.-]", "");
	}
	
	public boolean isNova() {
		return id == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public LocalDate getDataVigencia() {
		return dataVigencia;
	}

	public void setDataVigencia(LocalDate dataVigencia) {
		this.dataVigencia = dataVigencia;
	}

	@Override
	public String toString() {
		return "InstituicaoParceira [id=" + id + ", sigla=" + sigla + ", nome=" + nome + ", cnpj=" + cnpj
				+ ", dataVigencia=" + dataVigencia + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cnpj, dataVigencia, id, nome, sigla);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InstituicaoParceira other = (InstituicaoParceira) obj;
		return Objects.equals(cnpj, other.cnpj) && Objects.equals(dataVigencia, other.dataVigencia)
				&& Objects.equals(id, other.id) && Objects.equals(nome, other.nome)
				&& Objects.equals(sigla, other.sigla);
	}

	
}
