package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.repository.filter.PessoaFilter;

public interface PessoaService {

	public Pessoa salvar(Pessoa pessoa);
	
	public void excluir(Pessoa pessoa);

	Page<Pessoa> filtrar(PessoaFilter filtro, Pageable pageable);
	

}
