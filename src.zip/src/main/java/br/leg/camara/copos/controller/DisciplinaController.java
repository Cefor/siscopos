package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Disciplina;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.repository.Disciplinas;
import br.leg.camara.copos.repository.GrausCursos;
import br.leg.camara.copos.repository.filter.DisciplinaFilter;
import br.leg.camara.copos.service.DisciplinaService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Controller
@RequestMapping("/disciplina")
public class DisciplinaController {

	@Autowired
	private DisciplinaService disciplinaService;
	
	@Autowired
	private Disciplinas disciplinas;

	@Autowired
	private GrausCursos grausCursos;
	
	
	@RequestMapping("/nova")
	public ModelAndView nova(Disciplina disciplina) {
		ModelAndView mv = new ModelAndView("disciplina/CadastroDisciplina");
		
		mv.addObject("tipos", TipoDisciplina.values());
		mv.addObject("grausCursos", grausCursos.findAll());
							
		return mv;
	}
	
	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid Disciplina disciplina, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(disciplina);
		}
		
		try {
			disciplinaService.salvar(disciplina);
		} catch (DuplicidadeIndiceUnicoException e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return nova(disciplina);
		}

		
		attributes.addFlashAttribute("mensagem", "Disciplina salva com sucesso!");
		return new ModelAndView("redirect:/disciplina/nova");
	}
	
	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(@PathVariable Long id) {
		Disciplina disciplina = disciplinas.findOne(id);
		
		ModelAndView mv = nova(disciplina);
		mv.addObject(disciplina);
		return mv;
	}
	
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") Disciplina disciplina){
		try {
			disciplinaService.excluir(disciplina);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
		
	@GetMapping
	public ModelAndView pesquisar(DisciplinaFilter disciplinaFilter,BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("disciplina/PesquisaDisciplina");

		
		mv.addObject("tipos", TipoDisciplina.values());
		mv.addObject("grausCursos", grausCursos.findAll());
		
		PageWrapper<Disciplina> paginaWrapper = new PageWrapper<>(disciplinaService.filtrar(disciplinaFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}
	
	
	
}
