package br.leg.camara.copos.model.entity;

import java.io.Serializable;
import java.text.Normalizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.br.CPF;

import org.hibernate.validator.group.GroupSequenceProvider;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.leg.camara.copos.model.enums.Escolaridade;
import br.leg.camara.copos.model.enums.EstadoCivil;
import br.leg.camara.copos.model.enums.Sexo;
import br.leg.camara.copos.model.enums.TipoDocumento;
import br.leg.camara.copos.model.validation.PessoaGroupSequenceProvider;
import br.leg.camara.copos.model.validation.group.CpfGroup;

@Entity
@Table(name = "pessoa")
@GroupSequenceProvider(PessoaGroupSequenceProvider.class)
public class Pessoa implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long codigo;

	@NotBlank(message = "Nome é obrigatório")
	private String nome;

	@NotNull(message = "Obrigatório informar o sexo")
	@Column(length = 1)
	@Enumerated(EnumType.STRING)
	private Sexo sexo;
	
	@NotNull(message = "Data de nascimento obrigatória")
	@Column(name = "data_nascimento")
	private LocalDate dataNascimento;
	
	private String nacionalidade;
	
	@Transient
	private Estado estadoNascimento;
	
	@ManyToOne
	@JoinColumn(name = "codigo_naturalidade")
	private Cidade naturalidade;
	
	private String nomePai;

	private String nomeMae;
	
	@Enumerated(EnumType.ORDINAL)
	private EstadoCivil estadoCivil;

	@Enumerated(EnumType.ORDINAL)
	private Escolaridade escolaridade;
	
	private String profissao;
	
	@NotBlank(message = "Obrigatório informar o CPF")
	@CPF(groups = CpfGroup.class)
	private String cpf;
	
	//@NotNull(message = "Tipo de documento é obrigatório")
	@Enumerated(EnumType.ORDINAL)
	@Column(name = "tipo_documento")
	private TipoDocumento tipoDocumento;

	//@NotBlank(message = "Documento obrigatório")
	@Column(name = "numero_documento")
	private String numeroDocumento;

	@Column(name = "orgao_expedidor")
	private String orgaoExpedidor;
	
	@NotBlank(message = "Obrigatório informar o telefone")
	private String telefone;
	
	@Column(name = "email")
	private String email;

	@Column(name = "url_lattes")
	private String urlLattes;
	
	@Valid
	@JsonIgnore
	@Embedded
	private Endereco endereco;
	
	// indicador de cadastro completo
	private boolean completo;
	
	@PrePersist @PreUpdate
	private void prePersistPreUpdate() {
			this.numeroDocumento = retornaNumeroDocumentoSemFormatacao();
			this.cpf = retornaCpfSemFormatacao();
	}
	
	@PostLoad
	private void postLoad() {
		if(!StringUtils.isEmpty(this.numeroDocumento))
			this.numeroDocumento = this.tipoDocumento.formatar(this.numeroDocumento);
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getNomePlano() {
		
		Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
		String normalized = Normalizer.normalize(this.nome, Normalizer.Form.NFD);
	
		return pattern.matcher(normalized).replaceAll("");
	}
		
	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public String getOrgaoExpedidor() {
		return orgaoExpedidor;
	}

	public void setOrgaoExpedidor(String orgaoExpedidor) {
		this.orgaoExpedidor = orgaoExpedidor;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUrlLattes() {
		return urlLattes;
	}

	public void setUrlLattes(String urlLattes) {
		this.urlLattes = urlLattes;
	}
	
	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public boolean isNova() {
		return codigo == null;
	}
	
	public Sexo getSexo() {
		return sexo;
	}

	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}

	public LocalDate getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    this.dataNascimento = LocalDate.parse(dataNascimento,formatter);
	}
	
	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}
	
	public Estado getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimento(Estado estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Cidade getNaturalidade() {
		return naturalidade;
	}

	public void setNaturalidade(Cidade naturalidade) {
		this.naturalidade = naturalidade;
	}

	public String getNomePai() {
		return nomePai;
	}

	public void setNomePai(String nomePai) {
		this.nomePai = nomePai;
	}

	public String getNomeMae() {
		return nomeMae;
	}

	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}

	public String getProfissao() {
		return profissao;
	}

	public void setProfissao(String profissao) {
		this.profissao = profissao;
	}
	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public EstadoCivil getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(EstadoCivil estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public Escolaridade getEscolaridade() {
		return escolaridade;
	}

	public void setEscolaridade(Escolaridade escolaridade) {
		this.escolaridade = escolaridade;
	}
	
	public boolean isCompleto() {
		return completo;
	}

	public void setCompleto(boolean completo) {
		this.completo = completo;
	}
	
	public String getTipoComDocumento () {
		if(!StringUtils.isEmpty(this.numeroDocumento)) {
			if(!StringUtils.isEmpty(this.orgaoExpedidor)) {
				return this.tipoDocumento.getDocumento() + " - " + this.numeroDocumento + " - " + this.orgaoExpedidor;
			} else {
				return this.tipoDocumento.getDocumento() + " - " + this.numeroDocumento;
			}
		}
		
		return "";
	}

	/*
	public String getDataNascimentoString () {
		return "" + this.dataNascimento.getDayOfMonth() + "/" + this.dataNascimento.getMonthValue() + "/" + this.dataNascimento.getYear();  
		// return "" + this.dataNascimento.getDayOfMonth() + "/" + this.dataNascimento.getMonthOfYear() + "/" + this.dataNascimento.getYear();
	}
	*/
	
	public String retornaNumeroDocumentoSemFormatacao() {
		return TipoDocumento.removerFormatacao(this.numeroDocumento);
	}
	
	public String retornaCpfSemFormatacao() {
		return this.cpf.replaceAll("[.-]", "");
	}
	
	
	public String retornaCpfComFormatacao() {
		String cpf = this.cpf;
		
        // Verificar se o CPF é válido (11 dígitos)
        if (cpf == null || cpf.length() != 11) {
            throw new IllegalArgumentException("CPF inválido");
        }

        // Formatar o CPF com pontos e traço
        String cpfFormatado = cpf.substring(0, 3) + "." +
                              cpf.substring(3, 6) + "." +
                              cpf.substring(6, 9) + "-" +
                              cpf.substring(9);
        return cpfFormatado;
    }
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pessoa other = (Pessoa) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}
	
}
