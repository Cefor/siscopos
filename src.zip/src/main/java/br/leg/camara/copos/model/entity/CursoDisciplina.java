package br.leg.camara.copos.model.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import br.leg.camara.copos.model.enums.SimNao;

@Entity
@Table(name = "curso_disciplina")
public class CursoDisciplina {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_curso")
	private Curso curso;
	
	@NotNull(message = "Selecione uma disciplina")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_disciplina")
	private Disciplina disciplina;

	@NotNull(message = "Informe se a disciplina é obrigatória")
	@Column(name = "flag_obrigatoria", length = 1)
	@Enumerated(EnumType.STRING)
	private SimNao flagObrigatoria;	
	
	@ManyToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_curso_linhapesquisa")
	private CursoLinhaPesquisa cursoLinhaPesquisa;
	
	@NotNull(message = "Informe se a disciplina está ativa")
	@Column(name = "flag_ativa", length = 1)
	@Enumerated(EnumType.STRING)
	private SimNao flagAtiva;

	@NotNull(message = "Informe se a disciplina tem subtítulo")
	@Column(name = "flag_subtitulo", length = 1)
	@Enumerated(EnumType.STRING)
	private SimNao flagSubtitulo;
	

	public boolean isNova() {
		return id == null;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Curso getCurso() {
		return curso;
	}


	public void setCurso(Curso curso) {
		this.curso = curso;
	}


	public Disciplina getDisciplina() {
		return disciplina;
	}


	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}


	public SimNao getFlagObrigatoria() {
		return flagObrigatoria;
	}


	public void setFlagObrigatoria(SimNao flagObrigatoria) {
		this.flagObrigatoria = flagObrigatoria;
	}


	public CursoLinhaPesquisa getCursoLinhaPesquisa() {
		return cursoLinhaPesquisa;
	}


	public void setCursoLinhaPesquisa(CursoLinhaPesquisa cursoLinhaPesquisa) {
		this.cursoLinhaPesquisa = cursoLinhaPesquisa;
	}


	public SimNao getFlagAtiva() {
		return flagAtiva;
	}


	public void setFlagAtiva(SimNao flagAtiva) {
		this.flagAtiva = flagAtiva;
	}


	public SimNao getFlagSubtitulo() {
		return flagSubtitulo;
	}


	public void setFlagSubtitulo(SimNao flagSubtitulo) {
		this.flagSubtitulo = flagSubtitulo;
	}


	@Override
	public String toString() {
		return "CursoDisciplina [id=" + id + ", curso=" + curso + ", disciplina=" + disciplina + ", flagObrigatoria="
				+ flagObrigatoria + ", cursoLinhaPesquisa=" + cursoLinhaPesquisa + ", flagAtiva=" + flagAtiva
				+ ", flagSubtitulo=" + flagSubtitulo + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(curso, cursoLinhaPesquisa, disciplina, flagAtiva, flagObrigatoria, flagSubtitulo, id);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CursoDisciplina other = (CursoDisciplina) obj;
		return Objects.equals(curso, other.curso) && Objects.equals(cursoLinhaPesquisa, other.cursoLinhaPesquisa)
				&& Objects.equals(disciplina, other.disciplina) && flagAtiva == other.flagAtiva
				&& flagObrigatoria == other.flagObrigatoria && flagSubtitulo == other.flagSubtitulo
				&& Objects.equals(id, other.id);
	}

	
}
