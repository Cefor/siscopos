package br.leg.camara.copos.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Pessoa;

public interface Alunos extends JpaRepository<Aluno, Long> {
	
	public Optional<Aluno> findById(Long Id);
	
	public Optional<Aluno> findByCursoAndPessoa(Curso curso, Pessoa pessoa);

}
