package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.ProfessorSituacao;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.CursosLinhasPesquisa;
import br.leg.camara.copos.repository.Professores;
import br.leg.camara.copos.repository.ProfessoresSituacoes;
import br.leg.camara.copos.repository.SituacoesProfessores;
import br.leg.camara.copos.repository.filter.ProfessorSituacaoFilter;
import br.leg.camara.copos.service.ProfessorSituacaoService;
import br.leg.camara.copos.service.exception.SituacaoProfessorException;

@Controller
@RequestMapping("/professoressit")
public class ProfessorSituacaoController {

	@Autowired
	private Professores professores;

	@Autowired
	private ProfessoresSituacoes professoresSituacao;
	
	@Autowired
	private SituacoesProfessores situacoesProfessor;
	
	@Autowired
	private CursosLinhasPesquisa cursosLinhasPesquisa;
	
	@Autowired
	private ProfessorSituacaoService professorSituacaoService;
	
	@Autowired
	private Cursos cursos;
	
	
	
	@RequestMapping("/novo/{idProfessor}")
	public ModelAndView novo(ProfessorSituacao professorSituacao, @PathVariable Long idProfessor) {
		ModelAndView mv = new ModelAndView("professorsituacao/CadastroProfessorSituacao");
		
		professorSituacao.setProfessor(professores.getOne(idProfessor));
		

		mv.addObject("situacoesProfessor", situacoesProfessor.findAll());
		mv.addObject("cursoLinhas", cursosLinhasPesquisa.findByCurso(professorSituacao.getProfessor().getCurso()));
		mv.addObject("professorSituacoes", professoresSituacao.findByProfessorOrderByDataInicio(professorSituacao.getProfessor())); 

		
		return mv;
	}

	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(@PathVariable Long id) {
		ProfessorSituacao professorSituacao = professoresSituacao.findOne(id);
		
		ModelAndView mv = novo(professorSituacao, professorSituacao.getProfessor().getId());
		mv.addObject(professorSituacao);
		return mv;
	}
	

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid ProfessorSituacao professorSituacao, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return novo(professorSituacao, professorSituacao.getProfessor().getId());
		}

		try {
			professorSituacaoService.salvar(professorSituacao);
		} catch (SituacaoProfessorException e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/professoressit/novo/" + professorSituacao.getProfessor().getId());

			//result.rejectValue(null, e.getMessage(), e.getMessage());
			//return novo(professorSituacao, professorSituacao.getProfessor().getId());
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return novo(professorSituacao, professorSituacao.getProfessor().getId());
		}

		
		
		// apenas para mostrar na mensagem
		// carrega os atributos curso e linhaPesquisa de cursoLinhaPesquisa que nao vieram mesmo com EAGER 
		professorSituacao.setCursoLinhaPesquisa(
				cursosLinhasPesquisa.findOne(professorSituacao.getCursoLinhaPesquisa().getId()) );
		// carrega os atributo situacao de situacaoProfessor que nao veio mesmo com EAGER
		professorSituacao.setSituacaoProfessor(
				situacoesProfessor.findOne(professorSituacao.getSituacaoProfessor().getId()) 	);
		
		attributes.addFlashAttribute("mensagem", "Situação '" +
												 professorSituacao.getId() + " - " +
		                                         professorSituacao.getSituacaoProfessor().getSituacao() + " - " +
		                                         professorSituacao.getCursoLinhaPesquisa().getLinhaPesquisa().getApelido() +
		                                         "' salva com sucesso ");
		return new ModelAndView("redirect:/professoressit/novo/" + professorSituacao.getProfessor().getId());
	}
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") ProfessorSituacao professorSituacao){
		
		try {
			professorSituacaoService.excluir(professorSituacao);
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}

		return ResponseEntity.ok().build();
	}
	
	
	@GetMapping
	public ModelAndView pesquisar(ProfessorSituacaoFilter professorSituacaoFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		
		ModelAndView mv = new ModelAndView("professorsituacao/PesquisaProfessorSituacao");
		
		mv.addObject("cursos", cursos.findAll());
		mv.addObject("situacoesProfessor", situacoesProfessor.findAll());

		PageWrapper<ProfessorSituacao> paginaWrapper = new PageWrapper<>(professorSituacaoService.filtrar(professorSituacaoFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	
	
	
}





