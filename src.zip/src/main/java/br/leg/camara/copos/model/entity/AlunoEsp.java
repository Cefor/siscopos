package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "alunoesp")
public class AlunoEsp {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_aluno")
	private Aluno aluno;
	
	@Column(name = "matricula", length = 20)
	@NotBlank(message = "Matrícula obrigatória")
	private String matricula;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_semestre_ingresso")
	private SemestrePeriodo semestre;
	
	@Column(name = "data_fimrestricao")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataFimRestricao;
	
	@Column(name = "qtd_disciplinas_cursadas")
	private Integer qtdDisciplinasCursadas;
	
	
	public AlunoEsp() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public AlunoEsp(Aluno aluno, String matricula, SemestrePeriodo semestre, LocalDate dataFimRestricao, Integer qtdDisciplinasCursadas) {
		super();
		this.aluno = aluno;
		this.matricula = matricula;
		this.semestre = semestre;
		this.dataFimRestricao = dataFimRestricao;
		this.qtdDisciplinasCursadas = qtdDisciplinasCursadas;
	}


	public boolean isAlunoNovo() {
		return aluno == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public SemestrePeriodo getSemestre() {
		return semestre;
	}

	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}

	public LocalDate getDataFimRestricao() {
		return dataFimRestricao;
	}

	public void setDataFimRestricao(LocalDate dataFimRestricao) {
		this.dataFimRestricao = dataFimRestricao;
	}

	public Integer getQtdDisciplinasCursadas() {
		return qtdDisciplinasCursadas;
	}

	public void setQtdDisciplinasCursadas(Integer qtdDisciplinasCursadas) {
		this.qtdDisciplinasCursadas = qtdDisciplinasCursadas;
	}

	@Override
	public String toString() {
		return "AlunoEsp [id=" + id + ", aluno=" + aluno + ", matricula=" + matricula + ", semestre=" + semestre
				+ ", dataFimRestricao=" + dataFimRestricao + ", qtdDisciplinasCursadas=" + qtdDisciplinasCursadas + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(aluno, dataFimRestricao, id, matricula, qtdDisciplinasCursadas, semestre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlunoEsp other = (AlunoEsp) obj;
		return Objects.equals(aluno, other.aluno) && Objects.equals(dataFimRestricao, other.dataFimRestricao)
				&& Objects.equals(id, other.id) && Objects.equals(matricula, other.matricula)
				&& Objects.equals(qtdDisciplinasCursadas, other.qtdDisciplinasCursadas)
				&& Objects.equals(semestre, other.semestre);
	}


	
}
