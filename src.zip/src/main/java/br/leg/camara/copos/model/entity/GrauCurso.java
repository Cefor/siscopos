package br.leg.camara.copos.model.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "graucurso")
public class GrauCurso {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	

	@Column(name = "grau")
	@NotNull(message = "Grau obrigatório")
	private int grau;
	
	@Column(name = "nivel")
	@NotNull(message = "Nível obrigatório")
	private int nivel;
	
	@Column(name = "descricao", length = 20)
	@NotBlank(message = "Descrição obrigatória")
	private String descricao;
	
	@Column(name = "titulacao", length = 20)
	@NotBlank(message = "Titulação obrigatória")
	private String titulacao;

	@Column(name = "titulacao_fem", length = 20)
	@NotBlank(message = "Titulação feminina obrigatória")
	private String titulacaoFem;
	
	@Column(name = "documento", length = 20)
	@NotBlank(message = "Documento de conclusão obrigatório")
	private String documento;

	public boolean isNovo() {
		return id == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getGrau() {
		return grau;
	}

	public void setGrau(int grau) {
		this.grau = grau;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getTitulacao() {
		return titulacao;
	}

	public void setTitulacao(String titulacao) {
		this.titulacao = titulacao;
	}

	public String getTitulacaoFem() {
		return titulacaoFem;
	}

	public void setTitulacaoFem(String titulacaoFem) {
		this.titulacaoFem = titulacaoFem;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	@Override
	public String toString() {
		return "GrauCurso [id=" + id + ", grau=" + grau + ", nivel=" + nivel + ", descricao=" + descricao
				+ ", titulacao=" + titulacao + ", titulacaoFem=" + titulacaoFem + ", documento=" + documento + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(descricao, documento, grau, id, nivel, titulacao, titulacaoFem);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GrauCurso other = (GrauCurso) obj;
		return Objects.equals(descricao, other.descricao) && Objects.equals(documento, other.documento)
				&& grau == other.grau && Objects.equals(id, other.id) && nivel == other.nivel
				&& Objects.equals(titulacao, other.titulacao) && Objects.equals(titulacaoFem, other.titulacaoFem);
	}

}
