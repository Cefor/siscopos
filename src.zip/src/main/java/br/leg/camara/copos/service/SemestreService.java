package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.repository.filter.SemestreFilter;

public interface SemestreService {
	
	Page<SemestrePeriodo> filtrar(SemestreFilter filtro, Pageable pageable);

	void salvar(SemestrePeriodo semestre);

	void excluir(SemestrePeriodo semestre);
	
}
