package br.leg.camara.copos.model.validation;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;

import br.leg.camara.copos.model.entity.Pessoa;

// https://pogamando.github.io/2016/11/validacao-condicional-hibernate-validator/
public class PessoaGroupSequenceProvider implements DefaultGroupSequenceProvider<Pessoa> {

	@Override
	public List<Class<?>> getValidationGroups(Pessoa pessoa) {
		List<Class<?>> grupos = new ArrayList<>();
		grupos.add(Pessoa.class);
		
		if (isPessoaSelecionada(pessoa)) {
			grupos.add(pessoa.getTipoDocumento().getGrupo());
		}
		
		return grupos;
	}

	private boolean isPessoaSelecionada(Pessoa pessoa) {
		return pessoa != null && pessoa.getTipoDocumento() != null;
	}

}
