package br.leg.camara.copos.controller;

import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.PessoaVinculo;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.InstituicoesParceiras;
import br.leg.camara.copos.repository.Pessoas;
import br.leg.camara.copos.repository.PessoasVinculos;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.VinculosCD;
import br.leg.camara.copos.repository.filter.PessoaVinculoFilter;
import br.leg.camara.copos.service.PessoaVinculoService;
import br.leg.camara.copos.service.exception.CampoObrigatorioException;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;

@Controller
@RequestMapping("/pessoavinculo")
public class PessoaVinculoController {

	@Autowired
	private VinculosCD vinculosCD;
	
	@Autowired
	private PessoaVinculoService pessoaVinculoService;
	
	@Autowired
	private Cursos cursos;
	
	@Autowired
	private Pessoas pessoas;
	
	@Autowired
	private PessoasVinculos pessoasVinculos;
	
	@Autowired
	private InstituicoesParceiras instituicaoesParceiras;
	
	@Autowired
	private Semestres semestres;
	
	
	@RequestMapping("/novo/{idPessoa}")
	public ModelAndView novo(PessoaVinculo pessoaVinculo, @PathVariable Long idPessoa) {
		ModelAndView mv = new ModelAndView("pessoavinculo/CadastroPessoaVinculo");
		
		pessoaVinculo.setPessoa(pessoas.getOne(idPessoa));

		mv.addObject("vinculoscd", vinculosCD.findAll());
		mv.addObject("instituicoesParceiras", instituicaoesParceiras.findAll());
		
		return mv;
	}


	@GetMapping("/editar/{id}")
	public ModelAndView editar(@PathVariable Long id) {
		PessoaVinculo pessoaVinculo = pessoasVinculos.findOne(id);
		
		ModelAndView mv = novo(pessoaVinculo, pessoaVinculo.getPessoa().getCodigo());
		mv.addObject(pessoaVinculo);
		return mv;
	}

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid PessoaVinculo pessoaVinculo, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return novo(pessoaVinculo, pessoaVinculo.getPessoa().getCodigo());
		}

		try {
			pessoaVinculoService.salvar(pessoaVinculo);
		} catch (DuplicidadeIndiceUnicoException e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/pessoavinculo/novo/" + pessoaVinculo.getPessoa().getCodigo());

			//result.rejectValue(null, e.getMessage(), e.getMessage());
			//return novo(pessoaVinculo, pessoaVinculo.getPessoa().getCodigo());
		} catch (CampoObrigatorioException e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/pessoavinculo/novo/" + pessoaVinculo.getPessoa().getCodigo());
		
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return novo(pessoaVinculo, pessoaVinculo.getPessoa().getCodigo());
		}

		String mensagem = "";
		
		if(!StringUtils.isEmpty(pessoaVinculo.getInstituicaoParceira())) {
			mensagem = pessoaVinculo.getInstituicaoParceira().getNome();
		} else {
			mensagem = "Câmara dos Deputados (" + pessoaVinculo.getVinculoCD().getCategoria() + " - " +
					pessoaVinculo.getPontoCD() + ")";
		}
		
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		attributes.addFlashAttribute("mensagem", "Vínculo com " + mensagem + " iniciado em " +
												  pessoaVinculo.getDataInicio().format(dtFormatter) + 
		                                         " salvo com sucesso ");
		return new ModelAndView("redirect:/pessoavinculo/novo/" + pessoaVinculo.getPessoa().getCodigo());
	}
	

	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") PessoaVinculo pessoaVinculo){
		
		try {
			pessoaVinculoService.excluir(pessoaVinculo);
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}

		return ResponseEntity.ok().build();
	}

	
	
	@GetMapping("/pesquisar/{idPessoa}")
	public ModelAndView pesquisarPessoa(@PathVariable Long idPessoa) {
		
		ModelAndView mv = new ModelAndView("pessoavinculo/PesquisaPessoaVinculo");
		
		Pessoa pessoa = pessoas.findOne(idPessoa);
		
		mv.addObject(pessoa);
		mv.addObject("vinculos", pessoasVinculos.findByPessoaOrderByDataInicioAsc(pessoa));
		
		return mv;
	}
	
	
	
	@GetMapping("/pesquisaralunoreg")
	public ModelAndView pesquisarAlunoReg(PessoaVinculoFilter pessoaVinculoFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		
		ModelAndView mv = new ModelAndView("pessoavinculo/PesquisaAlunoRegVinculo");
		
		mv.addObject("vinculoscd", vinculosCD.findAll());
		mv.addObject("semestres", semestres.findByOrderByAnoDescSemestreDesc());
		
		
		List<Curso> listaCursos = cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc();
		mv.addObject("cursos", listaCursos);

		/*
		if(pessoaVinculoFilter.getCurso() == null) {
			if(listaCursos.size() > 0) {
				pessoaVinculoFilter.setCurso(listaCursos.get(0)); // Mestrado	
			}
		}
		*/
		
		PageWrapper<PessoaVinculo> paginaWrapper = new PageWrapper<>(pessoaVinculoService.filtrar(pessoaVinculoFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	
	
	
}





