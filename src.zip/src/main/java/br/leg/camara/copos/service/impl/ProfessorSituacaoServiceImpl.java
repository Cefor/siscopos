package br.leg.camara.copos.service.impl;

import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.ProfessorSituacao;
import br.leg.camara.copos.repository.ProfessoresSituacoes;
import br.leg.camara.copos.repository.filter.ProfessorSituacaoFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.ProfessorSituacaoService;
import br.leg.camara.copos.service.exception.SituacaoProfessorException;

@Service
public class ProfessorSituacaoServiceImpl implements ProfessorSituacaoService {
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
		
	@Autowired
	private ProfessoresSituacoes professoresSituacao;
	
	
	
	@Override
	@Transactional
	public void salvar(ProfessorSituacao professorSituacao) {
		
		// verifica se data inicio eh menor que data fim
		if(professorSituacao.getDataFim() != null) {
			if(professorSituacao.getDataInicio().isEqual(professorSituacao.getDataFim()) ||
					   professorSituacao.getDataInicio().isAfter(professorSituacao.getDataFim())	
							) {
						throw new SituacaoProfessorException("Data de início deve ser menor que data fim.");
					}
		}

		
		List<ProfessorSituacao> listaSituacao;
		
		// se existirem situacoes cadastradas, verificar superposicao
		listaSituacao = professoresSituacao.findByProfessorOrderByDataInicioDesc(professorSituacao.getProfessor());
		
		
		if(listaSituacao.size() > 0) {

			// data fim esta em aberto?
			if(professorSituacao.getDataFim() ==  null) {
				// verfica se alguma situacao existente tem data fim em aberto, exceto o proprio registro sendo editado
				for(ProfessorSituacao situacao : listaSituacao) {
					if(professorSituacao.getId() != situacao.getId() && situacao.getDataFim() == null) {
						throw new SituacaoProfessorException("Você está tentando salvar uma situação com data Fim em aberto. " + 
	                             "Finalize a situação " + situacao.getId() +" antes de inserir outra com data Fim em aberto.");
					}
				}
				
				// verfica se eh a mais recente
				if(professorSituacao.getId() != listaSituacao.get(0).getId() && !professorSituacao.getDataInicio().isAfter(listaSituacao.get(0).getDataFim())) {
					throw new SituacaoProfessorException("Uma nova situação com data Fim em aberto deve conter data de Início mais recente que " +
							listaSituacao.get(0).getDataFim().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) +
							" - situacao " + listaSituacao.get(0).getId() + "."
							);	
				}
			} else {
				// se for novo e o mais recente tiver data fim em aberto
				if(professorSituacao.isNova() && listaSituacao.get(0).getDataFim() == null) {
					// e a situacao nova tiver data fim maior que a data inicio da mais recente
					if(professorSituacao.getDataFim().isAfter(listaSituacao.get(0).getDataInicio())) {
						throw new SituacaoProfessorException("Você está tentando incluir uma situação com data Fim maior do que a data Início da situação em aberto. " +
								"Finalize a situação " + listaSituacao.get(0).getId() +" ou corrija a atual.");	
					}
				} 
				
			}
			
				
			// verifica se ha superposicao
			for(ProfessorSituacao situacao : listaSituacao) {

				// so verifica quando nao eh o proprio registro sendo editado
				if(professorSituacao.getId().longValue() != situacao.getId().longValue()) {
					
					// testa superposicao da data Inicio
					if(professorSituacao.getDataInicio().isEqual(situacao.getDataInicio()) ||
							   (situacao.getDataFim() != null && professorSituacao.getDataInicio().isEqual(situacao.getDataFim())) ||
							   (professorSituacao.getDataInicio().isAfter(situacao.getDataInicio()) &&
								  situacao.getDataFim() != null && professorSituacao.getDataInicio().isBefore(situacao.getDataFim()))
							   ) {
						throw new SituacaoProfessorException("Não pode haver superposição de períodos. O período " + 
							       professorSituacao.getDataInicio().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " - " +
							       professorSituacao.getDataFim().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + 
							       " colide com situação " +
							       situacao.getId() + "."
								);
					}

					// testa superposicao da data Fim
					if((professorSituacao.getDataFim() != null && professorSituacao.getDataFim().isEqual(situacao.getDataInicio())) ||
							   (situacao.getDataFim() != null && professorSituacao.getDataFim() != null && professorSituacao.getDataFim().isEqual(situacao.getDataFim())) ||
							   (professorSituacao.getDataFim() != null && professorSituacao.getDataFim().isAfter(situacao.getDataInicio()) &&
								  situacao.getDataFim() != null && professorSituacao.getDataFim().isBefore(situacao.getDataFim()))
							   ) {
						throw new SituacaoProfessorException("Não pode haver superposição de períodos. O período " + 
							       professorSituacao.getDataInicio().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " - " +
							       professorSituacao.getDataFim().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + 
							       " colide com situação " +
							       situacao.getId() + "."
								);
					}
					
				}

			}				
				
		}
		
		professoresSituacao.save(professorSituacao);
	}

	
	
	@Override
	@Transactional
	public void excluir(ProfessorSituacao professorSituacao) {

		// nao ha possibilidade de erro de integridade por associacao com outra entidade
		professoresSituacao.delete(professorSituacao);
		professoresSituacao.flush();
		
	}
	
	

	// Filtrar e paginação - PESQUISA
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<ProfessorSituacao> filtrar(ProfessorSituacaoFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(ProfessorSituacao.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<ProfessorSituacao> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}

	
	private void adicionarFiltro(ProfessorSituacaoFilter filtro, Criteria criteria) {
		
		
		Criteria professorCrit = criteria.createCriteria("professor");
		Criteria cursoCrit = professorCrit.createCriteria("curso");
		Criteria pessoaCrit = professorCrit.createCriteria("pessoa");
		Criteria cursoLinhaPesquisaCrit = criteria.createCriteria("cursoLinhaPesquisa");
		Criteria linhaPesquisaCrit = cursoLinhaPesquisaCrit.createCriteria("linhaPesquisa"); 
		//criteria.createAlias("situacaoProfessor", "sp", JoinType.LEFT_OUTER_JOIN);
		
		cursoCrit.addOrder(Order.asc("sigla"));
		pessoaCrit.addOrder(Order.asc("nome"));
		criteria.addOrder(Order.asc("dataInicio"));
		
		
		if (filtro != null) {

			if (!StringUtils.isEmpty(filtro.getCurso())) {
				professorCrit.add(Restrictions.eq("curso", filtro.getCurso()));
			}
			
			if (!StringUtils.isEmpty(filtro.getNome())) {
				pessoaCrit.add(Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getSituacaoProfessor())) {
				criteria.add(Restrictions.eq("situacaoProfessor", filtro.getSituacaoProfessor()));
			}
			
			if (!StringUtils.isEmpty(filtro.getLinha())) {
				linhaPesquisaCrit.add(Restrictions.ilike("apelido", filtro.getLinha(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getFlagDataFim())) {
				if(filtro.getFlagDataFim().equals("Sim")) {
					criteria.add(Restrictions.isNull("dataFim"));					
				}
			}

			if (!StringUtils.isEmpty(filtro.getDataReferencia())) {
				
				criteria.add(Restrictions.and(
							      	Restrictions.le("dataInicio", filtro.getDataReferencia()),
							      	Restrictions.or(
							      			Restrictions.ge("dataFim", filtro.getDataReferencia()),
							      			Restrictions.isNull("dataFim")
							      	)
						      )
						);
			}
		}
		
		
	}
		
	private Long total(ProfessorSituacaoFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(ProfessorSituacao.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA

}
