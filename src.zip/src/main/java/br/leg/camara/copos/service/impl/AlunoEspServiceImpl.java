package br.leg.camara.copos.service.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.bridge.AlunoEspNovo;
import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;
import br.leg.camara.copos.repository.Alunos;
import br.leg.camara.copos.repository.AlunosEsp;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.filter.AlunoEspFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.AlunoEspService;
import br.leg.camara.copos.service.exception.AlunoJaCadastradoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.PessoaObrigatoriaException;

@Service
public class AlunoEspServiceImpl implements AlunoEspService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private AlunosEsp alunosEsp;

	@Autowired
	private Alunos alunos;	
	
	@Autowired
	private AlunosReg alunosReg;	
	
	
	@Override
	@Transactional
	public void salvar(AlunoEspNovo alunoEspNovo) {
		
		Aluno aluno = new Aluno();
		
		if(alunoEspNovo.getPessoa().isNova()) {
			throw new PessoaObrigatoriaException("Obrigatório informar o(a) aluno(a)");
		}
		
		// verifica se ja eh aluno especial
		Optional<AlunoEsp> alunoAuxEsp = alunosEsp.findByAlunoCursoAndAlunoPessoa(alunoEspNovo.getCurso(), alunoEspNovo.getPessoa());
		if(alunoAuxEsp.isPresent()) {
			throw new AlunoJaCadastradoException( alunoAuxEsp.get().getAluno().getPessoa().getNome() +
		                                          " já tem matrícula como especial (" +
		                                          alunoAuxEsp.get().getMatricula() +
		                                          ")!");	
		}


		// verifica se eh aluno regular ativo no curso
		Optional<AlunoReg> alunoAuxReg = alunosReg.findByAlunoPessoaAndAlunoCursoAndSituacaoAlunoReg(alunoEspNovo.getPessoa(), alunoEspNovo.getCurso(), SituacaoAlunoReg.A);
		if(alunoAuxReg.isPresent()) {
			throw new AlunoJaCadastradoException( alunoAuxReg.get().getAluno().getPessoa().getNome() +
		                                          " tem matrícula ativa como regular (" +
		                                          alunoAuxReg.get().getMatricula() +
		                                          ")!");	
		}


		if(alunoEspNovo.getMatricula().isEmpty()) {
			// verifica a ultima matricula efetuada no mesmo semestre/curso e soma 1
			String ultimaMatricula = "0";
			List<AlunoEsp> listaAlunoEsp = alunosEsp.findBySemestreAndAlunoCursoOrderByMatriculaDesc(alunoEspNovo.getSemestre(), alunoEspNovo.getCurso());
			if(listaAlunoEsp.size() > 0) {
				ultimaMatricula = listaAlunoEsp.get(0).getMatricula();
				ultimaMatricula = (String) ultimaMatricula.subSequence(ultimaMatricula.length()-6, ultimaMatricula.length()-3);
			}
			String seq = "00" + (Integer.parseInt(ultimaMatricula) + 1);
			
			alunoEspNovo.setMatricula(
					alunoEspNovo.getSemestre().getAno() +
					alunoEspNovo.getCurso().getSigla() +
					alunoEspNovo.getSemestre().getSemestre() +
					seq.subSequence(seq.length() - 3, seq.length())	+
					"Esp"
					);
		}
		
		Optional<Aluno> alunoaux = alunos.findByCursoAndPessoa(alunoEspNovo.getCurso(), alunoEspNovo.getPessoa());
		
		if(alunoaux.isPresent()) { // se o aluno existe ...
			
			aluno = alunoaux.get();
			
			// e aluno especial existe -> mensagem de duplicidade
			if(alunosEsp.findByAluno(aluno).isPresent()) {
				throw new AlunoJaCadastradoException(alunoEspNovo.getPessoa().getNome() + " já é aluno(a) especial");
			} 

		} else { // se nao existir
			
			aluno = new Aluno(alunoEspNovo.getCurso(), alunoEspNovo.getPessoa());
			aluno = alunos.save(aluno);
		}
		
		AlunoEsp alunoEsp = new AlunoEsp(
				aluno,
				alunoEspNovo.getMatricula(),
				alunoEspNovo.getSemestre(),
				alunoEspNovo.getDataFimRestricao(),
				0
				);
		
		alunosEsp.save(alunoEsp);
	}
	
	
	@Override
	@Transactional
	public void salvarEdicao(AlunoEsp alunoEsp) {
		/*
		if(alunoEsp.getMatricula().isEmpty()) {
			throw new MatriculaObrigatoriaException("Obrigatório informar a matrícula");	
		}
		*/
	
		alunosEsp.save(alunoEsp);
	}
	
	
	@Override
	@Transactional
	public void excluir(AlunoEsp alunoEsp) {
		try {
			alunosEsp.delete(alunoEsp);
			alunosEsp.flush();
			
			// se nao tiver registro como aluno regular, excluir de Aluno
			if(!alunosReg.findByAluno(alunoEsp.getAluno()).isPresent()) {
				alunos.delete(alunoEsp.getAluno());
				alunos.flush();
			}
			
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Aluno especial já associado a outra entidade.");
		}
	}

	
	
	
	
	// Filtrar e paginação - PESQUISA GERAL
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<AlunoEsp> filtrar(AlunoEspFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoEsp.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<AlunoEsp> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	private void adicionarFiltro(AlunoEspFilter filtro, Criteria criteria) {
		
		Criteria alunoCrit = criteria.createCriteria("aluno");
		alunoCrit.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		alunoCrit.createAlias("curso", "c", JoinType.LEFT_OUTER_JOIN);
		
		alunoCrit.addOrder(Order.asc("p.nome"));
		alunoCrit.addOrder(Order.asc("c.nome"));
		
		if (filtro != null) {
	
			if (!StringUtils.isEmpty(filtro.getNome())) {
				alunoCrit.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCurso())) {
				alunoCrit.add(Restrictions.eq("curso", filtro.getCurso()));
			}
						
			if (!StringUtils.isEmpty(filtro.getCpf())) {
				alunoCrit.add(Restrictions.ilike("p.cpf", filtro.getCpf(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getMatricula())) {
				criteria.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getDataFimRestricao())) {
				criteria.add(Restrictions.gt("dataFimRestricao", filtro.getDataFimRestricao()));
			}
		}
	}
	
	private Long total(AlunoEspFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoEsp.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA GERAL
	
	
	// Filtrar e paginação - PESQUISA MATRICULA SEMESTRE
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Matricula> filtrarMatriculaSemestre(AlunoEspFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Matricula.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro2(filtro, criteria);
		
		List<Matricula> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total2(filtro));
	}
	
	private void adicionarFiltro2(AlunoEspFilter filtro, Criteria criteria) {
		
		criteria.createAlias("semestre", "s", JoinType.LEFT_OUTER_JOIN);
		
		Criteria alunoCrit = criteria.createCriteria("aluno");
		alunoCrit.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		alunoCrit.createAlias("curso", "c", JoinType.LEFT_OUTER_JOIN);
		
		Criteria alunoEspCrit = criteria.createCriteria("alunoEsp");
		
		criteria.add(Restrictions.isNotNull("alunoEsp"));
		
		alunoCrit.addOrder(Order.asc("p.nome"));
		alunoCrit.addOrder(Order.asc("c.nome"));
		criteria.addOrder(Order.asc("s.periodo"));
		
		
		if (filtro != null) {
	
			if (!StringUtils.isEmpty(filtro.getNome())) {
				alunoCrit.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCurso())) {
				alunoCrit.add(Restrictions.eq("curso", filtro.getCurso()));
			}
						
			if (!StringUtils.isEmpty(filtro.getCpf())) {
				alunoCrit.add(Restrictions.ilike("p.cpf", filtro.getCpf(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getMatricula())) {
				alunoEspCrit.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getSemestre())) {
				criteria.add(Restrictions.eq("semestre", filtro.getSemestre()));
			}

		}
		
	}
	
	private Long total2(AlunoEspFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Matricula.class);
		adicionarFiltro2(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA MATRICULA SEMESTRE
	
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public List<Matricula> filtrarTodos(AlunoEspFilter filtro) {
	    // Criar um objeto Criteria para a entidade Matricula
	    Criteria criteria = manager.unwrap(Session.class).createCriteria(Matricula.class);

	    // Adicionar filtros com base no AlunoRegFilter
	    adicionarFiltro2(filtro, criteria);

	    // Retornar a lista completa de registros filtrados
	    return criteria.list();
	}

	
}
