package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.enums.SimNao;

public class SemestreFilter {

	private String ano;
	private String semestre;
	private SimNao flagMatricula;
	
	
	public String getAno() {
		return ano;
	}
	public void setAno(String ano) {
		this.ano = ano;
	}
	public String getSemestre() {
		return semestre;
	}
	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}
	public SimNao getFlagMatricula() {
		return flagMatricula;
	}
	public void setFlagMatricula(SimNao flagMatricula) {
		this.flagMatricula = flagMatricula;
	}

	
	
}
