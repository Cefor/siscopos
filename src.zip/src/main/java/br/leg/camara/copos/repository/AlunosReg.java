package br.leg.camara.copos.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;

public interface AlunosReg extends JpaRepository<AlunoReg, Long> {

	public Optional<AlunoReg> findById(Long id);
	
	public Optional<AlunoReg> findByAluno(Aluno aluno);
		
	public List<AlunoReg> findBySemestreAndAlunoCursoOrderByMatriculaDesc(SemestrePeriodo semestre, Curso curso);
	
	// usado para saber se a pessoa eh aluno regular ativo no curso
	public Optional<AlunoReg> findByAlunoPessoaAndAlunoCursoAndSituacaoAlunoReg(Pessoa pessoa, Curso curso, SituacaoAlunoReg situacaoAlunoReg);
	
	// usado para trazer os alunos regulares ativos do curso
	public List<AlunoReg> findByAlunoCursoAndSituacaoAlunoReg(Curso curso, SituacaoAlunoReg situacaoAlunoReg);
	// usado para trazer ativos com prazo encerrado
	public List<AlunoReg> findByAlunoCursoAndSituacaoAlunoRegAndPrazoConclusaoLessThan(Curso curso, SituacaoAlunoReg situacaoAlunoReg, LocalDate dataAtual);
	

	// quantifica egressos
	public List<AlunoReg> findByAlunoCursoAndDataHomologacaoIsNotNull(Curso curso);

	// quantifica desligados
	public List<AlunoReg> findByAlunoCursoAndDataHomologacaoIsNullAndDataDesligamentoIsNotNullAndDataReativacaoIsNull(Curso curso);
		
	// quantifica prazo conclusao expirado
	public List<AlunoReg> findByAlunoCursoAndPrazoConclusaoLessThan(Curso curso, LocalDate prazoConclusao);
	
	// total de regulares no curso
	public List<AlunoReg> findByAlunoCurso(Curso curso);
}
