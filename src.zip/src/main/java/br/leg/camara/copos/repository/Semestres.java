package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SimNao;

public interface Semestres extends JpaRepository<SemestrePeriodo, Long> {
	
	List<SemestrePeriodo> findByOrderByAnoDescSemestreDesc();
	
	public Optional<SemestrePeriodo> findById(Long Id);
	
	List<SemestrePeriodo> findByFlagMatriculaOrderByAnoDescSemestreDesc(SimNao flag);
	
	public Optional<SemestrePeriodo> findByAnoAndSemestre(String ano, String semestre);
	
}
