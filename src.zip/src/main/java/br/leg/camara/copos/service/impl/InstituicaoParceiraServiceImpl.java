package br.leg.camara.copos.service.impl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.InstituicaoParceira;
import br.leg.camara.copos.repository.InstituicoesParceiras;
import br.leg.camara.copos.repository.filter.InstituicaoParceiraFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.InstituicaoParceiraService;
import br.leg.camara.copos.service.exception.CnpjJaCadastradoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Service
public class InstituicaoParceiraServiceImpl implements InstituicaoParceiraService {
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	
	@Autowired
	private InstituicoesParceiras instituicoesParceiras;
	
	

	@Override
	@Transactional
	public void salvar(InstituicaoParceira instituicaoParceira) {
		
		if (instituicaoParceira.isNova() && 
				instituicoesParceiras.findByCnpj(instituicaoParceira.retornaCnpjSemFormatacao()).isPresent()) {
			throw new CnpjJaCadastradoException("CNPJ já cadastrado: " + instituicaoParceira.getCnpj());
		}
		
		instituicoesParceiras.save(instituicaoParceira);
	}
	
	
	@Override
	@Transactional
	public void excluir(InstituicaoParceira instituicaoParceira) {
		try {
			instituicoesParceiras.delete(instituicaoParceira);
			instituicoesParceiras.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Instituição já foi associada a outra entidade.");
		}
	}

	
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<InstituicaoParceira> filtrar(InstituicaoParceiraFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(InstituicaoParceira.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<InstituicaoParceira> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	private void adicionarFiltro(InstituicaoParceiraFilter filtro, Criteria criteria) {
		
		if (filtro != null) {
			
			if (!StringUtils.isEmpty(filtro.getSigla())) {
				criteria.add(Restrictions.ilike("sigla", filtro.getSigla(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCnpj())) {
				criteria.add(Restrictions.ilike("cnpj", filtro.getCnpj(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getDataVigencia())) {
				criteria.add(Restrictions.ge("dataVigencia", filtro.getDataVigencia()));
			}
			
		}
	}
	
	private Long total(InstituicaoParceiraFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(InstituicaoParceira.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação


}
