package br.leg.camara.copos.repository.filter;

import java.time.LocalDate;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.SituacaoProfessor;

public class ProfessorSituacaoFilter {

	private Curso curso;
	private String nome;
	private SituacaoProfessor situacaoProfessor;
	private String linha;
	private String flagDataFim;
	private LocalDate dataReferencia; 
	
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public SituacaoProfessor getSituacaoProfessor() {
		return situacaoProfessor;
	}
	public void setSituacaoProfessor(SituacaoProfessor situacaoProfessor) {
		this.situacaoProfessor = situacaoProfessor;
	}
	public String getLinha() {
		return linha;
	}
	public void setLinha(String linha) {
		this.linha = linha;
	}
	public String getFlagDataFim() {
		return flagDataFim;
	}
	public void setFlagDataFim(String flagDataFim) {
		this.flagDataFim = flagDataFim;
	}
	public LocalDate getDataReferencia() {
		return dataReferencia;
	}
	public void setDataReferencia(LocalDate dataReferencia) {
		this.dataReferencia = dataReferencia;
	}
	
	
	
}
