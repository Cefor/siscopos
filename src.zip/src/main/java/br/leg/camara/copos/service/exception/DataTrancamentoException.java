package br.leg.camara.copos.service.exception;

public class DataTrancamentoException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public DataTrancamentoException(String message) {
		super(message);
	}

}
