package br.leg.camara.copos.service.impl;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.PessoaVinculo;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.PessoasVinculos;
import br.leg.camara.copos.repository.filter.PessoaVinculoFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.PessoaVinculoService;
import br.leg.camara.copos.service.exception.CampoObrigatorioException;
import br.leg.camara.copos.service.exception.DatasAlunoRegException;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Service
public class PessoaVinculoServiceImpl implements PessoaVinculoService {

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private AlunosReg alunosReg;

	@Autowired
	private PessoasVinculos pessoasVinculos;
	

	@Override
	@Transactional
	public void salvar(PessoaVinculo pessoaVinculo) {

		if(pessoasVinculos.findByPessoaAndDataInicio(pessoaVinculo.getPessoa(), pessoaVinculo.getDataInicio()).isPresent() &&
				pessoaVinculo.isNovo()) {
			DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			throw new DuplicidadeIndiceUnicoException("Já existe vÍnculo associado à data de início " + pessoaVinculo.getDataInicio().format(dtFormatter));
		}
		
		if(StringUtils.isEmpty(pessoaVinculo.getInstituicaoParceira()) &&
				StringUtils.isEmpty(pessoaVinculo.getVinculoCD()) &&
				StringUtils.isEmpty(pessoaVinculo.getPontoCD())
				) {
			throw new CampoObrigatorioException("Obrigatório informar a Instituição, ou Vínculo CD + Ponto CD");
		} else if(!StringUtils.isEmpty(pessoaVinculo.getVinculoCD()) &&
				   StringUtils.isEmpty(pessoaVinculo.getPontoCD())) {
			throw new CampoObrigatorioException("Obrigatório informar Ponto CD");
		} else if(StringUtils.isEmpty(pessoaVinculo.getVinculoCD()) &&
				  !StringUtils.isEmpty(pessoaVinculo.getPontoCD())) {
			throw new CampoObrigatorioException("Obrigatório informar Vínculo CD");
		}
		
		if(!StringUtils.isEmpty(pessoaVinculo.getDataFim()) &&
				(pessoaVinculo.getDataFim().isEqual(pessoaVinculo.getDataInicio()) ||
						pessoaVinculo.getDataFim().isBefore(pessoaVinculo.getDataInicio()))) {
			throw new DatasAlunoRegException("Data do fim do vínculo deve ser maior que a data do início");
		}
		
		pessoasVinculos.save(pessoaVinculo);
	}


	@Override
	@Transactional
	public void excluir(PessoaVinculo pessoaVinculo) {
		try {
			pessoasVinculos.delete(pessoaVinculo);
			pessoasVinculos.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Vínculo já foi associado a outra entidade.");
		}
	}
	

	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<PessoaVinculo> filtrar(PessoaVinculoFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(PessoaVinculo.class);
		
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
				
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}
	

	private void adicionarFiltro(PessoaVinculoFilter filtro, Criteria criteria) {
		
		criteria.createAlias("instituicaoParceira", "ip", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		criteria.addOrder(Order.asc("p.nome"));
		criteria.addOrder(Order.asc("dataInicio")); 

		List<AlunoReg> listaAlunosReg = new ArrayList<>();
		
		// inicia flag com 0 para logica de carregamento de listaAlunosReg 
		int flag = 0;
		
		// filtros em AlunoReg
		if(!StringUtils.isEmpty(filtro.getCurso()) ||
				!StringUtils.isEmpty(filtro.getSemestre())
				) {
			Criteria alunoRegCriteria = manager.unwrap(Session.class).createCriteria(AlunoReg.class);
			
			if(!StringUtils.isEmpty(filtro.getCurso())) {
				alunoRegCriteria.createAlias("aluno", "a", JoinType.LEFT_OUTER_JOIN);
				alunoRegCriteria.add(Restrictions.eq("a.curso", filtro.getCurso()));
			}
			if(!StringUtils.isEmpty(filtro.getSemestre())) {
				alunoRegCriteria.add(Restrictions.eq("semestre", filtro.getSemestre()));
			}
			
			@SuppressWarnings("unchecked")
			List<AlunoReg> result = (List<AlunoReg>) alunoRegCriteria.list();
            // listaAlunosReg = result != null ? result : new ArrayList<>();
			listaAlunosReg = result;
			
			flag = 1;
		}
		
		if(flag == 0) {
			listaAlunosReg = alunosReg.findAll();
		}
		
		// reseta o flag com zero para verificar se ha filtors em PessoaVinculo
		flag = 0;
		
		// filtros em PessoaVinculo
		if (!StringUtils.isEmpty(filtro.getInstituicaoParceira())) {
			criteria.add(Restrictions.ilike("ip.nome", filtro.getInstituicaoParceira(), MatchMode.ANYWHERE));
			flag = 1;
		}
		if (!StringUtils.isEmpty(filtro.getVinculoCD())) {
			criteria.add(Restrictions.eq("vinculoCD", filtro.getVinculoCD()));
			flag = 1;
		}
		if (!StringUtils.isEmpty(filtro.getNome())) {
			criteria.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			flag = 1;
		}
		if (!StringUtils.isEmpty(filtro.getDataVigencia())) {
			criteria.add(Restrictions.le("ip.dataVigencia", filtro.getDataVigencia()));
			flag = 1;
		}

		
		List<Pessoa> listaPessoas = listaAlunosReg.stream()
			    .map(alunoReg -> alunoReg.getAluno().getPessoa())
			    .collect(Collectors.toList());
		
	    if (!listaPessoas.isEmpty()) {
	        criteria.add(Restrictions.in("pessoa", listaPessoas));
	    } else if(flag == 0) {
	    	criteria.add(Restrictions.eq("id", -1L));
	    }
	}
	
	private Long total(PessoaVinculoFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(PessoaVinculo.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	
}
