package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.SemestrePeriodo;

public interface AlunosEsp extends JpaRepository<AlunoEsp, Long> {

	public Optional<AlunoEsp> findById(Long Id);
	
	public Optional<AlunoEsp> findByAluno(Aluno aluno);
	
	public List<AlunoEsp> findByAlunoCurso(Curso curso);
	
	public Optional<AlunoEsp> findByAlunoCursoAndAlunoPessoa(Curso curso, Pessoa pessoa);
	
	public List<AlunoEsp> findBySemestreAndAlunoCursoOrderByMatriculaDesc(SemestrePeriodo semestre, Curso curso);
	
}
