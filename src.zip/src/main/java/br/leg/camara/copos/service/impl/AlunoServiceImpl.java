package br.leg.camara.copos.service.impl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.repository.Alunos;
import br.leg.camara.copos.repository.filter.AlunoFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.AlunoService;

@Service
public class AlunoServiceImpl implements AlunoService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private Alunos alunos;
	
	
	@Transactional
	@Override
	public void salvar(Aluno aluno) {
		alunos.save(aluno);
	}
	
		
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public List<MatriculaDisciplina> matriculas(Long idAluno){
		Criteria criteria = manager.unwrap(Session.class).createCriteria(MatriculaDisciplina.class);
		
		Criteria matricula  = criteria.createCriteria("matricula");
		matricula.add(Restrictions.eq("aluno.id", idAluno));
		matricula.addOrder(Order.asc("semestre"));
		
		criteria.addOrder(Order.asc("dataMencao"));

		criteria.createAlias("oferta.cursoDisciplina.disciplina", "d", JoinType.LEFT_OUTER_JOIN);
		criteria.addOrder(Order.asc("d.sigla"));
		// a forma abaixo tambem funciona 
		//Criteria disciplina = criteria.createCriteria("oferta.cursoDisciplina.disciplina");
	    //disciplina.addOrder(Order.asc("sigla"));

		
		//Criteria oferta  = criteria.createCriteria("oferta");
		//oferta.add(Restrictions.isNull("dataCancelamento"));
		
		List<MatriculaDisciplina> lista = criteria.list() ;
		
		return lista;
	}
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Aluno> filtrar(AlunoFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Aluno.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<Aluno> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	
	private void adicionarFiltro(AlunoFilter filtro, Criteria criteria) {
		
		criteria.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("curso", "c", JoinType.LEFT_OUTER_JOIN);
		
		criteria.addOrder(Order.asc("p.nome"));
		criteria.addOrder(Order.asc("c.nome"));
		
		if (filtro != null) {
			
	
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCurso())) {
				criteria.add(Restrictions.eq("curso", filtro.getCurso()));
			}
						
			if (!StringUtils.isEmpty(filtro.getCpf())) {
				criteria.add(Restrictions.ilike("p.cpf", filtro.getCpf(), MatchMode.ANYWHERE));
			}
		}
	}
	
	
	private Long total(AlunoFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Aluno.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação
	
}
