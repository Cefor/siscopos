package br.leg.camara.copos.thymeleaf.processor;

import java.util.ArrayList;
import java.util.List;

import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.dom.Node;
import org.thymeleaf.processor.element.AbstractMarkupSubstitutionElementProcessor;

// http://www.thymeleaf.org/doc/tutorials/2.1/extendingthymeleaf.html
public class MessageElementTagProcessor extends AbstractMarkupSubstitutionElementProcessor{

	public MessageElementTagProcessor() {
		super("message");
	}

	@Override
	public int getPrecedence() {
		return 1000;
	}

	@Override
	protected List<Node> getMarkupSubstitutes(Arguments arguments, Element element) {

		// erro de validacao de campos de em formulario anotados com classforerror
        final Element container = new Element("th:block");
        container.setAttribute("th:replace", "fragments/MensagensErroValidacao");
        
        // mensagem de sucesso
        final Element container2 = new Element("th:block");
        container2.setAttribute("th:replace", "fragments/MensagemSucesso");
        
        // mensagem para tratamento de outras exceptions
        final Element container3 = new Element("th:block");
        container3.setAttribute("th:replace", "fragments/MensagemErroException");
        
        final List<Node> nodes = new ArrayList<Node>();
        nodes.add(container); 
        nodes.add(container2);
        nodes.add(container3);
        
        return nodes;
	}

}
