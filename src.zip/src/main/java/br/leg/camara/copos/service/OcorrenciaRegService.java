package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.OcorrenciaReg;
import br.leg.camara.copos.repository.filter.OcorrenciaRegFilter;

public interface OcorrenciaRegService {

	void salvar(OcorrenciaReg ocorrenciaReg);

	void excluir(OcorrenciaReg ocorrenciaReg);

	Page<OcorrenciaReg> filtrar(OcorrenciaRegFilter filtro, Pageable pageable);

}
