package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.repository.filter.CursoFilter;

public interface CursoService {
	
	Page<Curso> filtrar(CursoFilter filtro, Pageable pageable);

	void salvar(Curso curso);

	void excluir(Curso curso);
}
