package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.InstituicaoParceira;
import br.leg.camara.copos.repository.filter.InstituicaoParceiraFilter;

public interface InstituicaoParceiraService {

	Page<InstituicaoParceira> filtrar(InstituicaoParceiraFilter filtro, Pageable pageable);

	void salvar(InstituicaoParceira instituicaoParceira);

	void excluir(InstituicaoParceira instituicaoParceira);

	
}
