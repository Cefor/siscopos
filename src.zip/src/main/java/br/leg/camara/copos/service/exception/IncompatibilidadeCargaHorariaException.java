package br.leg.camara.copos.service.exception;

public class IncompatibilidadeCargaHorariaException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public IncompatibilidadeCargaHorariaException(String message) {
		super(message);
	}

}
