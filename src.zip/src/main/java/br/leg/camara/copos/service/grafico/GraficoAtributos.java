package br.leg.camara.copos.service.grafico;

import com.google.gson.Gson;

public class GraficoAtributos {

	private String tipoGrafico;
	private String labels_x;
		
	private String titulo1;
	private String dados1;
	private String corFundo1;
		
	private String titulo2;
	private String dados2;
	private String corFundo2;
	
	public GraficoAtributos() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public GraficoAtributos(String tipoGrafico, String labels_x, String titulo1, String dados1, String corFundo1,
			String titulo2, String dados2, String corFundo2) {
		super();
		this.tipoGrafico = tipoGrafico;
		this.labels_x = labels_x;
		this.titulo1 = titulo1;
		this.dados1 = dados1;
		this.corFundo1 = corFundo1;
		this.titulo2 = titulo2;
		this.dados2 = dados2;
		this.corFundo2 = corFundo2;
	}

	public String getTipoGrafico() {
		return tipoGrafico;
	}
	public void setTipoGrafico(String tipoGrafico) {
		this.tipoGrafico = tipoGrafico;
	}
	public String getLabels_x() {
		return labels_x;
	}
	public void setLabels_x(String labels_x) {
		this.labels_x = labels_x;
	}
	public String getTitulo1() {
		return titulo1;
	}
	public void setTitulo1(String titulo1) {
		this.titulo1 = titulo1;
	}
	public String getDados1() {
		return dados1;
	}
	public void setDados1(String dados1) {
		this.dados1 = dados1;
	}
	public String getCorFundo1() {
		return corFundo1;
	}
	public void setCorFundo1(String corFundo1) {
		this.corFundo1 = corFundo1;
	}
	public String getTitulo2() {
		return titulo2;
	}
	public void setTitulo2(String titulo2) {
		this.titulo2 = titulo2;
	}
	public String getDados2() {
		return dados2;
	}
	public void setDados2(String dados2) {
		this.dados2 = dados2;
	}
	public String getCorFundo2() {
		return corFundo2;
	}
	public void setCorFundo2(String corFundo2) {
		this.corFundo2 = corFundo2;
	}
	
	@Override
	public String toString() {
		return "GraficoAtributos [tipoGrafico=" + tipoGrafico + ", labels_x=" + labels_x + ", titulo1=" + titulo1
				+ ", dados1=" + dados1 + ", corFundo1=" + corFundo1 + ", titulo2=" + titulo2 + ", dados2=" + dados2
				+ ", corFundo2=" + corFundo2 + "]";
	}
	
	
	public String toJSON() {
		Gson gson = new Gson();
		
		String atributos = "tipoGrafico=" + tipoGrafico + ";labels_x=" + labels_x + ";titulo1=" + titulo1
				+ ";dados1=" + dados1 + ";corFundo1=" + corFundo1 + ";titulo2=" + titulo2 + ";dados2=" + dados2
				+ ";corFundo2=" + corFundo2;
		
		String[] keyValuePairs = atributos.split(";");
		
        Object[] objects = new Object[keyValuePairs.length];
        for (int i = 0; i < keyValuePairs.length; i++) {
            String[] keyValuePair = keyValuePairs[i].split("=");
            if(keyValuePair.length > 1) {
            	objects[i] = keyValuePair[1];
            } else {
            	objects[i] = " ";
            }
        }

        // Converte a lista de objetos JSON em uma string JSON
        return gson.toJson(objects);
	}
	
}
