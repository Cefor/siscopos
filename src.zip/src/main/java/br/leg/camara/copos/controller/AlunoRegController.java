package br.leg.camara.copos.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.bridge.AlunoRegNovo;
import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.enums.Sexo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;
import br.leg.camara.copos.report.HistoricoReport;
import br.leg.camara.copos.repository.Alunos;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.CursosLinhasPesquisa;
import br.leg.camara.copos.repository.ProfessoresSituacoes;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.SituacoesProfessores;
import br.leg.camara.copos.repository.filter.AlunoRegFilter;
import br.leg.camara.copos.service.AlunoRegService;
import br.leg.camara.copos.service.exception.AlunoJaCadastradoException;
import br.leg.camara.copos.service.exception.DatasAlunoRegException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.MatriculaObrigatoriaException;
import br.leg.camara.copos.service.exception.PessoaObrigatoriaException;

@Controller
@RequestMapping("/alunosreg")
public class AlunoRegController {

	@Autowired
	private AlunoRegService alunoRegService;

	@Autowired
	private Cursos cursos;
	
	@Autowired
	private Semestres semestres;
	
	@Autowired
	private CursosLinhasPesquisa cursosLinhasPesquisa;

	@Autowired
	private ProfessoresSituacoes professoresSituacoes;
	
	@Autowired
	private SituacoesProfessores situacoesProfessor;
	
	@Autowired
	private AlunosReg alunosReg;
	
	@Autowired
	private Alunos alunos;

	@Autowired
	private HistoricoReport historicoReport;
	
    @Value("${pasta.raiz.origem}")
    private String pastaRaizOrigem;
    
    @Value("${pasta.raiz.espelho}")
    private String pastaRaizEspelho;
    
    @Value("${pasta.pessoas}")
    private String pastaPessoas;
    
    @Value("${pasta.ofertas}")
    private String pastaOfertas;

    
	@GetMapping(value = {"", "/matricula"})
	public ModelAndView pesquisar(AlunoRegFilter alunoRegFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		
		ModelAndView mv = new ModelAndView("alunoreg/PesquisaAlunoReg");
		alunoRegFilter.setFlagMatricula(false);

		mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
		mv.addObject("simnao", SimNao.values());
		
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaPessoas", pastaPessoas);
	
		PageWrapper<AlunoReg> paginaWrapper = new PageWrapper<>(alunoRegService.filtrar(alunoRegFilter, pageable),
				httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}

	
	@RequestMapping("/novo/{idCurso}")
	// nao importa o nome no parametro, o objeto na camada view (Thymeleaf)
	// eh nominado com base no nome da classe, no caso abaixo, alunoRegNovo
	// Entao eh boa pratica aplicar essa regra dando um nome igual ao
	// parametro
	// public ModelAndView novo(AlunoRegNovo qqcoisa) { pode ser assim (qqcoisa) que na view o nome sera alunoRegNovo
	public ModelAndView novo(AlunoRegNovo alunoRegNovo, @PathVariable Long idCurso) {
		ModelAndView mv = new ModelAndView("alunoreg/CadastroAlunoReg");
		
		alunoRegNovo.setCurso(cursos.findById(idCurso).get());
		alunoRegNovo.setDataIngresso(LocalDate.now());
		// alunoRegNovo.setPrazoConclusao(LocalDate.now().plusMonths(30));
		
		mv.addObject("semestres", semestres.findByFlagMatriculaOrderByAnoDescSemestreDesc(SimNao.S));
		mv.addObject("cursoLinhas", cursosLinhasPesquisa.findByCurso(alunoRegNovo.getCurso()));
		mv.addObject("professores", professoresSituacoes.
				findByDataFimAndProfessorCursoAndSituacaoProfessorNotOrderByProfessorPessoaNome(null, alunoRegNovo.getCurso(),situacoesProfessor.findBySituacao("Inativo")));
		mv.addObject("opcoespag", SimNao.values());
		
		return mv;
	}


	@PostMapping("/salvarnovo")
	public ModelAndView salvar(@Valid AlunoRegNovo alunoRegNovo, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return novo(alunoRegNovo, alunoRegNovo.getCurso().getId());
		}
	
		try {
			alunoRegService.salvar(alunoRegNovo);
		} catch (PessoaObrigatoriaException e) {
			result.rejectValue("pessoa", e.getMessage(), e.getMessage());
			return novo(alunoRegNovo, alunoRegNovo.getCurso().getId());
		} catch (AlunoJaCadastradoException e) {
			result.rejectValue("pessoa", e.getMessage(), e.getMessage());
			return novo(alunoRegNovo, alunoRegNovo.getCurso().getId());
		} catch (MatriculaObrigatoriaException e) {
			result.rejectValue("matricula", e.getMessage(), e.getMessage());
			return novo(alunoRegNovo, alunoRegNovo.getCurso().getId());
		} catch (Exception e) {
			// pega apenas o conteudo de messageTemplate da mensagem padrao
	        Pattern pattern = Pattern.compile("messageTemplate='([^']*)'"); 
	        Matcher matcher = pattern.matcher(e.getMessage());

	        String mensagem = e.getMessage();
	        if (matcher.find()) {
	            mensagem = matcher.group(1);
	        } 
			
			result.rejectValue(null, mensagem, mensagem);
			return novo(alunoRegNovo, alunoRegNovo.getCurso().getId());
		} 
 
		String artigo = "o";
		if(alunoRegNovo.getPessoa().getSexo().equals(Sexo.F)) {
			artigo = "a";
		}
		
		attributes.addFlashAttribute("mensagem", "Alun" + artigo + " regular " + alunoRegNovo.getPessoa().getNome() + " (" + alunoRegNovo.getMatricula() + ") salv" + artigo + " com sucesso!");
		return new ModelAndView("redirect:/alunosreg/novo/" + alunoRegNovo.getCurso().getId());
	}
	
	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(AlunoReg alunoReg, @PathVariable Long id) {
		ModelAndView mv = new ModelAndView("alunoreg/EdicaoAlunoReg");

		// alunoReg tem campos vazios qdo vem do icone editar na pagina de pesquisa
		// e eh preciso instanciar alunoReg a partir da PathVariable id.
		// Qdo vem de salvaEdicao, ja vem preenchido
		if(alunoReg.isAlunoNovo()) { 
			alunoReg = alunosReg.findById(id).get();
		}
		
		mv.addObject(alunoReg);
		
		//mv.addObject("semestres", semestres.findByOrderByAnoDescSemestreDesc()); // nao permito editar semestre
		mv.addObject("cursoLinhas", cursosLinhasPesquisa.findByCurso(alunoReg.getAluno().getCurso()));
		mv.addObject("professoresSituacao", professoresSituacoes.
				findByDataFimAndProfessorCursoOrderByProfessorPessoaNome(null, alunoReg.getAluno().getCurso()));
		mv.addObject("opcoespag", SimNao.values());
		
		return mv;
	}

	
	@PostMapping("/salvaredicao")
	public ModelAndView salvarEdicao(@Valid AlunoReg alunoReg, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return editar(alunoReg, null);
		}
	
		try {
			alunoRegService.salvarEdicao(alunoReg);
		} catch (MatriculaObrigatoriaException e) {
			result.rejectValue("matricula", e.getMessage(), e.getMessage());
			return editar(alunoReg, null);
		}  catch (DatasAlunoRegException e) {
			result.rejectValue("dataHomologacao", e.getMessage(), e.getMessage());
			return editar(alunoReg, null);
		}  

		attributes.addFlashAttribute("mensagem", "Aluno regular salvo com sucesso");
		return new ModelAndView("redirect:/alunosreg/novo/" + alunoReg.getAluno().getCurso().getId());
		
	}

	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") AlunoReg alunoReg) {
		try {
			alunoRegService.excluir(alunoReg);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}

	
	@GetMapping("/historico/{idAluno}")
	public ModelAndView historico(@PathVariable Long idAluno) {
		ModelAndView mv = new ModelAndView("alunoreg/Historico");
		
		mv.addObject("nomeCurso", alunos.findById(idAluno).get().getCurso().getNome());
		mv.addObject("siglaCurso", alunos.findById(idAluno).get().getCurso().getSigla());
		mv.addObject("aluno", alunos.findById(idAluno).get());
		mv.addObject("tituloTCC", alunosReg.findByAluno(alunos.findById(idAluno).get()).get().getTituloTCC());
		if(alunosReg.findByAluno(alunos.findById(idAluno).get()).get().getOrientador() != null) {
			mv.addObject("orientador", alunosReg.findByAluno(alunos.findById(idAluno).get()).get().getOrientador().getPessoa().getNome());	
		} else {
			mv.addObject("orientador", "");
		}
		mv.addObject("disciplinas", alunoRegService.historico(idAluno));
		
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaOfertas", pastaOfertas);
		
		return mv;
	}
	
	
	@GetMapping("/gerarPDF/{idAluno}")
	public void gerarPDF(@PathVariable Long idAluno, HttpServletResponse response) throws IOException {
	    response.setContentType("application/pdf");
	    response.setHeader("Content-Disposition", "attachment; filename=\"" + "Historico_" + alunos.findById(idAluno).get().getPessoa().getNome() + ".pdf\"");

	    Aluno aluno = alunos.findById(idAluno).get();

	    historicoReport.imprimir(response, aluno);
	}
    
	
	@GetMapping("/periodo")
	public ModelAndView pesquisarPorMatriculaPeriodo(
	        AlunoRegFilter alunoRegFilter,
	        BindingResult result,
	        @PageableDefault(size = 15) Pageable pageable,
	        HttpServletRequest httpServletRequest,
	        HttpServletResponse response) throws IOException {

	    // Obter o formato solicitado (html ou csv) a partir do parâmetro da requisição
	    String formato = httpServletRequest.getParameter("formato");

	    // Obter os dados filtrados
	    PageWrapper<Matricula> paginaWrapper = new PageWrapper<>(
	            alunoRegService.filtrarMatriculaPeriodo(alunoRegFilter, pageable),
	            httpServletRequest);

	    
	    if ("csv".equalsIgnoreCase(formato)) {
	        // Carregar todos os registros ignorando a paginação
	        List<Matricula> todasAsMatriculas = alunoRegService.filtrarTodos(alunoRegFilter);
	        exportarParaCsv(response, todasAsMatriculas);
	        return null; // Encerrar a execução após exportar o arquivo
	    }


	    // Renderizar a página HTML caso o formato seja diferente de CSV ou nulo
	    ModelAndView mv = new ModelAndView("alunoreg/PesquisaAlunoRegPeriodo");
	    mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
	    mv.addObject("semestres", semestres.findByOrderByAnoDescSemestreDesc());
	    mv.addObject("situacoesAlunoReg", SituacaoAlunoReg.values());
	    mv.addObject("pagina", paginaWrapper);

	    return mv;
	}

	/**
	 * Método auxiliar para exportar os dados para CSV.
	*/
	private void exportarParaCsv(HttpServletResponse response, List<Matricula> matriculas) throws IOException {
	    response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"matriculasRegulares.csv\"");

	    try (PrintWriter writer = response.getWriter()) {
	        // Cabeçalho do arquivo CSV
	        writer.println("Curso;Nome;Situação;CPF;Matrícula;IdLattes;Semestre;Telefone;e-mail");

	        // Iterar pelos registros de matrícula e escrever no arquivo CSV
	        for (Matricula matricula : matriculas) {
	            writer.println(String.format("%s;%s;%s;%s;%s;%s;%s;%s;%s",
	                    matricula.getAluno().getCurso().getSigla(),
	                    matricula.getAluno().getPessoa().getNome(),
	                    matricula.getAlunoReg().getSituacaoAlunoReg().getDescricao(),
	                    matricula.getAluno().getPessoa().getCpf(),
	                    matricula.getAlunoReg().getMatricula(),
	                    matricula.getAluno().getPessoa().getUrlLattes().replaceAll("[^0-9]", ""),
	                    matricula.getSemestre().getPeriodo(),
	                    matricula.getAluno().getPessoa().getTelefone(),
	                    matricula.getAluno().getPessoa().getEmail()
	            		));
	        }

	        writer.flush();
	    }
	}

	/*
	private void exportarParaCsv(HttpServletResponse response, List<Matricula> matriculas) throws IOException {
	    // Configurar o tipo de conteúdo e a codificação da resposta
	    response.setContentType("text/csv; charset=UTF-8");
	    response.setHeader("Content-Disposition", "attachment; filename=\"matriculas.csv\"");
	    response.setCharacterEncoding("UTF-8");

	    // Escrever os dados usando UTF-8
	    try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(response.getOutputStream(), "UTF-8"), true)) {
	        // Cabeçalho do arquivo CSV
	        writer.println("Curso;Nome;CPF;Matrícula;Semestre");

	        // Iterar pelos registros de matrícula e escrever no arquivo CSV
	        for (Matricula matricula : matriculas) {
	            writer.println(String.format("%s;%s;%s;%s;%s",
	                    matricula.getAluno().getCurso().getNome(),
	                    matricula.getAluno().getPessoa().getNome(),
	                    matricula.getAluno().getPessoa().getCpf(),
	                    matricula.getAlunoReg().getMatricula(),
	                    matricula.getSemestre().getPeriodo()));
	        }

	        writer.flush();
	    }
	}
	*/
	
}
