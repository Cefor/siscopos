package br.leg.camara.copos.service.impl;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.bridge.AlunoEspMatricula;
import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.Matriculas;
import br.leg.camara.copos.repository.MatriculasDisciplinas;
import br.leg.camara.copos.repository.filter.AlunoEspFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.MatriculaAlunoEspService;
import br.leg.camara.copos.service.exception.AtingiuLimiteDisciplinasException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.InclusaoDisciplinaException;

@Service
public class MatriculaAlunoEspServiceImpl implements MatriculaAlunoEspService{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private MatriculasDisciplinas matriculasDisciplinas;
	
	@Autowired
	private AlunosReg alunosReg;

	@Autowired
	private Matriculas matriculas;
	
	
	
	
	@Override
	@Transactional
	public void salvar(AlunoEspMatricula alunoEspMatricula) {

		// verifica se eh aluno regular ativo no curso
		Optional<AlunoReg> alunoAuxReg = alunosReg.findByAlunoPessoaAndAlunoCursoAndSituacaoAlunoReg(alunoEspMatricula.getAlunoEsp().getAluno().getPessoa(), alunoEspMatricula.getAlunoEsp().getAluno().getCurso(), SituacaoAlunoReg.A);
		if(alunoAuxReg.isPresent()) {
			throw new InclusaoDisciplinaException( alunoAuxReg.get().getAluno().getPessoa().getNome() +
		                                          " tem matrícula ativa como regular (" +
		                                          alunoAuxReg.get().getMatricula() +
		                                          ")!");	
		}

		// verifica se atingiu o limite de disciplinas cursadas como especial, somando "AP", "RP" e matriculas no atual semestre
		if(matriculasDisciplinas.findByMatriculaAlunoEspAndMencaoIn(alunoEspMatricula.getAlunoEsp(), Arrays.asList("AP", "RP")).size() +
				matriculasDisciplinas.findByMatriculaAlunoEspAndOfertaSemestre(alunoEspMatricula.getAlunoEsp(), alunoEspMatricula.getOferta().getSemestre()).size() >= 
				alunoEspMatricula.getAlunoEsp().getAluno().getCurso().getLimiteOptativasEspecial()) {
			throw new AtingiuLimiteDisciplinasException("Atingiu o limite de disciplinas como aluno especial no curso.");
		}
		
		// verifica se atingiu o limite de matriculas como especial no semestre
			if(matriculasDisciplinas.findByMatriculaAlunoEspAndOfertaSemestre(alunoEspMatricula.getAlunoEsp(), alunoEspMatricula.getOferta().getSemestre()).size() >= 
					alunoEspMatricula.getAlunoEsp().getAluno().getCurso().getLimiteOptativasEspecialSemestre()) {
				throw new AtingiuLimiteDisciplinasException("Atingiu o limite de disciplinas no semestre " + alunoEspMatricula.getOferta().getSemestre().getPeriodo());
			}
		
			
		// verifica se existe registro na entidade Matricula para o semestre
		Optional<Matricula> matricula = matriculas.findByAlunoAndSemestre(
				alunoEspMatricula.getAlunoEsp().getAluno(),
				alunoEspMatricula.getOferta().getSemestre());
		
		if(!matricula.isPresent()) { // se nao existir
			matricula = Optional.ofNullable(new Matricula(
					alunoEspMatricula.getAlunoEsp().getAluno(),
					alunoEspMatricula.getAlunoEsp(),
					alunoEspMatricula.getOferta().getSemestre(),
					LocalDate.now()
					));
			
			// grava novo registro em Matricula
			matriculas.save(matricula.get());
			
		} else { // se existir, verifica se eh matricula de aluno especial
			
			if(matricula.get().getAlunoReg() != null) {
				throw new InclusaoDisciplinaException("Já existe matrícula como aluno regular no semestre " + 
						                               alunoEspMatricula.getOferta().getSemestre().getPeriodo() +
						                               ", o que não é permitido. Reveja a situação do aluno.");
			}
		}


		// verifica se a disciplina ja foi cadastrada ...
		//List<MatriculaDisciplina> matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaOrderByOfertaSemestreDesc(
		//	    alunoEspMatricula.getAlunoEsp().getAluno(), 
		//	    alunoEspMatricula.getOferta().getCursoDisciplina());
		
		// verifica se a disciplina ja foi cadastrada ...
		List<MatriculaDisciplina> matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaAndOfertaCursoDisciplinaSubtituloAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(
			    alunoEspMatricula.getAlunoEsp().getAluno(), 
			    alunoEspMatricula.getOferta().getCursoDisciplina(),
			    alunoEspMatricula.getOferta().getCursoDisciplinaSubtitulo()
			    );
		
		
		// para o registro mais recente, verifica se houve aprovacao ou se ja esta matriculado na disciplina sendo inserida
		if(matDisciplinas.size() > 0) {
			if((matDisciplinas.get(0).getMencao() == null) ||     // ja esta matriculado na disciplina
				matDisciplinas.get(0).getMencao().isEmpty()) {  

					throw new InclusaoDisciplinaException("Registro de matrícula existente: " + 
							matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
							matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getNome() + " - " +
  				            matDisciplinas.get(0).getOferta().getTurma() +  
			               (matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo() != null ? " - " + matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getSigla() : "")
  				    );
					
			} else if(matDisciplinas.get(0).getMencao().equals("AP")) {  // ja foi aprovado na disciplina
				
				throw new InclusaoDisciplinaException("Disciplina cursada com aprovação: " +
						matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getNome() + " - " +
						matDisciplinas.get(0).getOferta().getTurma() +
						(matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo() != null ? " - " + matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getSigla() : "")
						);
				
			} 
		}

		
		// verifica se estah se matriculando em optativa que ja foi subtitulo
		matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaSubtituloAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(
			    alunoEspMatricula.getAlunoEsp().getAluno(), 
			    alunoEspMatricula.getOferta().getCursoDisciplina());

		if(matDisciplinas.size() > 0) {
			if(matDisciplinas.get(0).getMencao().equals("AP")){
				throw new InclusaoDisciplinaException("Disciplina já cursada com aprovação: " + 
						matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getSigla() + " - " +
						matDisciplinas.get(0).getOferta().getTurma() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getSigla()
						);
			}
		}
		
		// verifica se estah se matriculando em subtitulo que ja foi optativa		
		matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(
			    alunoEspMatricula.getAlunoEsp().getAluno(), 
			    alunoEspMatricula.getOferta().getCursoDisciplinaSubtitulo());
		
		if(matDisciplinas.size() > 0) {
			if(matDisciplinas.get(0).getMencao().equals("AP")){
				throw new InclusaoDisciplinaException("Disciplina já cursada com aprovação: " + 
						matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getSigla() + " - " +
						matDisciplinas.get(0).getOferta().getTurma()
						);
			}
		}
				
		// verifica violacao de indice unico: (matricula, oferta)
		if(matriculasDisciplinas.findByMatriculaAndOferta(matricula.get(), alunoEspMatricula.getOferta()).isPresent()) {
			throw new InclusaoDisciplinaException("Disciplina '" +
												   alunoEspMatricula.getOferta().getCursoDisciplina().getDisciplina().getNome() +
												  "' já cadastrada no semestre " +
												  alunoEspMatricula.getOferta().getSemestre().getPeriodo());
		}
		
		MatriculaDisciplina matriculaDisciplina = new MatriculaDisciplina(
					matricula.get(),
					alunoEspMatricula.getOferta(),
					(float) 0
				);   
		
		matriculasDisciplinas.save(matriculaDisciplina);
	}

	
	@Override
	@Transactional
	public void excluir(MatriculaDisciplina matriculaDisciplina) {
		try {
			matriculasDisciplinas.delete(matriculaDisciplina);
			matriculasDisciplinas.flush();
			
			// se nao existirem mais disciplinas no semestre corrente para o aluno, apaga o registro em matricula
			if(matriculasDisciplinas.findByMatriculaAlunoAndOfertaSemestre(matriculaDisciplina.getMatricula().getAluno(), matriculaDisciplina.getOferta().getSemestre()).size() == 0) {
				matriculas.delete(matriculaDisciplina.getMatricula());
				matriculas.flush();
			}
			
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Disciplina já foi associada a outra entidade.");
		}
	}
	

	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<AlunoEsp> filtrar(AlunoEspFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoEsp.class);
		
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<AlunoEsp> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	
	private void adicionarFiltro(AlunoEspFilter filtro, Criteria criteria) {
		
		// os alunos regulares ativos do curso
		List<AlunoReg> listaAlunoReg = alunosReg.findByAlunoCursoAndSituacaoAlunoReg(filtro.getCurso(), SituacaoAlunoReg.A);
		if(listaAlunoReg.size() > 0) {
			List<Aluno> listaAluno = listaAlunoReg.stream().map(AlunoReg::getAluno).collect(Collectors.toList());
			criteria.add(Restrictions.not(Restrictions.in("aluno", listaAluno)));
		}
		
		criteria.add(Restrictions.or( Restrictions.isNull("dataFimRestricao"),
				                      Restrictions.lt("dataFimRestricao", LocalDate.now())));
		
		Criteria alunoCrit = criteria.createCriteria("aluno");
		alunoCrit.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		alunoCrit.createAlias("curso", "c", JoinType.LEFT_OUTER_JOIN);
		
		alunoCrit.addOrder(Order.asc("p.nome"));
		alunoCrit.addOrder(Order.asc("c.nome"));
		
		if (filtro != null) {
	
			if (!StringUtils.isEmpty(filtro.getNome())) {
				alunoCrit.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCurso())) {
				alunoCrit.add(Restrictions.eq("curso", filtro.getCurso()));
				criteria.add(Restrictions.lt("qtdDisciplinasCursadas",filtro.getCurso().getLimiteOptativasEspecial()));
			}
						
			if (!StringUtils.isEmpty(filtro.getCpf())) {
				alunoCrit.add(Restrictions.ilike("p.cpf", filtro.getCpf(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getMatricula())) {
				criteria.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
			}
		}
	}
	
	
	private Long total(AlunoEspFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoEsp.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação
	
	
}
