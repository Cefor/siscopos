package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.repository.filter.OfertaFilter;

public interface OfertaService {
	
	Page<Oferta> filtrar(OfertaFilter filtro, Pageable pageable);
	
	public void salvar(Oferta oferta);

	void excluir(Oferta oferta);

}
