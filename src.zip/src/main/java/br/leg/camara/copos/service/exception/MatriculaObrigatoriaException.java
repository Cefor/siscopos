package br.leg.camara.copos.service.exception;

public class MatriculaObrigatoriaException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public MatriculaObrigatoriaException(String message) {
		super(message);
	}

}
