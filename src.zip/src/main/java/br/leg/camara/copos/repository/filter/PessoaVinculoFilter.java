package br.leg.camara.copos.repository.filter;

import java.time.LocalDate;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.entity.VinculoCD;

public class PessoaVinculoFilter {

	private Curso curso;
	private String nome;
	private SemestrePeriodo semestre;
	private VinculoCD vinculoCD; 
	private String instituicaoParceira;
	private LocalDate dataVigencia;
	private LocalDate dataFim;
	
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public SemestrePeriodo getSemestre() {
		return semestre;
	}
	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}
	public VinculoCD getVinculoCD() {
		return vinculoCD;
	}
	public void setVinculoCD(VinculoCD vinculoCD) {
		this.vinculoCD = vinculoCD;
	}
	public String getInstituicaoParceira() {
		return instituicaoParceira;
	}
	public void setInstituicaoParceira(String instituicaoParceira) {
		this.instituicaoParceira = instituicaoParceira;
	}
	public LocalDate getDataVigencia() {
		return dataVigencia;
	}
	public void setDataVigencia(LocalDate dataVigencia) {
		this.dataVigencia = dataVigencia;
	}
	public LocalDate getDataFim() {
		return dataFim;
	}
	public void setDataFim(LocalDate dataFim) {
		this.dataFim = dataFim;
	}
	
}
