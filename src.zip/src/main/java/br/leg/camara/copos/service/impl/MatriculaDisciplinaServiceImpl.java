
package br.leg.camara.copos.service.impl;

import java.util.Arrays;
import java.util.List;
import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.repository.AlunosEsp;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.MatriculasDisciplinas;
import br.leg.camara.copos.service.MatriculaDisciplinaService;

@Service
public class MatriculaDisciplinaServiceImpl implements MatriculaDisciplinaService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private MatriculasDisciplinas matriculasDisciplinas;
	
	@Autowired
	private AlunosReg alunosReg;
	
	@Autowired
	private AlunosEsp alunosEsp;
	
	
	@Override
	@Transactional
	public void salvar(MatriculaDisciplina matriculaDisciplina) {

		matriculaDisciplina.setCreditosComputados((float) 0);
		
		if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getTipo().toString().equals("DISC")) {
			
			if(!matriculaDisciplina.getMencao().equals("CS")){
	
				if(matriculaDisciplina.getNota() != null && matriculaDisciplina.getFrequencia() != null) {
					
					if(matriculaDisciplina.getNota() >= matriculaDisciplina.getMatricula().getAluno().getCurso().getNotaMinima() &&
					   matriculaDisciplina.getFrequencia() >= matriculaDisciplina.getMatricula().getAluno().getCurso().getFrequenciaMinima()) {
		
						if(matriculaDisciplina.getDataOpcaoac() == null) {
							matriculaDisciplina.setCreditosComputados((float) matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getHoras() / 15);
						}
						matriculaDisciplina.setMencao("AP");
					} else {
						matriculaDisciplina.setMencao("RP");
						matriculaDisciplina.setDataOpcaoac(null);
						
						// se for aluno especial reprovado, insere restricao de 12 meses,
						// contados a partir do ultimo dia do semestre 
						if(matriculaDisciplina.getMatricula().getAlunoEsp() != null) {
							alunosEsp.findByAluno(matriculaDisciplina.getMatricula().getAluno()).get().setDataFimRestricao(
																			matriculaDisciplina.getOferta().getSemestre().getUltimoDia().plusMonths(12)
																			);
						}
						
					}
				
					if(matriculaDisciplina.getDataMencao() == null) {
						matriculaDisciplina.setDataMencao(LocalDate.now());	
					}
					
					
				} else {
					matriculaDisciplina.setMencao(null);
					matriculaDisciplina.setDataMencao(null);
					matriculaDisciplina.setDataOpcaoac(null);
					matriculaDisciplina.setNota(null);
					matriculaDisciplina.setFrequencia(null);
				}
				
			}
			
		} else {
			matriculaDisciplina.setCreditosComputados((float) matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getHoras() / 15);
		}
		
		
		// verifica se com a mencao atual computam duas reprovacoes como aluno regular
		// qdo houver dupla reprovacao, lanca data de DESLIGAMENTO
		if(matriculaDisciplina.getMatricula().getAlunoReg() != null &&
				matriculaDisciplina.getMencao().equals("RP")) {
			
			List<MatriculaDisciplina> matDisc = matriculasDisciplinas.findByMatriculaAlunoRegAndMencao(
					matriculaDisciplina.getMatricula().getAlunoReg(),
					"RP"
					);
			
			if(matDisc.size() >= 1) {

				// se ja tinha sido desligado, mantem a data de desligamento
				// caso contrario, desliga com data de hoje
				if(matriculaDisciplina.getMatricula().getAlunoReg().getDataDesligamento() == null) {
					matriculaDisciplina.getMatricula().getAlunoReg().setDataDesligamento(LocalDate.now());	
				}
				
				// cancela reativacao caso haja
				matriculaDisciplina.getMatricula().getAlunoReg().setDataReativacao(null);
				
				alunosReg.save(matriculaDisciplina.getMatricula().getAlunoReg());
			}
		}

		matriculasDisciplinas.save(matriculaDisciplina);
		
		// incluir a quantidade de disciplinas cursadas como especial
		if(matriculaDisciplina.getMatricula().getAlunoEsp() != null) {

			// os dois codigos funcionam
			/*
			matriculaDisciplina.getMatricula().getAlunoEsp().setQtdDisciplinasCursadas(
					matriculasDisciplinas.findByMatriculaAlunoEspAndMencaoIn(matriculaDisciplina.getMatricula().getAlunoEsp(), Arrays.asList("AP", "RP")).size()
					);
			
			alunosEsp.save(matriculaDisciplina.getMatricula().getAlunoEsp());
			*/
			
			alunosEsp.findById(matriculaDisciplina.getMatricula().getAlunoEsp().getId()).get().setQtdDisciplinasCursadas(
					matriculasDisciplinas.findByMatriculaAlunoEspAndMencaoIn(matriculaDisciplina.getMatricula().getAlunoEsp(), Arrays.asList("AP", "RP")).size()
					);
			
		}

	}
	

}
