package br.leg.camara.copos.service;

import br.leg.camara.copos.model.entity.MatriculaDisciplina;

public interface MatriculaDisciplinaService {
	
	public void salvar(MatriculaDisciplina matriculaDisciplina);

}
