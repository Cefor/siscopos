package br.leg.camara.copos.service.exception;

public class SituacaoProfessorException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public SituacaoProfessorException(String message) {
		super(message);
	}

}
