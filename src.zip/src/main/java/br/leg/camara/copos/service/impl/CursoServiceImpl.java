package br.leg.camara.copos.service.impl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.repository.AlunosEsp;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.filter.CursoFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.CursoService;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.LimiteOptativasEspecialException;
import br.leg.camara.copos.service.exception.LimiteOptativasEspecialSemestreException;

@Service
public class CursoServiceImpl implements CursoService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private Cursos cursos;
	
	@Autowired
	private AlunosEsp alunosEsp;
	
	
	
	
	@Override
	@Transactional
	public void salvar(Curso curso) {
		
		if(curso.getLimiteOptativasEspecialSemestre() > curso.getLimiteOptativasEspecial()) {
			throw new LimiteOptativasEspecialSemestreException("O limite de optativas como especial por semestre não pode ser maior que o limite de optativas como especial no curso.");
		}
		
		if(!curso.isNovo() &&
				curso.getLimiteOptativasEspecial() == 0 && 
				alunosEsp.findByAlunoCurso(curso).size() > 0) {
			throw new LimiteOptativasEspecialException("Já existe aluno especial associado ao curso " + curso.getNome());
		}
				
		cursos.save(curso);
	}
	
	
	@Override
	@Transactional
	public void excluir(Curso curso) {
		try {
			cursos.delete(curso);
			cursos.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Curso já foi associado a outra entidade.");
		}
	}

	
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Curso> filtrar(CursoFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Curso.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<Curso> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	private void adicionarFiltro(CursoFilter filtro, Criteria criteria) {
		
		if (filtro != null) {
			
			if (!StringUtils.isEmpty(filtro.getSigla())) {
				criteria.add(Restrictions.ilike("sigla", filtro.getSigla(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getGrau())) {
				criteria.add(Restrictions.eq("grau", filtro.getGrau()));
			}
			
		}
	}
	
	private Long total(CursoFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Curso.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação
	
}
