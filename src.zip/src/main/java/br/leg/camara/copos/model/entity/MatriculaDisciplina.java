package br.leg.camara.copos.model.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "matricula_disciplina")
public class MatriculaDisciplina implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_matricula")
	private Matricula matricula;
	
	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_oferta")
	private Oferta oferta;
	
    @Max(value = 10, message = "O valor máximo permitido para a nota é 10")
	@Column(name = "nota")
	private Float nota;
	
    @Max(value = 100, message = "O valor máximo permitido para a frequência é 100%")
	@Column(name = "frequencia")
	private Float frequencia;

	@Column(name = "mencao")
	private String mencao;
	
	@Column(name = "data_mencao")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataMencao;
	
	@Column(name = "data_opcaoac")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataOpcaoac;
	
	//@NotNull(message = "Obrigatório informar qtd. de créditos computados")
	@Column(name = "creditos_computados")
	private Float creditosComputados;

	
	public MatriculaDisciplina() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MatriculaDisciplina(Matricula matricula, Oferta oferta, Float creditosComputados) {
		super();
		this.matricula = matricula;
		this.oferta = oferta;
		this.creditosComputados = creditosComputados;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Matricula getMatricula() {
		return matricula;
	}

	public void setMatricula(Matricula matricula) {
		this.matricula = matricula;
	}

	public Oferta getOferta() {
		return oferta;
	}

	public void setOferta(Oferta oferta) {
		this.oferta = oferta;
	}

	public Float getNota() {
		return nota;
	}

	public void setNota(Float nota) {
		this.nota = nota;
	}

	public Float getFrequencia() {
		return frequencia;
	}

	public void setFrequencia(Float frequencia) {
		this.frequencia = frequencia;
	}

	public String getMencao() {
		return mencao;
	}

	public void setMencao(String mencao) {
		this.mencao = mencao;
	}

	public LocalDate getDataMencao() {
		return dataMencao;
	}

	public void setDataMencao(LocalDate dataMencao) {
		this.dataMencao = dataMencao;
	}

	public LocalDate getDataOpcaoac() {
		return dataOpcaoac;
	}

	public void setDataOpcaoac(LocalDate dataOpcaoac) {
		this.dataOpcaoac = dataOpcaoac;
	}

	public Float getCreditosComputados() {
		return creditosComputados;
	}

	public void setCreditosComputados(Float creditosComputados) {
		this.creditosComputados = creditosComputados;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "MatriculaDisciplina [id=" + id + ", matricula=" + matricula + ", oferta=" + oferta + ", nota=" + nota
				+ ", frequencia=" + frequencia + ", mencao=" + mencao + ", dataMencao=" + dataMencao + ", dataOpcaoac="
				+ dataOpcaoac + ", creditosComputados=" + creditosComputados + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(creditosComputados, dataMencao, dataOpcaoac, frequencia, id, matricula, mencao, nota,
				oferta);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MatriculaDisciplina other = (MatriculaDisciplina) obj;
		return Objects.equals(creditosComputados, other.creditosComputados)
				&& Objects.equals(dataMencao, other.dataMencao) && Objects.equals(dataOpcaoac, other.dataOpcaoac)
				&& Objects.equals(frequencia, other.frequencia) && Objects.equals(id, other.id)
				&& Objects.equals(matricula, other.matricula) && Objects.equals(mencao, other.mencao)
				&& Objects.equals(nota, other.nota) && Objects.equals(oferta, other.oferta);
	}

}
