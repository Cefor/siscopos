package br.leg.camara.copos.model.bridge;

import java.time.LocalDate;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.SemestrePeriodo;

public class AlunoEspNovo {

	private Long id;
	private Curso curso;
	private Pessoa pessoa;
	private String matricula;
	private SemestrePeriodo semestre;
	private LocalDate dataFimRestricao;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public Pessoa getPessoa() {
		return pessoa;
	}
	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public SemestrePeriodo getSemestre() {
		return semestre;
	}
	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}
	public LocalDate getDataFimRestricao() {
		return dataFimRestricao;
	}
	public void setDataFimRestricao(LocalDate dataFimRestricao) {
		this.dataFimRestricao = dataFimRestricao;
	}
	
}
