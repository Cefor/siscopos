package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.OfertaProfessor;
import br.leg.camara.copos.model.entity.Professor;
import br.leg.camara.copos.repository.filter.DisciplinaMinistradaFilter;
import br.leg.camara.copos.repository.filter.OrientacaoFilter;
import br.leg.camara.copos.repository.filter.ProfessorFilter;

public interface ProfessorService {
	
	Page<Professor> filtrar(ProfessorFilter filtro, Pageable pageable);

	Page<AlunoReg> orientacoes(OrientacaoFilter orientacaoFilter, Pageable pageable);

	Page<OfertaProfessor> disciplinas(DisciplinaMinistradaFilter filtro, Pageable pageable);

	void salvar(Professor professor);

	void excluir(Professor professor);

}
