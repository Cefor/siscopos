package br.leg.camara.copos.model.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import br.leg.camara.copos.model.enums.TipoDisciplina;

@Entity
@Table(name = "disciplina")
public class Disciplina {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Tipo da disciplina é obrigatório")
	@Column(name = "tipo")
	@Enumerated(EnumType.STRING)
	private TipoDisciplina tipo;
	
	@NotBlank(message = "Sigla da disciplina é obrigatória")
	@Column(name = "sigla", length = 10)
	private String sigla;
	
	@NotBlank(message = "Nome da disciplina é obrigatório")
	@Column(name = "nome")
	private String nome;
	
	@NotNull(message = "Informação de horas é obrigatória")
	@Column(name = "horas")
	private Integer horas;

	@NotNull(message = "Grau do curso é obrigatório")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_grau_curso")
	private GrauCurso grauCurso;
		
	public boolean isNova() {
		return id == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TipoDisciplina getTipo() {
		return tipo;
	}

	public void setTipo(TipoDisciplina tipo) {
		this.tipo = tipo;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getHoras() {
		return horas;
	}

	public void setHoras(Integer horas) {
		this.horas = horas;
	}

	public GrauCurso getGrauCurso() {
		return grauCurso;
	}

	public void setGrauCurso(GrauCurso grauCurso) {
		this.grauCurso = grauCurso;
	}

	@Override
	public String toString() {
		return "Disciplina [id=" + id + ", tipo=" + tipo + ", sigla=" + sigla + ", nome=" + nome + ", horas=" + horas
				+ ", grauCurso=" + grauCurso + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(grauCurso, horas, id, nome, sigla, tipo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Disciplina other = (Disciplina) obj;
		return Objects.equals(grauCurso, other.grauCurso) && Objects.equals(horas, other.horas)
				&& Objects.equals(id, other.id) && Objects.equals(nome, other.nome)
				&& Objects.equals(sigla, other.sigla) && tipo == other.tipo;
	}

}
