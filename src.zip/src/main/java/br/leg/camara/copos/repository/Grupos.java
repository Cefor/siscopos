package br.leg.camara.copos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Grupo;

public interface Grupos extends JpaRepository<Grupo, Long> {

}
