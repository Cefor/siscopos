package br.leg.camara.copos.service.impl;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.repository.Pessoas;
import br.leg.camara.copos.repository.filter.PessoaFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.PessoaService;
import br.leg.camara.copos.service.exception.CpfJaCadastradoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Service
public class PessoaServiceImpl implements PessoaService {

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;

	
	
	@Autowired
	private Pessoas pessoas;
	
	@Override
	@Transactional
	public Pessoa salvar(Pessoa pessoa) {
		
		if(pessoa.getCpf() != null){
		
			Optional<Pessoa> pessoaExistente = pessoas.findByCpf(pessoa.retornaCpfSemFormatacao());
			if (pessoaExistente.isPresent() && !pessoaExistente.get().equals(pessoa)) {
				throw new CpfJaCadastradoException("CPF já cadastrado");
			}
		
		}
		
		if(pessoa.getNacionalidade().isEmpty()) {
			pessoa.setNacionalidade("Brasileira");
		}
		
		return pessoas.save(pessoa);
	}

	
	@Override
	@Transactional
	public void excluir(Pessoa pessoa) {
		try {
			pessoas.delete(pessoa);
			pessoas.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Pessoa já foi associada a outra entidade.");
		}
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public Page<Pessoa> filtrar(PessoaFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Pessoa.class);
		
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		criteria.createAlias("endereco.cidade", "c", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("c.estado", "e", JoinType.LEFT_OUTER_JOIN);		
				
		return new PageImpl<>(criteria.list(), pageable, total(filtro));
	}
	
	private void adicionarFiltro(PessoaFilter filtro, Criteria criteria) {
		if (filtro != null) {
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCpf())) {
				criteria.add(Restrictions.ilike("cpf", filtro.getCpf(), MatchMode.ANYWHERE));
			}
		}
	}
	
	private Long total(PessoaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Pessoa.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	
}
