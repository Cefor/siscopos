package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.CursoLinhaPesquisa;
import br.leg.camara.copos.model.entity.LinhaPesquisa;

public interface CursosLinhasPesquisa extends JpaRepository<CursoLinhaPesquisa, Long> {
	
	public List<CursoLinhaPesquisa> findByCurso(Curso curso);
	
	public Optional<CursoLinhaPesquisa> findByCursoAndLinhaPesquisa(Curso curso, LinhaPesquisa linhaPesquisa);
	
}
