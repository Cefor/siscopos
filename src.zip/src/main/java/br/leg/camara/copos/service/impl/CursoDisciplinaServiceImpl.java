package br.leg.camara.copos.service.impl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.CursoDisciplina;
import br.leg.camara.copos.repository.CursosDisciplinas;
import br.leg.camara.copos.repository.filter.CursoDisciplinaFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.CursoDisciplinaService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Service
public class CursoDisciplinaServiceImpl implements CursoDisciplinaService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;

	@Autowired
	private CursosDisciplinas cursosDisciplinas;


	
	@Override
	@Transactional
	public void salvar(CursoDisciplina cursoDisciplina) {
		
		if(cursoDisciplina.isNova() &&
				cursosDisciplinas.findByCursoAndDisciplina(cursoDisciplina.getCurso(), cursoDisciplina.getDisciplina()).isPresent()) {
			throw new DuplicidadeIndiceUnicoException("Disciplina já associada ao curso.");
		}
		
		cursosDisciplinas.save(cursoDisciplina);
	}
	
	
	@Override
	@Transactional
	public void excluir(CursoDisciplina cursoDisciplina) {
		try {
			cursosDisciplinas.delete(cursoDisciplina);
			cursosDisciplinas.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Disciplina já foi associad a outra entidade.");
		}
	}
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<CursoDisciplina> filtrar(CursoDisciplinaFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(CursoDisciplina.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<CursoDisciplina> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
		
	private void adicionarFiltro(CursoDisciplinaFilter filtro, Criteria criteria) {

		criteria.createAlias("curso", "c", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("disciplina", "d", JoinType.LEFT_OUTER_JOIN);
		criteria.addOrder(Order.asc("c.nome"));
		criteria.addOrder(Order.asc("d.nome"));
		
		if (filtro != null) {
			
			if (!StringUtils.isEmpty(filtro.getCurso())) {
				criteria.add(Restrictions.eq("curso", filtro.getCurso()));
			}

			if (!StringUtils.isEmpty(filtro.getSiglaDisciplina())) {
				criteria.add(Restrictions.ilike("d.sigla", filtro.getSiglaDisciplina(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getNomeDisciplina())) {
				criteria.add(Restrictions.ilike("d.nome", filtro.getNomeDisciplina(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getTipoDisciplina())) {
				criteria.add(Restrictions.eq("d.tipo", filtro.getTipoDisciplina()));
			}

			if (!StringUtils.isEmpty(filtro.getApelidoLinhaPesquisa())) {
				Criteria cursoLinhaPesquisaCrit = criteria.createCriteria("cursoLinhaPesquisa");
				Criteria linhaPesquisaCrit = cursoLinhaPesquisaCrit.createCriteria("linhaPesquisa");
				linhaPesquisaCrit.add(Restrictions.ilike("apelido", filtro.getApelidoLinhaPesquisa(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getFlagObrigatoria())) {
				criteria.add(Restrictions.eq("flagObrigatoria", filtro.getFlagObrigatoria()));
			}
			
			if (!StringUtils.isEmpty(filtro.getFlagAtiva())) {
				criteria.add(Restrictions.eq("flagAtiva", filtro.getFlagAtiva()));
			}
			
		}
	}
	
	private Long total(CursoDisciplinaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(CursoDisciplina.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação
	
}
