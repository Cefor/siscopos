package br.leg.camara.copos.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Professor;
import br.leg.camara.copos.model.entity.ProfessorSituacao;
import br.leg.camara.copos.model.entity.SituacaoProfessor;

public interface ProfessoresSituacoes extends JpaRepository<ProfessorSituacao, Long> {
	
	public List<ProfessorSituacao> findByDataFimAndProfessorCursoOrderByProfessorPessoaNome(LocalDate dataFim, Curso curso);
	
	public List<ProfessorSituacao> findByDataFimAndProfessorCursoAndSituacaoProfessorNotOrderByProfessorPessoaNome(
			LocalDate dataFim, Curso curso, Optional<SituacaoProfessor> optional);
	
	public List<ProfessorSituacao> findByProfessorOrderByDataInicio(Professor professor);
	
	public List<ProfessorSituacao> findByProfessorOrderByDataInicioDesc(Professor professor);
	
	public List<ProfessorSituacao> findByDataFimAndProfessor(LocalDate dataFim, Professor professor);
	
	public List<ProfessorSituacao> findByProfessorAndDataInicioGreaterThanEqual(Professor professor, LocalDate dataInicio);
}
