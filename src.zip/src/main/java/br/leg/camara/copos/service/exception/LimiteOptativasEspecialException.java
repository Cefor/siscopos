package br.leg.camara.copos.service.exception;

public class LimiteOptativasEspecialException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public LimiteOptativasEspecialException(String message) {
		super(message);
	}

}
