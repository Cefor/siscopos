package br.leg.camara.copos.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.enums.Escolaridade;
import br.leg.camara.copos.model.enums.EstadoCivil;
import br.leg.camara.copos.model.enums.Sexo;
import br.leg.camara.copos.model.enums.TipoDocumento;
import br.leg.camara.copos.repository.Estados;
import br.leg.camara.copos.repository.Pessoas;
import br.leg.camara.copos.repository.filter.PessoaFilter;
import br.leg.camara.copos.service.PessoaService;
import br.leg.camara.copos.service.exception.CpfJaCadastradoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;


@Controller
@RequestMapping("/pessoas")
public class PessoaController {

	@Autowired
	private Estados estados;

	@Autowired
	private PessoaService pessoaService;
	
	@Autowired
	private Pessoas pessoas;
	
    @Value("${pasta.raiz.origem}")
    private String pastaRaizOrigem;
    
    @Value("${pasta.raiz.espelho}")
    private String pastaRaizEspelho;
    
    @Value("${pasta.pessoas}")
    private String pastaPessoas;
	

	@RequestMapping("/nova")
	public ModelAndView nova(Pessoa pessoa) {
		ModelAndView mv = new ModelAndView("pessoa/CadastroPessoa");
		mv.addObject("tiposDocumentos", TipoDocumento.values());
		mv.addObject("estados", estados.findAll());
		mv.addObject("todosSexos", Sexo.values());
		mv.addObject("todasEscolaridades", Escolaridade.values());
		mv.addObject("todosEstadosCivis", EstadoCivil.values());
		return mv;
	}

	//@PostMapping({ "/salvar", "{\\+d}" })
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid Pessoa pessoa, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(pessoa);
		}

		try {
			pessoaService.salvar(pessoa);
		} catch (CpfJaCadastradoException e) {
			result.rejectValue("cpf", e.getMessage(), e.getMessage());
			return nova(pessoa);
		}

		attributes.addFlashAttribute("mensagem", "Pessoa salva com sucesso!");
		return new ModelAndView("redirect:/pessoas/nova");
	}

	@GetMapping
	public ModelAndView pesquisar(PessoaFilter pessoaFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest,
			@RequestParam(required = false) String cpf) {

		if(cpf != null) { // quando vier de PesquisaPessoaTitulo.html
			pessoaFilter.setCpf(cpf);
		}
		
		ModelAndView mv = new ModelAndView("pessoa/PesquisaPessoas");
		
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaPessoas", pastaPessoas);

		PageWrapper<Pessoa> paginaWrapper = new PageWrapper<>(pessoaService.filtrar(pessoaFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}

	@GetMapping("/editar/{codigo}")
	public ModelAndView editar(@PathVariable Long codigo) {
		Pessoa pessoa = pessoas.findByCodigo(codigo).get();

		// http://blog.caelum.com.br/entendendo-o-lazy-e-o-eager-load-da-jpa/
		if (pessoa.getEndereco() != null) {
			if (pessoa.getEndereco().getCidade() != null) {
				pessoa.getEndereco().setEstado(pessoa.getEndereco().getCidade().getEstado());
			}
		}

		if (pessoa.getNaturalidade() != null) {
			pessoa.setEstadoNascimento(pessoa.getNaturalidade().getEstado());
		}

		ModelAndView mv = nova(pessoa);
		mv.addObject(pessoa);
		return mv;
	}

	@DeleteMapping("/excluir/{codigo}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("codigo") Pessoa pessoa) {
		try {
			pessoaService.excluir(pessoa);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}

	// pesquisa rapida
	@RequestMapping(consumes = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody List<Pessoa> pesquisar(String nome) {
		// return pessoas.findByNomeStartingWithIgnoreCase(nome);
		return pessoas.findByNomeContainingIgnoreCase(nome);
	}

	// cadastro rapido
	@RequestMapping(method = RequestMethod.POST, consumes = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ResponseEntity<?> salvar(@RequestBody @Valid Pessoa pessoa, BindingResult result) {
		if (result.hasErrors()) {
			return ResponseEntity.badRequest().body(result.getGlobalError().getDefaultMessage());
		}
	
		pessoa = pessoaService.salvar(pessoa);
		return ResponseEntity.ok(pessoa);
	}

}
