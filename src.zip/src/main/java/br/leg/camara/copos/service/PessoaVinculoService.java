package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.PessoaVinculo;
import br.leg.camara.copos.repository.filter.PessoaVinculoFilter;

public interface PessoaVinculoService {

	Page<PessoaVinculo> filtrar(PessoaVinculoFilter filtro, Pageable pageable);

	public void salvar(PessoaVinculo pessoaVinculo);

	void excluir(PessoaVinculo pessoaVinculo);

}
