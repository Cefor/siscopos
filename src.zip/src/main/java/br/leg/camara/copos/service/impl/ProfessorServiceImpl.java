package br.leg.camara.copos.service.impl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.OfertaProfessor;
import br.leg.camara.copos.model.entity.Professor;
import br.leg.camara.copos.repository.Professores;
import br.leg.camara.copos.repository.filter.DisciplinaMinistradaFilter;
import br.leg.camara.copos.repository.filter.OrientacaoFilter;
import br.leg.camara.copos.repository.filter.ProfessorFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.ProfessorService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Service
public class ProfessorServiceImpl implements ProfessorService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
		
	@Autowired
	private Professores professores;
	
	
	
	@Override
	@Transactional
	public void salvar(Professor professor) {
		
		if(professores.findByCursoAndPessoa(professor.getCurso(), professor.getPessoa()).isPresent()) {
			throw new DuplicidadeIndiceUnicoException("Professor(a) " + 
													  professor.getPessoa().getNome() +
													  " já está cadastrado(a) no curso " +
													  professor.getCurso().getSigla());
		}
		
		professores.save(professor);
	}

	
	@Override
	@Transactional
	public void excluir(Professor professor) {
		try {
			professores.delete(professor);
			professores.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Professor já foi associado a outra entidade.");
		}
	}
	
	
	
	
	
	
	
	
	
	// Filtros de DISCIPLINA
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<OfertaProfessor> disciplinas(DisciplinaMinistradaFilter filtro, Pageable pageable){
		Criteria criteria = manager.unwrap(Session.class).createCriteria(OfertaProfessor.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro3(filtro, criteria);
		
		List<OfertaProfessor> lista = criteria.list();
		
		return new PageImpl<>(lista, pageable, total3(filtro));
	}
	
	private void adicionarFiltro3(DisciplinaMinistradaFilter filtro, Criteria criteria) {
		
		Professor professor = professores.findOne(filtro.getIdProfessor());
		
		criteria.add(Restrictions.eq("professor", professor));
		
		criteria.createAlias("oferta", "o", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("oferta.cursoDisciplina", "cd", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("oferta.cursoDisciplina.disciplina", "d", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("oferta.cursoDisciplina.cursoLinhaPesquisa", "cl", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("oferta.cursoDisciplina.cursoLinhaPesquisa.linhaPesquisa", "l", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("oferta.semestre", "s", JoinType.LEFT_OUTER_JOIN);
		
		if (!StringUtils.isEmpty(filtro.getCurso())) {
			criteria.add(Restrictions.eq("cd.curso", filtro.getCurso()));
		}	
		
		if (!StringUtils.isEmpty(filtro.getSigla())) {
			criteria.add(Restrictions.ilike("d.sigla", filtro.getSigla(), MatchMode.ANYWHERE));
		}	

		if (!StringUtils.isEmpty(filtro.getLinha())) {
			criteria.add(Restrictions.ilike("l.apelido", filtro.getLinha(), MatchMode.ANYWHERE));
		}
		
		if (!StringUtils.isEmpty(filtro.getAno())) {
			criteria.add(Restrictions.ilike("s.ano", filtro.getAno(), MatchMode.ANYWHERE));
		}

	}
	
	private Long total3(DisciplinaMinistradaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(OfertaProfessor.class);
		adicionarFiltro3(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtros de DISCIPLINA
	
	
	
	
	// Filtros de ORIENTACAO
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<AlunoReg> orientacoes(OrientacaoFilter filtro, 
			Pageable pageable){
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoReg.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro2(filtro, criteria);
		
		List<AlunoReg> lista = criteria.list();
		
		return new PageImpl<>(lista, pageable, total2(filtro));
	}
	
	private void adicionarFiltro2(OrientacaoFilter filtro, Criteria criteria) {
		
		Professor professor = professores.findOne(filtro.getIdProfessor());
		
		if(filtro.getTipoOrientacao() == null || filtro.getTipoOrientacao().isEmpty()) {
			criteria.add(
				    Restrictions.or(
				        Restrictions.eq("orientador", professor),
				        Restrictions.eq("coorientador", professor.getPessoa())
				    )
				);
		} else if (filtro.getTipoOrientacao().equals("Orientador")){
			criteria.add(Restrictions.eq("orientador", professor));
		} else if (filtro.getTipoOrientacao().equals("Coorientador")){
			criteria.add(Restrictions.eq("coorientador", professor.getPessoa()));
		}

		criteria.createAlias("aluno", "a", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("aluno.pessoa", "p", JoinType.LEFT_OUTER_JOIN);

		if (!StringUtils.isEmpty(filtro.getCurso())) {
			criteria.add(Restrictions.eq("a.curso", filtro.getCurso()));
		}		
		
		if (!StringUtils.isEmpty(filtro.getMatricula())) {
			criteria.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
		}
		
		if (!StringUtils.isEmpty(filtro.getNome())) {
			criteria.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
		}
		
		if (!StringUtils.isEmpty(filtro.getLinha())) {
			Criteria cursoLinharCrit  = criteria.createCriteria("cursoLinhaPesquisa");
			Criteria linhaCrit = cursoLinharCrit.createCriteria("linhaPesquisa");
			linhaCrit.add(Restrictions.ilike("apelido", filtro.getLinha(), MatchMode.ANYWHERE));
		}

		criteria.addOrder(Order.asc("dataHomologacao"));
		criteria.addOrder(Order.asc("p.nome"));
	}
	
	private Long total2(OrientacaoFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoReg.class);
		adicionarFiltro2(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtros de ORIENTACAO
	
	
	
	
	// Filtrar e paginação - PESQUISA
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Professor> filtrar(ProfessorFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Professor.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<Professor> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
		
	private void adicionarFiltro(ProfessorFilter filtro, Criteria criteria) {
		
		criteria.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("curso", "c", JoinType.LEFT_OUTER_JOIN);
		
		criteria.addOrder(Order.asc("p.nome"));
		criteria.addOrder(Order.asc("c.nome"));
		
		if (filtro != null) {
			
	
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCurso())) {
				criteria.add(Restrictions.eq("curso", filtro.getCurso()));
			}
						
		}
	}
		
	private Long total(ProfessorFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Professor.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA
	
}
