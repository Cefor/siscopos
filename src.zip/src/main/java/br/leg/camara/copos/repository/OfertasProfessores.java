package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.model.entity.OfertaProfessor;
import br.leg.camara.copos.model.entity.Professor;

public interface OfertasProfessores extends JpaRepository<OfertaProfessor, Long> {

	public List<OfertaProfessor> findByOfertaOrderByProfessorPessoaNome(Oferta oferta);

	public Optional<OfertaProfessor> findByOfertaAndProfessor(Oferta oferta, Professor professor);
	
}
