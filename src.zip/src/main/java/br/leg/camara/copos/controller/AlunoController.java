package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.repository.Alunos;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.filter.AlunoFilter;
import br.leg.camara.copos.service.AlunoService;

@Controller
@RequestMapping("/alunos")
public class AlunoController {

	@Autowired
	private AlunoService alunoService;

	@Autowired
	private Cursos cursos;

	@Autowired
	private Alunos alunos;
	
    @Value("${pasta.raiz.origem}")
    private String pastaRaizOrigem;
    
    @Value("${pasta.raiz.espelho}")
    private String pastaRaizEspelho;
    
    @Value("${pasta.ofertas}")
    private String pastaOfertas;
    
    @Value("${pasta.pessoas}")
    private String pastaPessoas;
	

	
	@GetMapping
	public ModelAndView pesquisar(AlunoFilter alunoFilter, BindingResult result,
			@PageableDefault(size = 30) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("aluno/PesquisaAluno");
		
		mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
		
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaPessoas", pastaPessoas);

		PageWrapper<Aluno> paginaWrapper = new PageWrapper<>(alunoService.filtrar(alunoFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}

	
	
	@GetMapping("/linhatempo/{idAluno}")
	public ModelAndView linhaTempoAluno(@PathVariable Long idAluno) {
		ModelAndView mv = new ModelAndView("aluno/LinhaTempo");
		
		mv.addObject("nomeCurso", alunos.findById(idAluno).get().getCurso().getNome());
		mv.addObject("siglaCurso", alunos.findById(idAluno).get().getCurso().getSigla());
		mv.addObject("nomeAluno", alunos.findById(idAluno).get().getPessoa().getNome());
		mv.addObject("disciplinas", alunoService.matriculas(idAluno));
		
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaOfertas", pastaOfertas);
		
		return mv;
	}
}
