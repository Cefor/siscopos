package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Cidade;
import br.leg.camara.copos.model.entity.Estado;


public interface Cidades extends JpaRepository<Cidade, Long> {

	public List<Cidade> findByEstadoCodigoOrderByNome(Long codigoEstado);

	public Optional<Cidade> findByNomeAndEstado(String nome, Estado estado);
	
}