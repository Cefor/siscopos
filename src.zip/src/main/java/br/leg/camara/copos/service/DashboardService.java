package br.leg.camara.copos.service;

import br.leg.camara.copos.model.entity.Curso;

public interface DashboardService {

	int regularesAtivos(Curso curso);

	int regularesEgressos(Curso curso);

	int regularesDesligados(Curso curso);

	String regularesAtivosPrazoEncerrado(Curso curso);
	
	int regularesTotal(Curso curso);

	String regularesAtivosQualificados(Curso curso);

	String regularesEmHomologacao(Curso curso);

	String regularesTrancados(Curso curso);

	String graficoRegulares(Curso curso);

	String graficoEspeciais(Curso curso);

}
