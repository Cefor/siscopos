package br.leg.camara.copos.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.repository.filter.AlunoFilter;

public interface AlunoService {
	
	Page<Aluno> filtrar(AlunoFilter filtro, Pageable pageable);
	
	public List<MatriculaDisciplina> matriculas(Long id_aluno);
	
	public void salvar(Aluno aluno);

}
