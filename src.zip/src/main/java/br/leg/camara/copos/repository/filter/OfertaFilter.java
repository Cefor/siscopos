package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.TipoDisciplina;

public class OfertaFilter {

	private Curso curso;
	private SemestrePeriodo semestre;
	private String disciplinaSigla;
	private String professor;
	private TipoDisciplina tipo;
	
	public boolean isCursoVazio() {
		return curso == null;
	}
	
	public boolean isSemestreVazio() {
		return semestre == null;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public SemestrePeriodo getSemestre() {
		return semestre;
	}

	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}

	public String getDisciplinaSigla() {
		return disciplinaSigla;
	}

	public void setDisciplinaSigla(String disciplinaSigla) {
		this.disciplinaSigla = disciplinaSigla;
	}

	public String getProfessor() {
		return professor;
	}

	public void setProfessor(String professor) {
		this.professor = professor;
	}

	public TipoDisciplina getTipo() {
		return tipo;
	}

	public void setTipo(TipoDisciplina tipo) {
		this.tipo = tipo;
	}

	
}
