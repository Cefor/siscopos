package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "pessoa_titulo")
public class PessoaTitulo {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_pessoa")
	private Pessoa pessoa;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_graucurso")
	private GrauCurso grauCurso;

	@NotNull(message = "Data da titulação é obrigatória")
	@Column(name = "data_titulacao")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataTitulacao;	
	
	@Column(name = "descricao", length = 255)
	@NotBlank(message = "Descrição da titulação é obrigatória")
	private String descricao;

	public boolean isNovo() {
		return id == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public GrauCurso getGrauCurso() {
		return grauCurso;
	}

	public void setGrauCurso(GrauCurso grauCurso) {
		this.grauCurso = grauCurso;
	}

	public LocalDate getDataTitulacao() {
		return dataTitulacao;
	}

	public void setDataTitulacao(LocalDate dataTitulacao) {
		this.dataTitulacao = dataTitulacao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public String toString() {
		return "PessoaTitulo [id=" + id + ", pessoa=" + pessoa + ", grauCurso=" + grauCurso + ", dataTitulacao="
				+ dataTitulacao + ", descricao=" + descricao + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(dataTitulacao, descricao, grauCurso, id, pessoa);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PessoaTitulo other = (PessoaTitulo) obj;
		return Objects.equals(dataTitulacao, other.dataTitulacao) && Objects.equals(descricao, other.descricao)
				&& Objects.equals(grauCurso, other.grauCurso) && Objects.equals(id, other.id)
				&& Objects.equals(pessoa, other.pessoa);
	}

}
