package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.GrauCurso;
import br.leg.camara.copos.model.enums.SimNao;

public class PessoaTituloFilter {

	private Curso curso;
	private GrauCurso grauCurso;
	private String nome;
	private SimNao periodoCurso;
	
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public GrauCurso getGrauCurso() {
		return grauCurso;
	}
	public void setGrauCurso(GrauCurso grauCurso) {
		this.grauCurso = grauCurso;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public SimNao getPeriodoCurso() {
		return periodoCurso;
	}
	public void setPeriodoCurso(SimNao periodoCurso) {
		this.periodoCurso = periodoCurso;
	}
	

	
	
	
		
}
