package br.leg.camara.copos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.LinhaPesquisa;

public interface LinhasPesquisa extends JpaRepository<LinhaPesquisa, Long> {
	

}
