package br.leg.camara.copos.service.exception;

public class AlunoJaCadastradoException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public AlunoJaCadastradoException(String message) {
		super(message);
	}

}
