package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.Disciplina;
import br.leg.camara.copos.repository.filter.DisciplinaFilter;

public interface DisciplinaService {
	
	Page<Disciplina> filtrar(DisciplinaFilter filtro, Pageable pageable);

	void salvar(Disciplina disciplina);

	void excluir(Disciplina disciplina);
}
