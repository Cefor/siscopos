package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.OfertaProfessor;
import br.leg.camara.copos.repository.filter.OfertaFilter;

public interface OfertaProfessorService {

	void salvar(OfertaProfessor ofertaProfessor);

	void excluir(OfertaProfessor ofertaProfessor);

	Page<OfertaProfessor> filtrar(OfertaFilter filtro, Pageable pageable);
	
}
