package br.leg.camara.copos.repository.filter;

import java.time.LocalDate;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.SemestrePeriodo;

public class AlunoEspFilter {

	private Curso curso;
	private String nome;
	private String matricula;
	private String cpf;
	private LocalDate dataFimRestricao;
	private SemestrePeriodo semestre;
		
	public boolean isCursoVazio() {
		return curso ==  null;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public LocalDate getDataFimRestricao() {
		return dataFimRestricao;
	}

	public void setDataFimRestricao(LocalDate dataFimRestricao) {
		this.dataFimRestricao = dataFimRestricao;
	}

	public SemestrePeriodo getSemestre() {
		return semestre;
	}

	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}

	
}
