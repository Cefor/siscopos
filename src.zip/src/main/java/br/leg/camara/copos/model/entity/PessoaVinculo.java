package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "pessoa_vinculo")
public class PessoaVinculo {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_pessoa")
	private Pessoa pessoa;
	
	@OneToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_instituicaoparceira")
	private InstituicaoParceira instituicaoParceira;
	
	@OneToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_vinculocd")
	private VinculoCD vinculoCD;
	
	@Column(name = "pontoCD")
	private String pontoCD;
	
	@Column(name = "data_inicio")
	@NotNull(message = "Data de início do vínculo obrigatória")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataInicio;
	
	@Column(name = "data_fim")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataFim;

	@Column(name = "observacao", length = 255)
	private String observacao;
	
	public boolean isNovo() {
		return id == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public InstituicaoParceira getInstituicaoParceira() {
		return instituicaoParceira;
	}

	public void setInstituicaoParceira(InstituicaoParceira instituicaoParceira) {
		this.instituicaoParceira = instituicaoParceira;
	}

	public VinculoCD getVinculoCD() {
		return vinculoCD;
	}

	public void setVinculoCD(VinculoCD vinculoCD) {
		this.vinculoCD = vinculoCD;
	}

	public String getPontoCD() {
		return pontoCD;
	}

	public void setPontoCD(String pontoCD) {
		this.pontoCD = pontoCD;
	}

	public LocalDate getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(LocalDate dataInicio) {
		this.dataInicio = dataInicio;
	}

	public LocalDate getDataFim() {
		return dataFim;
	}

	public void setDataFim(LocalDate dataFim) {
		this.dataFim = dataFim;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	@Override
	public String toString() {
		return "PessoaVinculo [id=" + id + ", pessoa=" + pessoa + ", instituicaoParceira=" + instituicaoParceira
				+ ", vinculoCD=" + vinculoCD + ", pontoCD=" + pontoCD + ", dataInicio=" + dataInicio + ", dataFim="
				+ dataFim + ", observacao=" + observacao + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(dataFim, dataInicio, id, instituicaoParceira, observacao, pessoa, pontoCD, vinculoCD);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PessoaVinculo other = (PessoaVinculo) obj;
		return Objects.equals(dataFim, other.dataFim) && Objects.equals(dataInicio, other.dataInicio)
				&& Objects.equals(id, other.id) && Objects.equals(instituicaoParceira, other.instituicaoParceira)
				&& Objects.equals(observacao, other.observacao) && Objects.equals(pessoa, other.pessoa)
				&& Objects.equals(pontoCD, other.pontoCD) && Objects.equals(vinculoCD, other.vinculoCD);
	}

}
