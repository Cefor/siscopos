package br.leg.camara.copos.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.PessoaVinculo;

public interface PessoasVinculos extends JpaRepository<PessoaVinculo, Long> {

	List<PessoaVinculo> findByPessoaOrderByDataInicioAsc(Pessoa pessoa);
	
	Optional<PessoaVinculo> findByPessoaAndDataInicio(Pessoa pessoa, LocalDate dataInicio);
	
}
