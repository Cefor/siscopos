package br.leg.camara.copos.controller;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/files")
public class FileController {


    @GetMapping("/list")
    public ResponseEntity<List<String>> listFiles(@RequestParam("folder") String folder) {
        try {
            Path folderPath = Paths.get(folder);

            if (!Files.exists(folderPath)) {
            	
            	// System.out.println("A pasta especificada não foi encontrada.");
            	
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Collections.singletonList("A pasta especificada não foi encontrada."));
            }

            List<String> files = Files.list(folderPath)
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .collect(Collectors.toList());

            return ResponseEntity.ok(files);

        } catch (NoSuchFileException e) {
        	
        	// System.out.println("NoSuchFileException: " + e.getMessage());
        	
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonList("A pasta especificada não foi encontrada."));
        } catch (IOException e) {
        	
        	// System.out.println("IOException: " + e.getMessage());
        	
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList("Erro ao acessar os arquivos na pasta."));
        }
    }


    @GetMapping("/download")
    public ResponseEntity<Resource> downloadFile(@RequestParam String folder, @RequestParam String filename) {
        try {
            // Decodificar o caminho da pasta e o nome do arquivo
            String decodedFolder = URLDecoder.decode(folder, StandardCharsets.UTF_8.name());
            String decodedFilename = URLDecoder.decode(filename, StandardCharsets.UTF_8.name());
            Path filePath = Paths.get(decodedFolder).resolve(decodedFilename);
            File file = filePath.toFile();

            if (!file.exists()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }

            Resource resource = new FileSystemResource(file);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName());

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(resource);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    
    @GetMapping("/check")
    public ResponseEntity<Boolean> checkIfDirectory(@RequestParam("folder") String folder) {
        Path folderPath = Paths.get(folder);
        return ResponseEntity.ok(Files.isDirectory(folderPath));
    }
}
