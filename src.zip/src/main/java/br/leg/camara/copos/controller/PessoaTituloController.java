package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.PessoaTitulo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.repository.Pessoas;
import br.leg.camara.copos.repository.PessoasTitulos;
import br.leg.camara.copos.repository.filter.PessoaTituloFilter;
import br.leg.camara.copos.service.PessoaTituloService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.GrausCursos;

@Controller
@RequestMapping("/pessoatitulo")
public class PessoaTituloController {

	@Autowired
	private Pessoas pessoas;
	
	@Autowired
	private GrausCursos grausCursos;

	@Autowired
	private PessoasTitulos pessoasTitulos;
	
	@Autowired
	private PessoaTituloService pessoaTituloService;
	
	@Autowired
	private Cursos cursos;

		
	@RequestMapping("/novo/{idPessoa}")
	public ModelAndView novo(PessoaTitulo pessoaTitulo, @PathVariable Long idPessoa) {
		
		ModelAndView mv = new ModelAndView("pessoatitulo/CadastroPessoaTitulo");
		
		Pessoa pessoa = pessoas.getOne(idPessoa);
		pessoaTitulo.setPessoa(pessoa);
		
		mv.addObject("grauscursos", grausCursos.findAll());
		
		
		return mv;
	}
	

	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid PessoaTitulo pessoaTitulo, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return novo(pessoaTitulo, pessoaTitulo.getPessoa().getCodigo());
		}

		try {
			pessoaTituloService.salvar(pessoaTitulo);
		} catch (DuplicidadeIndiceUnicoException e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return novo(pessoaTitulo, pessoaTitulo.getPessoa().getCodigo());
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return novo(pessoaTitulo, pessoaTitulo.getPessoa().getCodigo());
		} 

		attributes.addFlashAttribute("mensagem", "Título acadêmico salvo com sucesso.");
		return new ModelAndView("redirect:/pessoatitulo/novo/" + pessoaTitulo.getPessoa().getCodigo());
		
	}


	@GetMapping("/editar/{id}")
	public ModelAndView editar(PessoaTitulo pessoaTitulo, @PathVariable Long id) {
		
		pessoaTitulo = pessoasTitulos.findOne(id);
		
		ModelAndView mv = novo(pessoaTitulo, pessoaTitulo.getPessoa().getCodigo());
		
		mv.addObject(pessoaTitulo);
		
		return mv;
	}

	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") PessoaTitulo pessoaTitulo) {
		try {
			pessoaTituloService.excluir(pessoaTitulo);
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	
	@GetMapping("/pesquisar/{idPessoa}")
	public ModelAndView pesquisarPessoa(@PathVariable Long idPessoa) {
		
		ModelAndView mv = new ModelAndView("pessoatitulo/PesquisaPessoaTitulo");
		
		Pessoa pessoa = pessoas.findOne(idPessoa);
		
		mv.addObject(pessoa);
		mv.addObject("titulos", pessoasTitulos.findByPessoaOrderByDataTitulacaoAsc(pessoa));
		
		
		return mv;
	}
	
	
	@GetMapping("/pesquisarprofessor")
	public ModelAndView pesquisarProfessor(PessoaTituloFilter pessoaTituloFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		
		ModelAndView mv = new ModelAndView("pessoatitulo/PesquisaPessoaTituloProfessor");
	    
	    mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
	    mv.addObject("grausCursos", grausCursos.findAll());
	    mv.addObject("simnao", SimNao.values());
	    
	    PageWrapper<PessoaTitulo> paginaWrapper = new PageWrapper<>(pessoaTituloService.filtrarProfessor(pessoaTituloFilter, pageable),
	            httpServletRequest);
	    
	    mv.addObject("pagina", paginaWrapper);
	    return mv;		
	}
	
	
	
		
}
