package br.leg.camara.copos.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.PessoaTitulo;
import br.leg.camara.copos.model.entity.Professor;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.repository.PessoasTitulos;
import br.leg.camara.copos.repository.Professores;
import br.leg.camara.copos.repository.filter.PessoaTituloFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.PessoaTituloService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;

@Service
public class PessoaTituloServiceImpl implements PessoaTituloService{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private PessoasTitulos pessoasTitulos;
	
	@Autowired
	private Professores professores;
	
	
	@Override
	@Transactional
	public void salvar(PessoaTitulo pessoaTitulo) {

		if(pessoasTitulos.findByPessoaAndDataTitulacao(pessoaTitulo.getPessoa(), pessoaTitulo.getDataTitulacao()).isPresent() &&
				pessoaTitulo.isNovo()) {
			DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			throw new DuplicidadeIndiceUnicoException("Já existe título associado à data " + pessoaTitulo.getDataTitulacao().format(dtFormatter));
		}
		
		pessoasTitulos.save(pessoaTitulo);
	}
	
	
	@Override
	@Transactional
	public void excluir(PessoaTitulo pessoaTitulo) {
		pessoasTitulos.delete(pessoaTitulo);
		pessoasTitulos.flush();
	}
	
	
	
	
	
	
	// Filtrar e paginação - PESQUISA
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<PessoaTitulo> filtrarProfessor(PessoaTituloFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(PessoaTitulo.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<PessoaTitulo> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	
	private void adicionarFiltro(PessoaTituloFilter filtro, Criteria criteria) {
		
		List<Professor> listaProfessores;
		
		// filtros em Professor
		if (filtro != null && !StringUtils.isEmpty(filtro.getCurso())) {
			listaProfessores = professores.findByCurso(filtro.getCurso());
		} else {
			listaProfessores = professores.findAll();
		}

		List<Pessoa> pessoas = listaProfessores.stream()
			    .map(Professor::getPessoa)  // Extrair o objeto Pessoa de cada Professor
			    .collect(Collectors.toList());
		
		criteria.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		criteria.createAlias("grauCurso", "gc", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.in("pessoa", pessoas));
		criteria.addOrder(Order.asc("p.nome"));
		criteria.addOrder(Order.desc("gc.grau"));
		criteria.addOrder(Order.desc("dataTitulacao"));

		// filtros em PessoaTitulo
		if (filtro != null) {
			if (!StringUtils.isEmpty(filtro.getGrauCurso())) {
				criteria.add(Restrictions.eq("grauCurso", filtro.getGrauCurso()));
			}
			
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getPeriodoCurso()) && 
					!StringUtils.isEmpty(filtro.getCurso()) && 
					filtro.getPeriodoCurso().equals(SimNao.S)) {
				
				if(filtro.getCurso().getDataFim() != null) {
					criteria.add(Restrictions.le("dataTitulacao", filtro.getCurso().getDataFim()));
				} else {
					criteria.add(Restrictions.le("dataTitulacao", LocalDate.now()));
				}
		
			}
		}
	}
			
		
	private Long total(PessoaTituloFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(PessoaTitulo.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA
		
}

