package br.leg.camara.copos.service.impl;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.bridge.AlunoRegNovo;
import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;
import br.leg.camara.copos.repository.Alunos;
import br.leg.camara.copos.repository.AlunosEsp;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.filter.AlunoRegFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.AlunoRegService;
import br.leg.camara.copos.service.exception.AlunoJaCadastradoException;
import br.leg.camara.copos.service.exception.DatasAlunoRegException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.MatriculaObrigatoriaException;
import br.leg.camara.copos.service.exception.PessoaObrigatoriaException;

@Service
public class AlunoRegServiceImpl implements AlunoRegService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
		
	@Autowired
	private AlunosReg alunosReg;

	@Autowired
	private AlunosEsp alunosEsp;
	
	@Autowired
	private Alunos alunos;
	
	@Override
	@Transactional
	public void salvar(AlunoRegNovo alunoRegNovo) {
		
		Aluno aluno = new Aluno();
		
		if(alunoRegNovo.getPessoa().isNova()) {
			throw new PessoaObrigatoriaException("Obrigatório informar o(a) aluno(a)");
		}
				
		if(alunoRegNovo.getMatricula().isEmpty()) {
			// throw new MatriculaObrigatoriaException("Obrigatório informar a matrícula");
			
			// verifica a ultima matricula efetuada no mesmo semestre/curso e soma 1
			String ultimaMatricula = "0";
			List<AlunoReg> listaAlunoReg = alunosReg.findBySemestreAndAlunoCursoOrderByMatriculaDesc(alunoRegNovo.getSemestre(), alunoRegNovo.getCurso());
			if(listaAlunoReg.size() > 0) {
				ultimaMatricula = listaAlunoReg.get(0).getMatricula();
				ultimaMatricula = (String) ultimaMatricula.subSequence(ultimaMatricula.length()-3, ultimaMatricula.length());
			}
			String seq = "00" + (Integer.parseInt(ultimaMatricula) + 1);
			
			alunoRegNovo.setMatricula(
					alunoRegNovo.getSemestre().getAno() +
					alunoRegNovo.getCurso().getSigla() +
					alunoRegNovo.getSemestre().getSemestre() +
					seq.subSequence(seq.length() - 3, seq.length())				
					);
		}
		
		Optional<Aluno> alunoaux = alunos.findByCursoAndPessoa(alunoRegNovo.getCurso(), alunoRegNovo.getPessoa());
		
		if(alunoaux.isPresent()) { // se o aluno existe ...

			aluno = alunoaux.get();
			
			// e aluno regular existe -> mensagem de duplicidade 
			if(alunosReg.findByAluno(aluno).isPresent()) { 
				throw new AlunoJaCadastradoException(alunoRegNovo.getPessoa().getNome() + " já é aluno(a) regular");
			} 
			
		} else { // se nao existir ...

			aluno = new Aluno(alunoRegNovo.getCurso(), alunoRegNovo.getPessoa());
			// salva aluno usando o repository, nao o AlunoSevice,
			// pois esta numa so Transaction
			aluno = alunos.save(aluno);
		}
		
		// Estima prazo de conclusao
		if(alunoRegNovo.getPrazoConclusao() == null) {
			if(alunoRegNovo.getCurso().getDataFim() == null) {
				alunoRegNovo.setPrazoConclusao(alunoRegNovo.getSemestre().getDia1().plusMonths( alunoRegNovo.getCurso().getPrazoConclusao() ).minusDays(1));	
			} else {
				alunoRegNovo.setPrazoConclusao(alunoRegNovo.getCurso().getDataFim());
			}
		}
		
		if(alunoRegNovo.getOrientador().isNovo()) {
			alunoRegNovo.setOrientador(null);
		}
		
		AlunoReg alunoReg = new AlunoReg(
				aluno,
				alunoRegNovo.getMatricula(),
				alunoRegNovo.getSemestre(),
				alunoRegNovo.getDataIngresso(),
				alunoRegNovo.getCursoLinhaPesquisa(),
				alunoRegNovo.getOrientador(),
				alunoRegNovo.getCoorientador(),
				alunoRegNovo.getPagante(),
				alunoRegNovo.getPrazoConclusao(),
				alunoRegNovo.getTituloTCC(),
				alunoRegNovo.getDataHomologacao(),
				alunoRegNovo.getDataExpedicaoDiploma(),
				alunoRegNovo.getDataDesligamento(),
				alunoRegNovo.getDataReativacao()
				);

		alunosReg.save(alunoReg);
		
	}
	
	@Override
	@Transactional
	public void salvarEdicao(AlunoReg alunoReg) {
		
		if(alunoReg.getMatricula().isEmpty()) {
			throw new MatriculaObrigatoriaException("Obrigatório informar a matrícula");
		}
		
		if(alunoReg.getOrientador().isNovo()) {
			alunoReg.setOrientador(null);
		}
		
		if(alunoReg.getCoorientador().isNova()) {
			alunoReg.setCoorientador(null);
		}

		// Estima prazo de conclusao
		if(alunoReg.getPrazoConclusao() == null) {
			if(alunoReg.getAluno().getCurso().getDataFim() == null) {
				alunoReg.setPrazoConclusao(alunoReg.getSemestre().getDia1().plusMonths( alunoReg.getAluno().getCurso().getPrazoConclusao() ).minusDays(1));	
			} else {
				alunoReg.setPrazoConclusao(alunoReg.getAluno().getCurso().getDataFim());
			}
		}
		
		
		// tratamento das datas
		
		// se dataHomologacao != null, verifica se as outras datas sao nulo
		if(alunoReg.getDataHomologacao() != null) {
			
			if(alunoReg.getDataDesligamento() != null) {
				
				if(alunoReg.getDataReativacao() != null) {

					// entao, dataHologacao deve maior que todas
					if( !( alunoReg.getDataHomologacao().isAfter(alunoReg.getDataDesligamento()) &&
						   alunoReg.getDataDesligamento().isBefore(alunoReg.getDataReativacao()) &&
						   alunoReg.getDataHomologacao().isAfter(alunoReg.getDataReativacao()) 
						  ) 
					   ) {
						throw new DatasAlunoRegException("Se o aluno foi desligado e teve sua matrícula reativada, " +
						                "a data de homologação deve estar em branco (enquanto o aluno está cursando) " +
								        "ou deve ser maior que a data da reativação.");
					} 

					// se todas as datas sao != null, recalcula prazo de conclusao com base na data de reativacao
					if(alunoReg.getPrazoConclusao() != null &&
					   alunoReg.getPrazoConclusao().isBefore(alunoReg.getDataReativacao().plusMonths(alunoReg.getAluno().getCurso().getPrazoConclusao()).minusDays(1))	) {

						alunoReg.setPrazoConclusao(alunoReg.getDataReativacao().plusMonths(alunoReg.getAluno().getCurso().getPrazoConclusao()).minusDays(1));
					}
					
					
				} else { // se data de reativacao eh nula e de deslimento nao 
					throw new DatasAlunoRegException("Datas de homologação e desligamento só coexistem quando a matrícula está reativada.");
				}
				
			} else { // se data de desligamento eh nula e data de homologacao não
				
				if(alunoReg.getDataReativacao() != null) {
					throw new DatasAlunoRegException("Não pode haver data de reativação sem que tenha havido o desligamento.");
				}
			}
		} else { // se data de homologacao eh nula 
			
			if(alunoReg.getDataReativacao() != null &&
			   alunoReg.getDataDesligamento() == null ) {
				throw new DatasAlunoRegException("Não pode haver data de reativação sem que tenha havido o desligamento.");
			}
			
			if(alunoReg.getDataDesligamento() != null &&
			   alunoReg.getDataReativacao() != null) {
				
				if(alunoReg.getDataDesligamento().isAfter(alunoReg.getDataReativacao())) {
					throw new DatasAlunoRegException("Data de reativação deve ser maior que a data do desligamento.");
				}
				
				// recalcula prazo de conclusao com base na data de reativacao
				if(alunoReg.getPrazoConclusao() != null &&
				   alunoReg.getPrazoConclusao().isBefore(alunoReg.getDataReativacao().plusMonths(alunoReg.getAluno().getCurso().getPrazoConclusao()).minusDays(1))	) {

					alunoReg.setPrazoConclusao(alunoReg.getDataReativacao().plusMonths(alunoReg.getAluno().getCurso().getPrazoConclusao()).minusDays(1));
				}
			}
		}
		
		
		if(alunoReg.getDataExpedicaoDiploma() != null) {
			if(alunoReg.getDataHomologacao() == null) {
				throw new DatasAlunoRegException("Data de expedição do diploma só pode ser lançada quando a data de homologação estiver preenchida.");
			} else if(alunoReg.getDataExpedicaoDiploma().isBefore(alunoReg.getDataHomologacao())) {
				throw new DatasAlunoRegException("Data de expedição do diploma deve ser maior ou igual à data de homologação.");
			}
		}
		
		//System.out.println("\n\n\nEntrou\n\n\n");		
		
		
		alunosReg.save(alunoReg);
	}
	
	
	@Override
	@Transactional
	public void excluir(AlunoReg alunoReg) {
		try {
			alunosReg.delete(alunoReg);
			alunosReg.flush();
			
			// se nao tiver registro como aluno especial, excluir de Aluno
			if(!alunosEsp.findByAluno(alunoReg.getAluno()).isPresent()) {
				alunos.delete(alunoReg.getAluno());
				alunos.flush();
			}
			
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Aluno regular já associado a outra entidade.");
		}
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public List<MatriculaDisciplina> historico(Long idAluno){

		AlunoReg alunoReg = alunosReg.findByAluno(alunos.getOne(idAluno)).get();
		Criteria criteria = manager.unwrap(Session.class).createCriteria(MatriculaDisciplina.class);
		
		criteria.createAlias("matricula", "m", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.eq("m.aluno.id", idAluno));

		criteria.createAlias("oferta", "o", JoinType.LEFT_OUTER_JOIN);
		criteria.add(Restrictions.isNull("o.dataCancelamento"));
		
		//Criteria oferta  = criteria.createCriteria("oferta");
		//oferta.add(Restrictions.isNull("dataCancelamento"));
		
		criteria.addOrder(Order.asc("m.semestre"));
		criteria.addOrder(Order.asc("dataMencao"));
		criteria.createAlias("oferta.cursoDisciplina.disciplina", "d", JoinType.LEFT_OUTER_JOIN);
		criteria.addOrder(Order.asc("d.sigla"));	
		
		List<MatriculaDisciplina> lista = criteria.list();

		// retirar todas as reprovacoes e CS como aluno especial
        Iterator<MatriculaDisciplina> iterator = lista.iterator();
        while (iterator.hasNext()) {
            MatriculaDisciplina matriculaDisciplina = iterator.next();
            
            if (matriculaDisciplina.getMencao() != null &&
            		(matriculaDisciplina.getMencao().equals("RP") || matriculaDisciplina.getMencao().equals("CS")) &&
            		matriculaDisciplina.getMatricula().getAlunoEsp() != null) {
                iterator.remove();
            }
        }
        
		// retirar todas as reprovacoes e CS anteriores ao semestre da reativacao
        if(alunoReg.getDataReativacao() != null) {
            iterator = lista.iterator();
            while (iterator.hasNext()) {
                MatriculaDisciplina matriculaDisciplina = iterator.next();
                
                if (matriculaDisciplina.getMencao() != null &&
                		(matriculaDisciplina.getMencao().equals("RP") || matriculaDisciplina.getMencao().equals("CS")) &&
                		matriculaDisciplina.getOferta().getSemestre().getPeriodo().compareTo(periodo(alunoReg.getDataReativacao())) < 0){ 
                    iterator.remove();
                }
            }
        }
		
		// retirar todas as disciplinas cursadas apos a data de homologacao
        if(alunoReg.getDataHomologacao() != null) {
            iterator = lista.iterator();
            while (iterator.hasNext()) {
                MatriculaDisciplina matriculaDisciplina = iterator.next();
                
                if (matriculaDisciplina.getOferta().getSemestre().getPeriodo().compareTo(periodo(alunoReg.getDataHomologacao())) > 0){ 
                    iterator.remove();
                }
            }
        } else if(alunoReg.getDataDesligamento() != null) {
        	if(alunoReg.getDataReativacao() == null) { // aluno desligado
        		// retirar todas as disciplinas cursadas apos a data de desligamento
        		iterator = lista.iterator();
                while (iterator.hasNext()) {
                    MatriculaDisciplina matriculaDisciplina = iterator.next();
                    
                    if (matriculaDisciplina.getOferta().getSemestre().getPeriodo().compareTo(periodo(alunoReg.getDataDesligamento())) > 0){ 
                        iterator.remove();
                    }
                }
        	} // senao, eh aluno regular ativo e nao retira nada
        }
		
		return lista;
	}
		
		
	private String periodo(LocalDate data) {
		return data.getYear() + "/" + (data.getDayOfYear() > 182 ? 2 : 1);
	}
	
	
	
	// Filtrar e paginação - PESQUISA GERAL
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<AlunoReg> filtrar(AlunoRegFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoReg.class);
		
		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<AlunoReg> filtrados = criteria.list();
		//filtrados.forEach(u -> Hibernate.initialize(u.getGrupos()));
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	private void adicionarFiltro(AlunoRegFilter filtro, Criteria criteria) {
		if (filtro != null) {

			criteria.createAlias("aluno", "a", JoinType.LEFT_OUTER_JOIN);
			
			criteria.createAlias("aluno.pessoa", "p", JoinType.LEFT_OUTER_JOIN);
			criteria.addOrder(Order.asc("p.nome")); 
			
			if (!StringUtils.isEmpty(filtro.getCurso())) {
				criteria.add(Restrictions.eq("a.curso", filtro.getCurso()));
			}
						
			if (!StringUtils.isEmpty(filtro.getNome())) {
				// https://www.devmedia.com.br/hibernate-api-criteria-realizando-consultas/29627
				// criteria.createAlias("aluno.pessoa", "p", JoinType.LEFT_OUTER_JOIN);
				criteria.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getMatricula())) {
				criteria.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getOrientador())) {
				Criteria professorCrit  = criteria.createCriteria("orientador");
				Criteria pessoaCrit = professorCrit.createCriteria("pessoa");
				pessoaCrit.add(Restrictions.ilike("nome", filtro.getOrientador(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getPagante())) {
				criteria.add(Restrictions.eq("pagante", filtro.getPagante()));
			}
			
			if (!StringUtils.isEmpty(filtro.getLinha())) {
				Criteria cursoLinharCrit  = criteria.createCriteria("cursoLinhaPesquisa");
				Criteria linhaCrit = cursoLinharCrit.createCriteria("linhaPesquisa");
				linhaCrit.add(Restrictions.ilike("apelido", filtro.getLinha(), MatchMode.ANYWHERE));
			}
			
			if (filtro.isFlagMatricula()) { // condicoes para matricula
				criteria.add(Restrictions.and(Restrictions.ge("prazoConclusao", LocalDate.now()),
						                      Restrictions.eq("situacaoAlunoReg", SituacaoAlunoReg.A)
						));
			}

			/*
			if (filtro.isFlagMatricula()) { // condicoes para matricula
				criteria.add(Restrictions.and(Restrictions.ge("prazoConclusao", LocalDate.now()),
						                      Restrictions.isNull("dataHomologacao"),
						                      Restrictions.or(
						                    		  Restrictions.isNull("dataDesligamento"),
						                    		  Restrictions.and(
						                    				  Restrictions.isNotNull("dataDesligamento"),
						                    				  Restrictions.isNotNull("dataReativacao")	
						                        	  )
						                    	)  
						));
			}
			*/

		}
	}
	
	private Long total(AlunoRegFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(AlunoReg.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA GERAL

	
	
	// Filtrar e paginação - PESQUISA MATRICULA Periodo
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Matricula> filtrarMatriculaPeriodo(AlunoRegFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Matricula.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro2(filtro, criteria);
		
		List<Matricula> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total2(filtro));
	}
	
	private void adicionarFiltro2(AlunoRegFilter filtro, Criteria criteria) {
		
		criteria.createAlias("semestre", "s", JoinType.LEFT_OUTER_JOIN);
		
		Criteria alunoCrit = criteria.createCriteria("aluno");
		alunoCrit.createAlias("pessoa", "p", JoinType.LEFT_OUTER_JOIN);
		alunoCrit.createAlias("curso", "c", JoinType.LEFT_OUTER_JOIN);
		
		Criteria alunoRegCrit = criteria.createCriteria("alunoReg");
		
		criteria.add(Restrictions.isNotNull("alunoReg"));
		
		alunoCrit.addOrder(Order.asc("p.nome"));
		alunoCrit.addOrder(Order.asc("c.nome"));
		criteria.addOrder(Order.asc("s.periodo"));
		
		
		if (filtro != null) {
	
			if (!StringUtils.isEmpty(filtro.getNome())) {
				alunoCrit.add(Restrictions.ilike("p.nome", filtro.getNome(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getCurso())) {
				alunoCrit.add(Restrictions.eq("curso", filtro.getCurso()));
			}

			if (!StringUtils.isEmpty(filtro.getSemestreInicio()) &&
					!StringUtils.isEmpty(filtro.getSemestreFim())) {
				criteria.add(Restrictions.ge("s.periodo", filtro.getSemestreInicio().getPeriodo()));
				criteria.add(Restrictions.le("s.periodo", filtro.getSemestreFim().getPeriodo()));
			} else {
				if(!StringUtils.isEmpty(filtro.getSemestreInicio())) {
					criteria.add(Restrictions.eq("semestre", filtro.getSemestreInicio()));
				}
				if(!StringUtils.isEmpty(filtro.getSemestreFim())) {
					criteria.add(Restrictions.le("s.periodo", filtro.getSemestreFim().getPeriodo()));
				}
			}
			
			if (!StringUtils.isEmpty(filtro.getMatricula())) {
				alunoRegCrit.add(Restrictions.ilike("matricula", filtro.getMatricula(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getSituacaoAlunoReg())) {
				alunoRegCrit.add(Restrictions.eq("situacaoAlunoReg", filtro.getSituacaoAlunoReg()));
			}
			
		}
		
	}
	
	private Long total2(AlunoRegFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Matricula.class);
		adicionarFiltro2(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA MATRICULA SEMESTRE
	
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public List<Matricula> filtrarTodos(AlunoRegFilter filtro) {
	    // Criar um objeto Criteria para a entidade Matricula
	    Criteria criteria = manager.unwrap(Session.class).createCriteria(Matricula.class);

	    // Adicionar filtros com base no AlunoRegFilter
	    adicionarFiltro2(filtro, criteria);

	    // Retornar a lista completa de registros filtrados
	    return criteria.list();
	}


}
