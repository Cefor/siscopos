package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.Curso;

public class OrientacaoFilter {

	private Long idProfessor;
	private Curso curso;
	private String matricula;
	private String nome;
	private String linha;
	private String tipoOrientacao;
	
	
	public Long getIdProfessor() {
		return idProfessor;
	}
	public void setIdProfessor(Long idProfessor) {
		this.idProfessor = idProfessor;
	}
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getLinha() {
		return linha;
	}
	public void setLinha(String linha) {
		this.linha = linha;
	}
	public String getTipoOrientacao() {
		return tipoOrientacao;
	}
	public void setTipoOrientacao(String tipoOrientacao) {
		this.tipoOrientacao = tipoOrientacao;
	}

}
