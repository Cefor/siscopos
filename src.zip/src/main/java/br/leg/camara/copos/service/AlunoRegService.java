package br.leg.camara.copos.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.bridge.AlunoRegNovo;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.repository.filter.AlunoRegFilter;

public interface AlunoRegService {
	
	Page<AlunoReg> filtrar(AlunoRegFilter filtro, Pageable pageable);
	
	public void salvar(AlunoRegNovo alunoRegNovo);
	
	public void salvarEdicao(AlunoReg alunoReg);
	
	public void excluir(AlunoReg alunoReg);

	List<MatriculaDisciplina> historico(Long idAluno);

	Page<Matricula> filtrarMatriculaPeriodo(AlunoRegFilter filtro, Pageable pageable);

	List<Matricula> filtrarTodos(AlunoRegFilter filtro);

}
