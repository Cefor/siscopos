package br.leg.camara.copos.model.bridge;

import java.time.LocalDate;

import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Oferta;

public class AlunoRegMatricula {

	// Matricula
	private Long id;
	private AlunoReg alunoReg;
	private LocalDate dataMatricula;

	// MatriculaDisciplina
	private Oferta oferta;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public AlunoReg getAlunoReg() {
		return alunoReg;
	}

	public void setAlunoReg(AlunoReg alunoReg) {
		this.alunoReg = alunoReg;
	}

	public LocalDate getDataMatricula() {
		return dataMatricula;
	}

	public void setDataMatricula(LocalDate dataMatricula) {
		this.dataMatricula = dataMatricula;
	}

	public Oferta getOferta() {
		return oferta;
	}

	public void setOferta(Oferta oferta) {
		this.oferta = oferta;
	}
	
	
	
}
