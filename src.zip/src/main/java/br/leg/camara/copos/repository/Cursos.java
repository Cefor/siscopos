package br.leg.camara.copos.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Curso;

public interface Cursos extends JpaRepository<Curso, Long> {
	
	public Optional<Curso> findById(Long Id);
	
	public List<Curso> findByDataFimGreaterThanOrDataFimIsNull(LocalDate dataHoje);
	
	public List<Curso> findByLimiteOptativasEspecialGreaterThanAndDataFimGreaterThanOrDataFimIsNull(int limite, LocalDate dataHoje);
	
	public List<Curso> findByLimiteOptativasEspecialGreaterThan(int limite);
	
	public List<Curso> findAllByOrderByGrauNivelDescNomeAscSiglaAsc();
	
}
