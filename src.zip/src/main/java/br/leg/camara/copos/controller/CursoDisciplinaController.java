package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.CursoDisciplina;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.CursosDisciplinas;
import br.leg.camara.copos.repository.CursosLinhasPesquisa;
import br.leg.camara.copos.repository.Disciplinas;
import br.leg.camara.copos.repository.filter.CursoDisciplinaFilter;
import br.leg.camara.copos.service.CursoDisciplinaService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Controller
@RequestMapping("/cursodisciplina")
public class CursoDisciplinaController {


	@Autowired
	private Cursos cursos;
	
	@Autowired
	private CursosLinhasPesquisa cursosLinhasPesquisa;
	
	@Autowired
	private CursoDisciplinaService cursoDisciplinaService;

	@Autowired
	private Disciplinas disciplinas;

	@Autowired
	private CursosDisciplinas cursosDisciplinas;
	
	
	
	@RequestMapping("/nova/{idCurso}")
	public ModelAndView nova(CursoDisciplina cursoDisciplina, @PathVariable Long idCurso) {
		ModelAndView mv = new ModelAndView("cursodisciplina/CadastroCursoDisciplina");
		
		cursoDisciplina.setCurso(cursos.getOne(idCurso));

		mv.addObject("disciplinas", disciplinas.findByGrauCursoNivelGreaterThanEqualOrderByNomeAsc(cursoDisciplina.getCurso().getGrau().getNivel()));
		mv.addObject("simnao", SimNao.values());
		mv.addObject("cursoLinhasPesquisa", cursosLinhasPesquisa.findByCurso(cursoDisciplina.getCurso()));
		
		return mv;
	}

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid CursoDisciplina cursoDisciplina, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(cursoDisciplina, cursoDisciplina.getCurso().getId());
		}
	
		try {
			cursoDisciplinaService.salvar(cursoDisciplina);
		} catch (DuplicidadeIndiceUnicoException e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return nova(cursoDisciplina, cursoDisciplina.getCurso().getId());
		}
		
		attributes.addFlashAttribute("mensagem", "Disciplina adicionada com sucesso!");
		return new ModelAndView("redirect:/cursodisciplina/nova/" + cursoDisciplina.getCurso().getId());
	}
	 
	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(@PathVariable Long id) {
		CursoDisciplina cursoDisciplina = cursosDisciplinas.findOne(id);
		
		ModelAndView mv = nova(cursoDisciplina, cursoDisciplina.getCurso().getId());
		mv.addObject(cursoDisciplina);
		return mv;
	}
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") CursoDisciplina cursoDisciplina){
		try {
			cursoDisciplinaService.excluir(cursoDisciplina);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	
	
	@GetMapping
	public ModelAndView pesquisar(CursoDisciplinaFilter cursoDisciplinaFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("cursodisciplina/PesquisaCursoDisciplina");
		
		mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
		mv.addObject("tiposDisciplinas", TipoDisciplina.values());
		mv.addObject("simnao", SimNao.values());		
		
		PageWrapper<CursoDisciplina> paginaWrapper = new PageWrapper<>(cursoDisciplinaService.filtrar(cursoDisciplinaFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}

	
	
	
	
}
