package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.model.entity.OfertaProfessor;
import br.leg.camara.copos.repository.OfertasProfessores;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.Ofertas;
import br.leg.camara.copos.repository.ProfessoresSituacoes;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.SituacoesProfessores;
import br.leg.camara.copos.repository.filter.OfertaFilter;
import br.leg.camara.copos.service.OfertaProfessorService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.IncompatibilidadeCargaHorariaException;

@Controller
@RequestMapping("/ofertaprofessor")
public class OfertaProfessorController {

	@Autowired
	private OfertaProfessorService ofertaProfessorService;
	
	@Autowired
	private Ofertas ofertas;
	
	@Autowired
	private ProfessoresSituacoes professoresSituacao;
	
	@Autowired
	private SituacoesProfessores situacoesProfessor;
		
	@Autowired
	private OfertasProfessores ofertasProfessores;
	
	@Autowired
	private Cursos cursos;

	@Autowired
	private Semestres semestres;
	
	
	@RequestMapping("/nova/{idOferta}")
	public ModelAndView nova(OfertaProfessor ofertaProfessor, @PathVariable Long idOferta) {
		
		ModelAndView mv = new ModelAndView("ofertaprofessor/CadastroOfertaProfessor");
		
		Oferta oferta = ofertas.getOne(idOferta);
		ofertaProfessor.setOferta(oferta);
		
		mv.addObject("professoresSituacao",  professoresSituacao.
				findByDataFimAndProfessorCursoAndSituacaoProfessorNotOrderByProfessorPessoaNome(null, oferta.getCursoDisciplina().getCurso(),situacoesProfessor.findBySituacao("Inativo")));
		mv.addObject("ofertaProfessores", ofertasProfessores.findByOfertaOrderByProfessorPessoaNome(oferta));
		
		return mv;
	}
	
	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid OfertaProfessor ofertaProfessor, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(ofertaProfessor, ofertaProfessor.getOferta().getId());
		}

		try {
			ofertaProfessorService.salvar(ofertaProfessor);
		} catch (DuplicidadeIndiceUnicoException e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return nova(ofertaProfessor, ofertaProfessor.getOferta().getId());
		} catch (IncompatibilidadeCargaHorariaException e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return nova(ofertaProfessor, ofertaProfessor.getOferta().getId());			
		}

		attributes.addFlashAttribute("mensagem", "Oferta-professor salva com sucesso.");
		return new ModelAndView("redirect:/ofertaprofessor/nova/" + ofertaProfessor.getOferta().getId());
	}

	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(OfertaProfessor ofertaProfessor, @PathVariable Long id) {
		
		ofertaProfessor = ofertasProfessores.findOne(id);
		
		ModelAndView mv = nova(ofertaProfessor, ofertaProfessor.getOferta().getId());
		
		mv.addObject(ofertaProfessor);
		
		return mv;
	}

	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") OfertaProfessor ofertaProfessor) {
		try {
			ofertaProfessorService.excluir(ofertaProfessor);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	
	@GetMapping
	public ModelAndView pesquisar(OfertaFilter ofertaFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		
		ModelAndView mv = new ModelAndView("ofertaprofessor/PesquisaOfertaProfessor");
		
		mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
		mv.addObject("semestres", semestres.findByOrderByAnoDescSemestreDesc());
		
		PageWrapper<OfertaProfessor> paginaWrapper = new PageWrapper<>(ofertaProfessorService.filtrar(ofertaFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;

	}
	
	
}
