package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;

public interface Matriculas extends JpaRepository<Matricula, Long> {
	
	public Optional<Matricula> findByAlunoAndSemestre(Aluno aluno, SemestrePeriodo semestre);
	
	// usado para verificacao da quantidade de trancamentos
	List<Matricula> findByAlunoCursoAndAlunoRegSituacaoAlunoRegOrderByAlunoRegAscSemestrePeriodoDesc(Curso curso, SituacaoAlunoReg situacaoAlunoReg);
	
	

}
