package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.GrausCursos;
import br.leg.camara.copos.repository.filter.CursoFilter;
import br.leg.camara.copos.service.CursoService;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.LimiteOptativasEspecialException;
import br.leg.camara.copos.service.exception.LimiteOptativasEspecialSemestreException;

@Controller
@RequestMapping("/curso")
public class CursoController {


	@Autowired
	private CursoService cursoService;

	@Autowired
	private Cursos cursos;	

	@Autowired
	private GrausCursos grausCursos;
	
    @Value("${pasta.raiz.origem}")
    private String pastaRaizOrigem;
    
    @Value("${pasta.raiz.espelho}")
    private String pastaRaizEspelho;
    
    @Value("${pasta.cursos}")
    private String pastaCursos;
	
	
	@RequestMapping("/novo")
	public ModelAndView novo(Curso curso) {
		ModelAndView mv = new ModelAndView("curso/CadastroCurso");
		
		mv.addObject("graus", grausCursos.findAll());
							
		return mv;
	}

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid Curso curso, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return novo(curso);
		}
	
		try {
			cursoService.salvar(curso);
		} catch (LimiteOptativasEspecialException e) {
			result.rejectValue("limiteOptativasEspecial", e.getMessage(), e.getMessage());
			return novo(curso);
		} catch (LimiteOptativasEspecialSemestreException e) {
			result.rejectValue("limiteOptativasEspecialSemestre", e.getMessage(), e.getMessage());
			return novo(curso);
		}
		
		
		attributes.addFlashAttribute("mensagem", "Curso salvo com sucesso!");
		return new ModelAndView("redirect:/curso/novo");
	}	
	
	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(@PathVariable Long id) {
		Curso curso = cursos.findOne(id);
		
		ModelAndView mv = novo(curso);
		mv.addObject(curso);
		return mv;
	}
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") Curso curso){
		try {
			cursoService.excluir(curso);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	
		
	@GetMapping
	public ModelAndView pesquisar(CursoFilter cursoFilter,BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("curso/PesquisaCurso");

		
		mv.addObject("graus", grausCursos.findAll());
		
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaCursos", pastaCursos);

		
		PageWrapper<Curso> paginaWrapper = new PageWrapper<>(cursoService.filtrar(cursoFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}
	
	
	
}
