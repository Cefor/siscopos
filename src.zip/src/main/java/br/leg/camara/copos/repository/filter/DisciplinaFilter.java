package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.GrauCurso;
import br.leg.camara.copos.model.enums.TipoDisciplina;

public class DisciplinaFilter {

	private TipoDisciplina tipo;
	private String sigla;
	private String nome;
	private GrauCurso grauCurso;
	
	public TipoDisciplina getTipo() {
		return tipo;
	}
	public void setTipo(TipoDisciplina tipo) {
		this.tipo = tipo;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public GrauCurso getGrauCurso() {
		return grauCurso;
	}
	public void setGrauCurso(GrauCurso grauCurso) {
		this.grauCurso = grauCurso;
	}
	
	
	
	
}
