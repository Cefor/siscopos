package br.leg.camara.copos.service.impl;

import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.OcorrenciaReg;
import br.leg.camara.copos.repository.OcorrenciasReg;
import br.leg.camara.copos.repository.filter.OcorrenciaRegFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.OcorrenciaRegService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;

@Service
public class OcorrenciaRegServiceImpl implements OcorrenciaRegService{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;
		
	@Autowired
	private OcorrenciasReg ocorrenciasReg;
	
	
	@Override
	@Transactional
	public void salvar(OcorrenciaReg ocorrenciaReg) {

		if(ocorrenciasReg.findByAlunoRegAndTipoOcorrenciaRegAndDataOcorrencia(ocorrenciaReg.getAlunoReg(), ocorrenciaReg.getTipoOcorrenciaReg(), ocorrenciaReg.getDataOcorrencia()).isPresent() &&
				ocorrenciaReg.isNova()) {
			DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			throw new DuplicidadeIndiceUnicoException("Já existe ocorrência desse tipo associada à data " + ocorrenciaReg.getDataOcorrencia().format(dtFormatter));
		}
		
		ocorrenciasReg.save(ocorrenciaReg);
	}
	
	
	@Override
	@Transactional
	public void excluir(OcorrenciaReg ocorrenciaReg) {
		ocorrenciasReg.delete(ocorrenciaReg);
		ocorrenciasReg.flush();
	}
	
	
	
	
	// Filtrar e paginação - PESQUISA
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<OcorrenciaReg> filtrar(OcorrenciaRegFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(OcorrenciaReg.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<OcorrenciaReg> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}


	private void adicionarFiltro(OcorrenciaRegFilter filtro, Criteria criteria) {
		
		Criteria alunoRegCrit = criteria.createCriteria("alunoReg");
		Criteria alunoCrit = alunoRegCrit.createCriteria("aluno");
		Criteria pessoaCrit = alunoCrit.createCriteria("pessoa");
		
		criteria.addOrder(Order.asc("dataOcorrencia"));
		
		
		if (filtro != null) {
			
			if (!StringUtils.isEmpty(filtro.getCurso())) {
				alunoCrit.add(Restrictions.eq("curso", filtro.getCurso()));
			}
			
			if (!StringUtils.isEmpty(filtro.getTipoOcorrenciaReg())) {
				criteria.add(Restrictions.eq("tipoOcorrenciaReg", filtro.getTipoOcorrenciaReg()));
			}
			
			if (!StringUtils.isEmpty(filtro.getNomeAlunoReg())) {
				pessoaCrit.add(Restrictions.ilike("nome", filtro.getNomeAlunoReg(), MatchMode.ANYWHERE));	
			}
			
			if (!StringUtils.isEmpty(filtro.getDataInicio())) {
				criteria.add(Restrictions.ge("dataOcorrencia", filtro.getDataInicio()));
			}
			
			if (!StringUtils.isEmpty(filtro.getDataFim())) {
				criteria.add(Restrictions.le("dataOcorrencia", filtro.getDataFim()));
			}

			
		}
		
	}
	
	
	private Long total(OcorrenciaRegFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(OcorrenciaReg.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação - PESQUISA
	
	
	
}
