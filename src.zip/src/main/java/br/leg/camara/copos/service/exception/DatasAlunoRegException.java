package br.leg.camara.copos.service.exception;

public class DatasAlunoRegException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public DatasAlunoRegException(String message) {
		super(message);
	}

}
