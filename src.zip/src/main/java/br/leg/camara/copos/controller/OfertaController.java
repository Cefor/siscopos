package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.model.enums.Turma;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.CursosDisciplinas;
import br.leg.camara.copos.repository.Ofertas;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.filter.OfertaFilter;
import br.leg.camara.copos.service.OfertaService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.IncompatibilidadeCargaHorariaException;

@Controller
@RequestMapping("/oferta")
public class OfertaController {

	@Autowired
	private OfertaService ofertaService;
	
	@Autowired
	private Cursos cursos;
	
	@Autowired
	private Semestres semestres;
	
	@Autowired
	private CursosDisciplinas cursosDisciplinas;
	
	@Autowired
	private Ofertas ofertas;

    @Value("${pasta.raiz.origem}")
    private String pastaRaizOrigem;
    
    @Value("${pasta.raiz.espelho}")
    private String pastaRaizEspelho;
    
    @Value("${pasta.ofertas}")
    private String pastaOfertas;
	
	// qdo chamado pela tela de cadastro de oferta tem parametros
	@GetMapping
	public ModelAndView pesquisar(OfertaFilter ofertaFilter, BindingResult result,
			@PageableDefault(size = 30) Pageable pageable, HttpServletRequest httpServletRequest,
			@RequestParam(value = "idCurso", required = false) Long idCurso, 
			@RequestParam(value = "idSemestre", required = false) Long idSemestre) {
		ModelAndView mv = new ModelAndView("oferta/PesquisaOferta");
		
		mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
		mv.addObject("semestres", semestres.findByOrderByAnoDescSemestreDesc());
		mv.addObject("tipos", TipoDisciplina.values());
		
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaOfertas", pastaOfertas);
	
		if(idCurso != null && idSemestre != null) {
			ofertaFilter.setCurso(cursos.findById(idCurso).get());
			ofertaFilter.setSemestre(semestres.findById(idSemestre).get());
		}
				
		PageWrapper<Oferta> paginaWrapper = new PageWrapper<>(ofertaService.filtrar(ofertaFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}	
	
	
	
	@RequestMapping("/nova/{idCurso}/{idSemestre}")
	public ModelAndView nova(Oferta oferta, 
                             @PathVariable Long idCurso, 
                             @PathVariable Long idSemestre) {
		ModelAndView mv = new ModelAndView("oferta/CadastroOferta");
		
		Curso curso = cursos.findById(idCurso).get();
		
		oferta.setSemestre(semestres.findById(idSemestre).get());
		
		mv.addObject("curso", curso);
		mv.addObject("cursoDisciplinas", cursosDisciplinas.findByCursoAndFlagAtivaOrderByDisciplinaTipoAscDisciplinaSiglaAsc(curso, SimNao.S));
		mv.addObject("cursoDisciplinasSubtitulo", cursosDisciplinas.findByCursoAndFlagAtivaOrderByDisciplinaTipoAscDisciplinaSiglaAsc(curso, SimNao.N));
		mv.addObject("turmas", Turma.values());
		
		return mv;
	}

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid Oferta oferta, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(oferta, oferta.getCursoDisciplina().getCurso().getId(), oferta.getSemestre().getId());
		}

		try {
			ofertaService.salvar(oferta);
		} catch (DuplicidadeIndiceUnicoException e) {
			result.rejectValue("id", e.getMessage(), e.getMessage());
			return nova(oferta, oferta.getCursoDisciplina().getCurso().getId(), oferta.getSemestre().getId());
		} catch (IncompatibilidadeCargaHorariaException e) {
			result.rejectValue("id", e.getMessage(), e.getMessage());
			return nova(oferta, oferta.getCursoDisciplina().getCurso().getId(), oferta.getSemestre().getId());
		}

		attributes.addFlashAttribute("mensagem", "Oferta salva com sucesso: " + 
		                                         oferta.getCursoDisciplina().getDisciplina().getSigla() + " - " +
		                                         oferta.getSemestre().getPeriodo()
		                                         );
		return new ModelAndView("redirect:/oferta/nova/" + 
		                        oferta.getCursoDisciplina().getCurso().getId() +
		                        "/" + oferta.getSemestre().getId());
	}
	
	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(Oferta oferta, @PathVariable Long id) {
		
		oferta = ofertas.findOne(id);
		
		ModelAndView mv = nova(oferta, oferta.getCursoDisciplina().getCurso().getId(), oferta.getSemestre().getId());
		
		mv.addObject(oferta);
		
		return mv;
	}
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") Oferta oferta) {
		try {
			ofertaService.excluir(oferta);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
}
