package br.leg.camara.copos.model.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "curso_linhapesquisa")
public class CursoLinhaPesquisa {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_curso")
	private Curso curso;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_linhapesquisa")
	private LinhaPesquisa linhaPesquisa;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public LinhaPesquisa getLinhaPesquisa() {
		return linhaPesquisa;
	}

	public void setLinhaPesquisa(LinhaPesquisa linhaPesquisa) {
		this.linhaPesquisa = linhaPesquisa;
	}

	@Override
	public String toString() {
		return "CursoLinhaPesquisa [id=" + id + ", curso=" + curso + ", linhaPesquisa=" + linhaPesquisa + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(curso, id, linhaPesquisa);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CursoLinhaPesquisa other = (CursoLinhaPesquisa) obj;
		return Objects.equals(curso, other.curso) && Objects.equals(id, other.id)
				&& Objects.equals(linhaPesquisa, other.linhaPesquisa);
	}

	
	
}
