package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Pessoa;

public interface Pessoas extends JpaRepository<Pessoa, Long> {

	public Optional<Pessoa> findByNumeroDocumento(String numeroDocumento);
	
	public Optional<Pessoa> findByCpf(String cpf);

	public List<Pessoa> findByNomeStartingWithIgnoreCase(String nome);
	
	public List<Pessoa> findByNomeContainingIgnoreCase(String nome);
	
	public Optional<Pessoa> findByCodigo(Long codigo);

}
