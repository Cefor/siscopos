package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import br.leg.camara.copos.model.enums.SimNao;

@Entity
@Table(name = "semestre")
public class SemestrePeriodo {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "ano", length = 4)
	@NotBlank(message = "Ano obrigatório")
	private String ano;
	
	@Column(name = "semestre", length = 1)
	@NotBlank(message = "Semestre obrigatório")
	private String semestre;
	
	@Column(name = "periodo", length = 6)
	private String periodo;
	
	@NotNull(message = "Informar se está aberto para matrícula")
	@Column(name = "flag_matricula", length = 1)
	@Enumerated(EnumType.STRING)
	private SimNao flagMatricula;
	

	@PrePersist @PreUpdate
	private void prePersistPreUpdate() {
		this.periodo = this.ano.concat("/").concat(semestre); 
	}
	
	public LocalDate getDia1() {
		int ano = Integer.parseInt(this.ano);
		int mes = (int) Math.pow(Double.parseDouble(this.semestre), 2.81);
		return LocalDate.of(ano, mes, 1);
	}
	
	public LocalDate getUltimoDia() {
		int ano = Integer.parseInt(this.ano);
		
		if(this.semestre.equals("1")) {
			return LocalDate.of(ano, 6, 30);	
		} else {
			return LocalDate.of(ano, 12, 31);
		}
	}
	
	public boolean isNovo() {
		return id == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public String getSemestre() {
		return semestre;
	}

	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public SimNao getFlagMatricula() {
		return flagMatricula;
	}

	public void setFlagMatricula(SimNao flagMatricula) {
		this.flagMatricula = flagMatricula;
	}

	@Override
	public String toString() {
		return "SemestrePeriodo [id=" + id + ", ano=" + ano + ", semestre=" + semestre + ", periodo=" + periodo
				+ ", flagMatricula=" + flagMatricula + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(ano, flagMatricula, id, periodo, semestre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SemestrePeriodo other = (SemestrePeriodo) obj;
		return Objects.equals(ano, other.ano) && flagMatricula == other.flagMatricula && Objects.equals(id, other.id)
				&& Objects.equals(periodo, other.periodo) && Objects.equals(semestre, other.semestre);
	}
	
}
