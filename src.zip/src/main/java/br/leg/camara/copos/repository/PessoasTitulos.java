package br.leg.camara.copos.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.PessoaTitulo;

public interface PessoasTitulos extends JpaRepository<PessoaTitulo, Long> {
	
	public List<PessoaTitulo> findByPessoaOrderByDataTitulacaoAsc(Pessoa pessoa);
	
	public Optional<PessoaTitulo> findByPessoaAndDataTitulacao(Pessoa pessoa, LocalDate dataTitulacao);
	
	public List<PessoaTitulo> findByPessoaAndDataTitulacaoLessThanEqualOrderByGrauCursoGrauDesc(Pessoa pessoa, LocalDate dataTitulacao);

	public List<PessoaTitulo> findByPessoaIn(List<Pessoa> collect);

}
