package br.leg.camara.copos.controller;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.repository.MatriculasDisciplinas;
import br.leg.camara.copos.repository.Ofertas;
import br.leg.camara.copos.service.MatriculaDisciplinaService;

@Controller
@RequestMapping("/pautas")
public class PautaController {
	
	@Autowired
	private MatriculasDisciplinas matriculasDisciplinas;
	
	@Autowired
	private Ofertas ofertas;
	
	@Autowired
	private MatriculaDisciplinaService matriculaDisciplinaService;
		

	
	@GetMapping("{idOferta}")
	public ModelAndView pesquisar(@PathVariable Long idOferta) {
		ModelAndView mv = new ModelAndView("pauta/Pauta");
		
		mv.addObject("matriculasDisciplina", 
				      matriculasDisciplinas.findByOfertaOrderByMatriculaAlunoPessoaNomeAsc(ofertas.getOne(idOferta))
				     );
		
		return mv;
	}



	@GetMapping("/editar/{id}")
	public ModelAndView editar(MatriculaDisciplina matriculaDisciplina, 
			                   @PathVariable Long id,
			                   @RequestHeader(value = "Referer", required = false) String referer) {
		
		String path = null;
		
		// verifica a url de origem: pode ser "pauta" ou "matricula em disciplina - regular"  
		if (referer != null) {
				try {
					URL url = new URL(referer);
					path = url.getPath();
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}
        } 
		
		
		ModelAndView mv = new ModelAndView("pauta/Mencao");
		
		if(id != null) {
			matriculaDisciplina = matriculasDisciplinas.findOne(id);	
			mv.addObject(matriculaDisciplina);
		}
		
		mv.addObject("path", path);
		
		List<String> mencoes = new ArrayList<>();

		if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getTipo().equals(TipoDisciplina.DISC)) {
			mencoes.add("");
			mencoes.add("CS");
		} else if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getTipo().equals(TipoDisciplina.CCCM)) {
			
			if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("EQUALI") ||
				  matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("DEFESA")) {
				mencoes.add("AP");
				mencoes.add("RP");
			} else { // se nao, eh ATIVCO ou APROVE
				mencoes.add("CC");
			}
		} // se for CCSM (ATIVOR e TRANCA) nao tem mencao

		
		mv.addObject("mencoes", mencoes);
		
		return mv;
	}
	
	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid MatriculaDisciplina matriculaDisciplina, 
			                   BindingResult result, 
			                   RedirectAttributes attributes,
			                   @RequestParam String path) { // no Thymeleaf o parametro path eh um input type="text" 
		if (result.hasErrors()) {
			return editar(matriculaDisciplina, null, "http://localhost:8080" + path);
		}

		
		try {
			matriculaDisciplinaService.salvar(matriculaDisciplina);
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return editar(matriculaDisciplina, null, "http://localhost:8080" + path);
		}

		
		attributes.addFlashAttribute("mensagem", "Menção lançada na disciplina: " + matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla());
		return new ModelAndView("redirect:" + path.replace("/copos", ""));
	}

	
	
}
