package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Pessoa;
import br.leg.camara.copos.model.entity.Professor;

public interface Professores extends JpaRepository<Professor, Long> {
	
	public List<Professor> findByCursoOrderByPessoaNome(Curso curso);
	
	public Optional<Professor> findByCursoAndPessoa(Curso curso, Pessoa pessoa);

	public List<Professor> findByCurso(Curso curso);
	
}
