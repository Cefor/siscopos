package br.leg.camara.copos.service.impl;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.filter.SemestreFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.SemestreService;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.SemestreJaCadastradoException;

@Service
public class SemestreServiceImpl implements SemestreService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;

	
	@Autowired
	private Semestres semestres;
	
	
	@Override
	@Transactional
	public void salvar(SemestrePeriodo semestre) {
		
		if(semestre.getId() == null &&
		   semestres.findByAnoAndSemestre(semestre.getAno(), semestre.getSemestre()).isPresent()) {
			throw new SemestreJaCadastradoException("Semestre já cadastrado: " + semestre.getAno() + '/' + semestre.getSemestre());
		}
		
		semestres.save(semestre);
	}
	
	@Override
	@Transactional
	public void excluir(SemestrePeriodo semestre) {
		try {
			semestres.delete(semestre);
			semestres.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Semestre já foi associado a outra entidade.");
		}
	}
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<SemestrePeriodo> filtrar(SemestreFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(SemestrePeriodo.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<SemestrePeriodo> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	
	private void adicionarFiltro(SemestreFilter filtro, Criteria criteria) {
		
		criteria.addOrder(Order.desc("ano"));
		criteria.addOrder(Order.desc("semestre"));
		
		if (filtro != null) {
	
			if (!StringUtils.isEmpty(filtro.getAno())) {
				criteria.add(Restrictions.ilike("ano", filtro.getAno(), MatchMode.ANYWHERE));
			}

			if (!StringUtils.isEmpty(filtro.getSemestre())) {
				criteria.add(Restrictions.eq("semestre", filtro.getSemestre()));
			}
			
			if (!StringUtils.isEmpty(filtro.getFlagMatricula())) {
				criteria.add(Restrictions.eq("flagMatricula", filtro.getFlagMatricula()));
			}
		}
		
	}
	
		
	private Long total(SemestreFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(SemestrePeriodo.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação


	
}
