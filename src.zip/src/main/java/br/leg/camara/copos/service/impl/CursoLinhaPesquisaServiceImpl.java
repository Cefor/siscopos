package br.leg.camara.copos.service.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import br.leg.camara.copos.model.entity.CursoLinhaPesquisa;
import br.leg.camara.copos.repository.CursosLinhasPesquisa;
import br.leg.camara.copos.service.CursoLinhaPesquisaService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Service
public class CursoLinhaPesquisaServiceImpl implements CursoLinhaPesquisaService{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private CursosLinhasPesquisa cursosLinhasPesquisa;
	
	
	
	@Override
	@Transactional
	public void salvar(CursoLinhaPesquisa cursoLinhaPesquisa) {
		
		if(cursosLinhasPesquisa.findByCursoAndLinhaPesquisa(cursoLinhaPesquisa.getCurso(), cursoLinhaPesquisa.getLinhaPesquisa()).isPresent()) {
			throw new DuplicidadeIndiceUnicoException("Linha de pesquisa já cadastrada para o curso");
		}
		
		cursosLinhasPesquisa.save(cursoLinhaPesquisa);
		
	}
	
	
	

	@Override
	@Transactional
	public void excluir(CursoLinhaPesquisa cursoLinhaPesquisa) {
		try {
			cursosLinhasPesquisa.delete(cursoLinhaPesquisa);
			cursosLinhasPesquisa.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Linha de pesquisa já foi associada a outra entidade.");
		}

	}


	
}
