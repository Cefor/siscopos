package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.TipoDisciplina;

public class CursoDisciplinaFilter {

	private Curso curso;
	private String siglaDisciplina;
	private String nomeDisciplina;
	private TipoDisciplina tipoDisciplina;
	private SimNao flagObrigatoria;
	private String apelidoLinhaPesquisa;
	private SimNao flagAtiva;
	
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public String getSiglaDisciplina() {
		return siglaDisciplina;
	}
	public void setSiglaDisciplina(String siglaDisciplina) {
		this.siglaDisciplina = siglaDisciplina;
	}
	public String getNomeDisciplina() {
		return nomeDisciplina;
	}
	public void setNomeDisciplina(String nomeDisciplina) {
		this.nomeDisciplina = nomeDisciplina;
	}
	public TipoDisciplina getTipoDisciplina() {
		return tipoDisciplina;
	}
	public void setTipoDisciplina(TipoDisciplina tipoDisciplina) {
		this.tipoDisciplina = tipoDisciplina;
	}
	public SimNao getFlagObrigatoria() {
		return flagObrigatoria;
	}
	public void setFlagObrigatoria(SimNao flagObrigatoria) {
		this.flagObrigatoria = flagObrigatoria;
	}
	public String getApelidoLinhaPesquisa() {
		return apelidoLinhaPesquisa;
	}
	public void setApelidoLinhaPesquisa(String apelidoLinhaPesquisa) {
		this.apelidoLinhaPesquisa = apelidoLinhaPesquisa;
	}
	public SimNao getFlagAtiva() {
		return flagAtiva;
	}
	public void setFlagAtiva(SimNao flagAtiva) {
		this.flagAtiva = flagAtiva;
	}
	
		
}
