package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.PessoaTitulo;
import br.leg.camara.copos.repository.filter.PessoaTituloFilter;

public interface PessoaTituloService {

	void salvar(PessoaTitulo pessoaTitulo);

	void excluir(PessoaTitulo pessoaTitulo);

	Page<PessoaTitulo> filtrarProfessor(PessoaTituloFilter filtro, Pageable pageable);

}
