package br.leg.camara.copos.model.enums;

public enum SituacaoAlunoReg {

	A("Ativo"),
	E("Egresso"),
	D("Desligado"),
	X("Desconhecido");

	private String descricao;
	
	SituacaoAlunoReg(String descricao) {
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return descricao;
	}

}

