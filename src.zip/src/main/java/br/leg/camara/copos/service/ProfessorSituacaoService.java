package br.leg.camara.copos.service;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.ProfessorSituacao;
import br.leg.camara.copos.repository.filter.ProfessorSituacaoFilter;

public interface ProfessorSituacaoService {

	void salvar(ProfessorSituacao professorSituacao);

	void excluir(ProfessorSituacao professorSituacao);

	Page<ProfessorSituacao> filtrar(ProfessorSituacaoFilter filtro, Pageable pageable);



}
