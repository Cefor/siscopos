package br.leg.camara.copos.model.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "oferta_professor")
public class OfertaProfessor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_oferta")
	private Oferta oferta;
	
	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_professor")
	private Professor professor;
	
    @Column(name = "cargahoraria")
	private Float cargahoraria;

	
	public boolean isNova() {
		return id == null;
	}
    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Oferta getOferta() {
		return oferta;
	}

	public void setOferta(Oferta oferta) {
		this.oferta = oferta;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public Float getCargahoraria() {
		return cargahoraria;
	}

	public void setCargahoraria(Float cargahoraria) {
		this.cargahoraria = cargahoraria;
	}

	@Override
	public String toString() {
		return "OfertaProfessor [id=" + id + ", oferta=" + oferta + ", professor=" + professor + ", cargahoraria="
				+ cargahoraria + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cargahoraria, id, oferta, professor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OfertaProfessor other = (OfertaProfessor) obj;
		return Objects.equals(cargahoraria, other.cargahoraria) && Objects.equals(id, other.id)
				&& Objects.equals(oferta, other.oferta) && Objects.equals(professor, other.professor);
	}
    
    
    
}
