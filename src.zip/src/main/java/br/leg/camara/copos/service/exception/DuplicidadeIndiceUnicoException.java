package br.leg.camara.copos.service.exception;

public class DuplicidadeIndiceUnicoException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public DuplicidadeIndiceUnicoException(String message) {
		super(message);
	}

}
