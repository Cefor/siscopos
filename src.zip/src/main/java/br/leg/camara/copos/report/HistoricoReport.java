package br.leg.camara.copos.report;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.lowagie.text.Anchor;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.RGBColor;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.entity.PessoaTitulo;
import br.leg.camara.copos.model.entity.Usuario;
import br.leg.camara.copos.model.enums.Sexo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.PessoasTitulos;
import br.leg.camara.copos.repository.Usuarios;
import br.leg.camara.copos.service.AlunoRegService;


@Service
public class HistoricoReport {

	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private AlunoRegService alunoRegService;  
	
	@Autowired
	private AlunosReg alunosReg;
	
	@Autowired
	private Usuarios usuarios;

	@Autowired
	private PessoasTitulos pessoasTitulos;
	
	
	private Aluno aluno;
	private AlunoReg alunoReg;
	private Document document;
	private List<MatriculaDisciplina> historico;
	private float totalCreditos;
	private LocalDate dataConclusao;

	
	public void imprimir(HttpServletResponse response, Aluno aluno) throws IOException, DocumentException {

		this.aluno = aluno;
		this.alunoReg = alunosReg.findByAluno(this.aluno).get();
		this.document = new Document(PageSize.A4, 12, 12, 15, 20); // left, right, top, bottom
		this.historico = alunoRegService.historico(aluno.getId());
		this.totalCreditos = 0;
		this.dataConclusao = null;

        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        
        this.cabecalho();
        this.dadosCadastraisAluno();
        this.dadosCurso();
        this.componentesCurriculares();
        this.dadosTCC();
        this.conclusaoCurso();
        this.legenda();
        this.emissao();
        
        document.close();

	}

	

	private void cabecalho() {
		
		try {
			//Image img = Image.getInstance("static/images/brazao.jpg");
			Image img = Image.getInstance(getClass().getResource("/static/images/brazao.jpg"));
			
	        // Cria uma tabela com 1 linha e 2 colunas
	        PdfPTable table = new PdfPTable(2);
	        table.setWidthPercentage(100);
	        table.setWidths(new float[] {0.7f, 6f});
	        
	        // Primeira coluna: imagem
	        img.scaleAbsolute(52, 52); // ajusta o tamanho da imagem conforme necessário
	        PdfPCell cellImage = new PdfPCell(img);
	        cellImage.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cellImage);

	        // Segunda coluna: texto
	        Font font = FontFactory.getFont(FontFactory.TIMES, 8, Font.NORMAL);
	        Paragraph paragraph1 = new Paragraph("Câmara dos Deputados", font);
	        Paragraph paragraph2 = new Paragraph("Centro de Formação, Treinamento e Aperfeiçoamento", font);
	        Paragraph paragraph3 = new Paragraph("Programa de Pós-Graduação", font);
	        Paragraph paragraph4 = new Paragraph("Via N3, Projeção L, SGMN, Complexo Avançado da Câmara dos Deputados, Prédio do Cefor, Sala 2", font);
	        Paragraph paragraph5 = new Paragraph("Telefone: 55(61) 3216-7679", font);
	        Paragraph paragraph6 = new Paragraph();
	        
	        Anchor anchor = new Anchor(new Phrase("www.camara.leg.br/posgraduacao", FontFactory.getFont(FontFactory.TIMES, 8, Font.UNDERLINE, RGBColor.BLUE)));
	        anchor.setReference("http://www.camara.leg.br/posgraduacao");
	        paragraph6.add(anchor);
	        
	        // altura das linhas
	        paragraph1.setLeading(6);
	        paragraph2.setLeading(8);
	        paragraph3.setLeading(8);
	        paragraph4.setLeading(8);
	        paragraph5.setLeading(8);
	        paragraph6.setLeading(8);
	        
	        // adiciona os paragrafos aa segunda coluna
	        PdfPCell cellText = new PdfPCell();
	        cellText.setVerticalAlignment(Element.ALIGN_TOP);
	        cellText.addElement(paragraph1);
	        cellText.addElement(paragraph2);
	        cellText.addElement(paragraph3);
	        cellText.addElement(paragraph4);
	        cellText.addElement(paragraph5);
	        cellText.addElement(paragraph6);
	        cellText.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cellText);
	        
	        // Adiciona a tabela ao documento
	        document.add(table);
	        
	        // Adicione uma quebra de linha apos o cabeçalho
	        document.add(Chunk.NEWLINE);
	        
	        // Criar a tabela com 2 linhas e 1 coluna
            PdfPTable table2 = new PdfPTable(1);
	        table2.setWidthPercentage(100);

            Font font2 = FontFactory.getFont(FontFactory.TIMES, 10, Font.BOLD);
            
            // Adicionar a primeira linha
            PdfPCell cell1 = new PdfPCell(new Paragraph("HISTÓRICO ESCOLAR DE PÓS-GRADUAÇÃO", font2));
	        cell1.setPaddingTop(0);
            cell1.setBorder(Rectangle.NO_BORDER);
            cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            cell1.setMinimumHeight(14);
            cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
            table2.addCell(cell1);
            
           	// Adicionar a segunda linha
            PdfPCell cell2 = new PdfPCell(new Paragraph(aluno.getCurso().getNome().toUpperCase(), font2));
            cell2.setPaddingTop(0);
            cell2.setBorder(Rectangle.NO_BORDER);
            cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            cell1.setMinimumHeight(14);
            table2.addCell(cell2);

            table2.setSpacingBefore(3);
            
            // Adicionar a tabela ao documento
            document.add(table2);
	        
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        

	}
	
		
	private void dadosCadastraisAluno() {

		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);
        
        // fontes
        Font font1 = FontFactory.getFont(FontFactory.TIMES, 8, Font.BOLD);
        font1.setColor(RGBColor.BLUE);
        Font font2 = FontFactory.getFont(FontFactory.TIMES, 9);
        Font font3 = FontFactory.getFont(FontFactory.TIMES, 9, Font.BOLD);
        
        // Linha titulo do bloco
        String titulo = "DADOS CADASTRAIS ";
        
        if(this.aluno.getPessoa().getSexo().equals(Sexo.F)) {
        	titulo = titulo.concat("DA ALUNA");
        } else {
        	titulo = titulo.concat("DO ALUNO");
        }
        
        PdfPCell cell1 = new PdfPCell(new Paragraph(titulo, font1));
        cell1.setColspan(12);
        cell1.setPaddingTop(0);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell1.setMinimumHeight(11);
        cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table.addCell(cell1);

        document.add(table);
        
        // linhas com dados
		PdfPTable table2 = new PdfPTable(12);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(1);
        
		// linha 1
        PdfPCell cell2 = new PdfPCell(new Paragraph("Nome:", font2));
        cell2.setColspan(2);
        cell2.setPaddingTop(1);
        cell2.setBorderWidth((float) 0.1);
        cell2.setBorderColor(RGBColor.LIGHT_GRAY);
        cell2.setMinimumHeight(11);
        cell2.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell2);
        PdfPCell cell3 = new PdfPCell(new Paragraph(this.aluno.getPessoa().getNome(), font3));
        cell3.setColspan(10);
        cell3.setPaddingTop(1);
        cell3.setBorderWidth((float) 0.1);
        cell3.setBorderColor(RGBColor.LIGHT_GRAY);
        cell3.setMinimumHeight(11);
        cell3.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell3);

		// linha 2
        PdfPCell cell4 = new PdfPCell(new Paragraph("CPF:", font2));
        cell4.setColspan(2);
        cell4.setPaddingTop(1);
        cell4.setBorderWidth((float) 0.1);
        cell4.setBorderColor(RGBColor.LIGHT_GRAY);
        cell4.setMinimumHeight(11);
        cell4.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell4);
        PdfPCell cell5 = new PdfPCell(new Paragraph(this.aluno.getPessoa().retornaCpfComFormatacao(), font2));
        cell5.setColspan(5);
        cell5.setPaddingTop(1);
        cell5.setBorderWidth((float) 0.1);
        cell5.setBorderColor(RGBColor.LIGHT_GRAY);
        cell5.setMinimumHeight(11);
        cell5.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell5);
        PdfPCell cell6 = new PdfPCell(new Paragraph("Matrícula no curso:", font2));
        cell6.setColspan(2);
        cell6.setPaddingTop(1);
        cell6.setBorderWidth((float) 0.1);
        cell6.setBorderColor(RGBColor.LIGHT_GRAY);
        cell6.setMinimumHeight(11);
        cell6.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell6);
        PdfPCell cell7 = new PdfPCell(new Paragraph(this.alunoReg.getMatricula(), font2));
        cell7.setColspan(3);
        cell7.setPaddingTop(1);
        cell7.setBorderWidth((float) 0.1);
        cell7.setBorderColor(RGBColor.LIGHT_GRAY);
        cell7.setMinimumHeight(11);
        cell7.setVerticalAlignment(Element.ALIGN_CENTER);
        cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell7);

		// linha 3
        PdfPCell cell8 = new PdfPCell(new Paragraph("Doc. de identificação:", font2));
        cell8.setColspan(2);
        cell8.setPaddingTop(1);
        cell8.setBorderWidth((float) 0.1);
        cell8.setBorderColor(RGBColor.LIGHT_GRAY);
        cell8.setMinimumHeight(11);
        cell8.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell8);
        PdfPCell cell9 = new PdfPCell(new Paragraph(this.aluno.getPessoa().getTipoComDocumento(), font2));
        cell9.setColspan(5);
        cell9.setPaddingTop(1);
        cell9.setBorderWidth((float) 0.1);
        cell9.setBorderColor(RGBColor.LIGHT_GRAY);
        cell9.setMinimumHeight(11);
        cell9.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell9);
        PdfPCell cell10 = new PdfPCell(new Paragraph("Forma de ingresso:", font2));
        cell10.setColspan(2);
        cell10.setPaddingTop(1);
        cell10.setBorderWidth((float) 0.1);
        cell10.setBorderColor(RGBColor.LIGHT_GRAY);
        cell10.setMinimumHeight(11);
        cell10.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell10);
        PdfPCell cell11 = new PdfPCell(new Paragraph("Seleção", font2));
        cell11.setColspan(3);
        cell11.setPaddingTop(1);
        cell11.setBorderWidth((float) 0.1);
        cell11.setBorderColor(RGBColor.LIGHT_GRAY);
        cell11.setMinimumHeight(11);
        cell11.setVerticalAlignment(Element.ALIGN_CENTER);
        cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell11);
        
		// linha 4
        PdfPCell cell12 = new PdfPCell(new Paragraph("Data de nascimento:", font2));
        cell12.setColspan(2);
        cell12.setPaddingTop(1);
        cell12.setBorderWidth((float) 0.1);
        cell12.setBorderColor(RGBColor.LIGHT_GRAY);
        cell12.setMinimumHeight(11);
        cell12.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell12);
        PdfPCell cell13 = new PdfPCell(new Paragraph(this.aluno.getPessoa().getDataNascimento().format(dtFormatter).toString(), font2));
        cell13.setColspan(5);
        cell13.setPaddingTop(1);
        cell13.setBorderWidth((float) 0.1);
        cell13.setBorderColor(RGBColor.LIGHT_GRAY);
        cell13.setMinimumHeight(11);
        cell13.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell13);
        PdfPCell cell14 = new PdfPCell(new Paragraph("Data de ingresso:", font2));
        cell14.setColspan(2);
        cell14.setPaddingTop(1);
        cell14.setBorderWidth((float) 0.1);
        cell14.setBorderColor(RGBColor.LIGHT_GRAY);
        cell14.setMinimumHeight(11);
        cell14.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell14);
        PdfPCell cell15 = new PdfPCell(new Paragraph(this.alunoReg.getDataIngresso().format(dtFormatter).toString(), font2));
        cell15.setColspan(3);
        cell15.setPaddingTop(1);
        cell15.setBorderWidth((float) 0.1);
        cell15.setBorderColor(RGBColor.LIGHT_GRAY);
        cell15.setMinimumHeight(11);
        cell15.setVerticalAlignment(Element.ALIGN_CENTER);
        cell15.setHorizontalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell15);

		// linha 5
        PdfPCell cell16 = new PdfPCell(new Paragraph("Naturalidade:", font2));
        cell16.setColspan(2);
        cell16.setPaddingTop(1);
        cell16.setBorderWidth((float) 0.1);
        cell16.setBorderColor(RGBColor.LIGHT_GRAY);
        cell16.setMinimumHeight(11);
        cell16.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell16);
        
        String naturalidade = "";
        if(this.aluno.getPessoa().getNaturalidade() != null) {
        	naturalidade = this.aluno.getPessoa().getNaturalidade().getNome() + "/" + this.aluno.getPessoa().getNaturalidade().getEstado().getSigla();
        }
        PdfPCell cell17 = new PdfPCell(new Paragraph(naturalidade, font2));
        cell17.setColspan(5);
        cell17.setPaddingTop(1);
        cell17.setBorderWidth((float) 0.1);
        cell17.setBorderColor(RGBColor.LIGHT_GRAY);
        cell17.setMinimumHeight(11);
        cell17.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell17);
        PdfPCell cell18 = new PdfPCell(new Paragraph("Nacionalidade:", font2));
        cell18.setColspan(2);
        cell18.setPaddingTop(1);
        cell18.setBorderWidth((float) 0.1);
        cell18.setBorderColor(RGBColor.LIGHT_GRAY);
        cell18.setMinimumHeight(11);
        cell18.setVerticalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell18);
        PdfPCell cell19 = new PdfPCell(new Paragraph(this.aluno.getPessoa().getNacionalidade(), font2));
        cell19.setColspan(3);
        cell19.setPaddingTop(1);
        cell19.setBorderWidth((float) 0.1);
        cell19.setBorderColor(RGBColor.LIGHT_GRAY);
        cell19.setMinimumHeight(11);
        cell19.setVerticalAlignment(Element.ALIGN_CENTER);
        cell19.setHorizontalAlignment(Element.ALIGN_CENTER);
        table2.addCell(cell19);

        document.add(table2);
		
	}
	
	private void dadosCurso() {
		
		PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);
        
        // Linha titulo do bloco
        PdfPCell cell1 = new PdfPCell();
        cell1.setColspan(12);
        cell1.setPaddingTop(0);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell1.setMinimumHeight(11);
        cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table.addCell(cell1);

        document.add(table);
        
        // dados do curso e instituicao
		PdfPTable table2 = new PdfPTable(12);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(2);

        // fontes
        Font font1 = FontFactory.getFont(FontFactory.TIMES, 7);
        Font font2 = FontFactory.getFont(FontFactory.TIMES, 8);

        Paragraph paragraph1 = new Paragraph("CEFOR/Câmara dos Deputados: Ato da Mesa nº 69, de 12/05/1997, publicado no DCD nº 121, de 11/07/1997.", font1);
        Paragraph paragraph2 = new Paragraph("Programa de Pós-Graduação do CEFOR: Portaria-DG nº 69, de 30/06/2005.", font1);
        Paragraph paragraph3 = new Paragraph("Credenciamento: " + 
                                              (this.aluno.getCurso().getNormativo() != null ? this.aluno.getCurso().getNormativo() : ""), font1);
        
        Paragraph paragraph4 = new Paragraph(this.aluno.getCurso().getNome(), font2);
        Paragraph paragraph5 = new Paragraph("Grau: " + this.aluno.getCurso().getGrau().getDescricao(), font2);
        Paragraph paragraph6 = new Paragraph((this.aluno.getCurso().getGrau().getNivel() < 3 ? "Código: " : "Código Capes: ") + this.aluno.getCurso().getCodigo(), font2);
        Paragraph paragraph7 = new Paragraph((this.aluno.getCurso().getGrau().getNivel() < 3 ? "Área do Conhecimento: " : "Área de Concentração: ") + 
        		                               (this.aluno.getCurso().getArea() != null ? this.aluno.getCurso().getArea() : ""), font2);

        
        // altura das linhas e alinhamento
        paragraph1.setLeading(20);
        paragraph2.setLeading(13);
        paragraph3.setLeading(13);
        paragraph3.setSpacingAfter(10);
        
        paragraph4.setLeading(13);
        paragraph4.setAlignment(Element.ALIGN_CENTER);
        
        paragraph5.setLeading(13);
        paragraph5.setAlignment(Element.ALIGN_CENTER);
        
        paragraph6.setLeading(13);
        paragraph6.setAlignment(Element.ALIGN_CENTER);
        paragraph7.setLeading(13);
        paragraph7.setAlignment(Element.ALIGN_CENTER);
        paragraph7.setSpacingAfter(10);
        
        // adiciona os paragrafos aa segunda coluna
        PdfPCell cell2 = new PdfPCell();
        cell2.setColspan(7);
        cell2.setBorderWidth((float) 0.1);
        cell2.setBorderColor(RGBColor.LIGHT_GRAY);
        //cell2.setMinimumHeight(65);
        cell2.setVerticalAlignment(Element.ALIGN_CENTER);
        cell2.addElement(paragraph1);
        cell2.addElement(paragraph2);
        cell2.addElement(paragraph3);
        table2.addCell(cell2);
        PdfPCell cell3 = new PdfPCell();
        cell3.setColspan(5);
        cell3.setBorderWidth((float) 0.1);
        cell3.setBorderColor(RGBColor.LIGHT_GRAY);
        //cell3.setMinimumHeight(65);
        cell3.setVerticalAlignment(Element.ALIGN_CENTER);
        cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell3.addElement(paragraph4);
        cell3.addElement(paragraph5);
        cell3.addElement(paragraph6);
        cell3.addElement(paragraph7);
        table2.addCell(cell3);

        
        document.add(table2);
        
	}
	
	
	private void componentesCurriculares() {
	
		PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);
        
        // fontes
        Font font1 = FontFactory.getFont(FontFactory.TIMES, 8, Font.BOLD);
        font1.setColor(RGBColor.BLUE);
        
        // Linha titulo do bloco
        PdfPCell cell1 = new PdfPCell(new Paragraph("COMPONENTES CURRICULARES", font1));
        cell1.setColspan(12);
        cell1.setPaddingTop(0);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell1.setMinimumHeight(11);
        cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table.addCell(cell1);

        document.add(table);

        // identificacao de gerenero
        String genero;
        if(this.aluno.getPessoa().getSexo().equals(Sexo.F)) {
        	genero = "ALUNA";
        } else {
        	genero = "ALUNO";
        }
        
        
        // listas de disciplinas por bloco
        List<MatriculaDisciplina> listaOptativasEspecial = new ArrayList<>();
        List<MatriculaDisciplina> listaObrigatoriasRegular = new ArrayList<>();
        List<MatriculaDisciplina> listaOptativasRegular = new ArrayList<>();
        List<MatriculaDisciplina> listaAproveitamento = new ArrayList<>();
        List<MatriculaDisciplina> listaOutros = new ArrayList<>();
        
        Iterator<MatriculaDisciplina> iterator = this.historico.iterator();
        while (iterator.hasNext()) {
        	MatriculaDisciplina matriculaDisciplina = iterator.next();
        	
        	// bloco optativas cursadas como especial
        	if(matriculaDisciplina.getOferta().getCursoDisciplina().getFlagObrigatoria().equals(SimNao.N) &&
        			matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getTipo().equals(TipoDisciplina.DISC) &&
        			matriculaDisciplina.getMatricula().getAlunoEsp() != null
        			) {
        		listaOptativasEspecial.add(matriculaDisciplina);
        		
        		// bloco obrigatorias cursadas como regular
        	} else if(matriculaDisciplina.getOferta().getCursoDisciplina().getFlagObrigatoria().equals(SimNao.S) &&
        			matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getTipo().equals(TipoDisciplina.DISC) &&
        			matriculaDisciplina.getMatricula().getAlunoReg() != null
        			) {
        		listaObrigatoriasRegular.add(matriculaDisciplina);
        		
            	// bloco optativa cursadas como regular        		
        	} else if(matriculaDisciplina.getOferta().getCursoDisciplina().getFlagObrigatoria().equals(SimNao.N) &&
        			matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getTipo().equals(TipoDisciplina.DISC) &&
        			matriculaDisciplina.getMatricula().getAlunoReg() != null
        			) {
        		listaOptativasRegular.add(matriculaDisciplina);
        		
        		// bloco disciplinas cursadas em outras instituicoes
        	} else if(matriculaDisciplina.getOferta().getCursoDisciplina().getFlagObrigatoria().equals(SimNao.N) &&
        			matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getTipo().equals(TipoDisciplina.CCCM) &&
        			matriculaDisciplina.getMatricula().getAlunoReg() != null &&
        			matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("APROVE")
        			) {
        		listaAproveitamento.add(matriculaDisciplina);
        		
        		// bloco outros componentes curriculares
        	} else {
        		listaOutros.add(matriculaDisciplina);
        		if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("DEFESA") &&
        				matriculaDisciplina.getMencao() != null &&
        				matriculaDisciplina.getMencao().equals("AP")) {
        			this.dataConclusao = matriculaDisciplina.getDataMencao();
        		} 
        	}

        	
        }
        
        // apresenta os blocos
        listaComponentesCurriculares("DISCIPLINAS OPTATIVAS CURSADAS COMO " + genero + " ESPECIAL", listaOptativasEspecial, 1);
        listaComponentesCurriculares("DISCIPLINAS OBRIGATÓRIAS CURSADAS COMO " + genero + " REGULAR", listaObrigatoriasRegular, 0);
        listaComponentesCurriculares("DISCIPLINAS OPTATIVAS CURSADAS COMO " + genero + " REGULAR", listaOptativasRegular, 1);
        listaComponentesCurriculares("DISCIPLINAS CURSADAS EM OUTRAS INSTITUIÇÕES DE ENSINO", listaAproveitamento, 2);
        listaComponentesCurriculares("OUTROS COMPONENTES CURRICULARES", listaOutros, 2);


        font1.setColor(RGBColor.BLACK);
        
        // total de creditos/horas integralizados
		PdfPTable table2 = new PdfPTable(48);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(2);

        PdfPCell cell2= new PdfPCell();
        cell2.setColspan(4);
        cell2.setBorderWidth(0);
        cell2.setMinimumHeight(11);
        table2.addCell(cell2);
        PdfPCell cell3 = new PdfPCell(new Paragraph("TOTAL INTEGRALIZADO", font1));
        cell3.setColspan(24);
        cell3.setPaddingTop(0);
        cell3.setBorderWidth((float) 0.1);
        cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell3.setVerticalAlignment(Element.ALIGN_CENTER);
        cell3.setMinimumHeight(11);
        table2.addCell(cell3);        
        
        DecimalFormat formato = new DecimalFormat("0.0");
        DecimalFormat formato2 = new DecimalFormat("0");
        
        PdfPCell cell4= new PdfPCell(new Paragraph(formato.format(this.totalCreditos), font1));
        cell4.setColspan(4);
        cell4.setPaddingTop(0);
        cell4.setBorderWidth((float) 0.1);
        cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell4.setVerticalAlignment(Element.ALIGN_CENTER);
        cell4.setMinimumHeight(11);
        table2.addCell(cell4);
        PdfPCell cell5= new PdfPCell(new Paragraph(formato2.format(this.totalCreditos * 15) + "h", font1));
        cell5.setColspan(3);
        cell5.setPaddingTop(0);
        cell5.setBorderWidth((float) 0.1);
        cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell5.setVerticalAlignment(Element.ALIGN_CENTER);
        cell5.setMinimumHeight(11);
        table2.addCell(cell5);
        PdfPCell cell6= new PdfPCell();
        cell6.setColspan(13);
        cell6.setBorderWidth(0);
        cell6.setMinimumHeight(11);
        table2.addCell(cell6);
        
        // total exigido
        PdfPCell cell7= new PdfPCell();
        cell7.setColspan(4);
        cell7.setBorderWidth(0);
        cell7.setMinimumHeight(11);
        table2.addCell(cell7);
        PdfPCell cell8 = new PdfPCell(new Paragraph("TOTAL EXIGIDO", font1));
        cell8.setColspan(24);
        cell8.setPaddingTop(0);
        cell8.setBorderWidth((float) 0.1);
        cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell8.setVerticalAlignment(Element.ALIGN_CENTER);
        cell8.setMinimumHeight(11);
        table2.addCell(cell8);     
        PdfPCell cell9= new PdfPCell(new Paragraph(formato.format(this.aluno.getCurso().getCargaHoraria()/15), font1));
        cell9.setColspan(4);
        cell9.setPaddingTop(0);
        cell9.setBorderWidth((float) 0.1);
        cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell9.setVerticalAlignment(Element.ALIGN_CENTER);
        cell9.setMinimumHeight(11);
        table2.addCell(cell9);
        PdfPCell cell10= new PdfPCell(new Paragraph(formato2.format(this.aluno.getCurso().getCargaHoraria()) + "h", font1));
        cell10.setColspan(3);
        cell10.setPaddingTop(0);
        cell10.setBorderWidth((float) 0.1);
        cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell10.setVerticalAlignment(Element.ALIGN_CENTER);
        cell10.setMinimumHeight(11);
        table2.addCell(cell10);
        PdfPCell cell11= new PdfPCell();
        cell11.setColspan(13);
        cell11.setBorderWidth(0);
        cell11.setMinimumHeight(11);
        table2.addCell(cell11);



        document.add(table2);
	}
	
	
	private void listaComponentesCurriculares(String titulo, List<MatriculaDisciplina> listaComponentes, Integer flagData) {
        // flagData define o titulo da celula: 0 - branco; 1 - opcao ac; 2 - data

		
		if(listaComponentes.isEmpty()) {
			return;
		}
		
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		PdfPTable table2 = new PdfPTable(48);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(2);
        
        // fontes
        Font font2 = FontFactory.getFont(FontFactory.TIMES, 7);
        Font font3 = FontFactory.getFont(FontFactory.TIMES, 7, Font.BOLD);
        
        // Linha titulo do bloco
        PdfPCell cell2 = new PdfPCell(new Paragraph(titulo, font3));
        cell2.setColspan(28);
        cell2.setPaddingTop(1);
        cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell2.setVerticalAlignment(Element.ALIGN_CENTER);
        cell2.setMinimumHeight(11);
        cell2.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table2.addCell(cell2);
        PdfPCell cell3 = new PdfPCell(new Paragraph("DADOS ACADÊMICOS", font3));
        cell3.setColspan(20);
        cell3.setPaddingTop(1);
        cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell3.setVerticalAlignment(Element.ALIGN_CENTER);
        cell3.setMinimumHeight(11);
        cell3.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table2.addCell(cell3);

        // cabecalho
        PdfPCell cell4 = new PdfPCell(new Paragraph("PERÍODO", font2));
        cell4.setColspan(4);
        cell4.setPaddingTop(1);
        cell4.setBorderWidth((float) 0.1);
        cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell4.setVerticalAlignment(Element.ALIGN_CENTER);
        cell4.setMinimumHeight(11);
        table2.addCell(cell4);
        PdfPCell cell5 = new PdfPCell(new Paragraph("SIGLA", font2));
        cell5.setColspan(4);
        cell5.setPaddingTop(1);
        cell5.setBorderWidth((float) 0.1);
        cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell5.setVerticalAlignment(Element.ALIGN_CENTER);
        cell5.setMinimumHeight(11);
        table2.addCell(cell5);
        PdfPCell cell6 = new PdfPCell(new Paragraph("NOME", font2));
        cell6.setColspan(20);
        cell6.setPaddingTop(1);
        cell6.setBorderWidth((float) 0.1);
        cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell6.setVerticalAlignment(Element.ALIGN_CENTER);
        cell6.setMinimumHeight(11);
        table2.addCell(cell6);
        PdfPCell cell7 = new PdfPCell(new Paragraph("CRÉDITOS", font2));
        cell7.setColspan(4);
        cell7.setPaddingTop(1);
        cell7.setBorderWidth((float) 0.1);
        cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell7.setVerticalAlignment(Element.ALIGN_CENTER);
        cell7.setMinimumHeight(11);
        table2.addCell(cell7);
        PdfPCell cell7_1 = new PdfPCell(new Paragraph("CH", font2));
        cell7_1.setColspan(3);
        cell7_1.setPaddingTop(1);
        cell7_1.setBorderWidth((float) 0.1);
        cell7_1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell7_1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell7_1.setMinimumHeight(11);
        table2.addCell(cell7_1);
        
        String dataTitulo = "--";
        if(flagData == 1) {
        	dataTitulo = "OPÇÃO AC";
        } else if(flagData == 2) {
        	dataTitulo = "DATA";
        }
        PdfPCell cell8 = new PdfPCell(new Paragraph(dataTitulo, font2));
        cell8.setColspan(4);
        cell8.setPaddingTop(1);
        cell8.setBorderWidth((float) 0.1);
        cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell8.setVerticalAlignment(Element.ALIGN_CENTER);
        cell8.setMinimumHeight(11);
        table2.addCell(cell8);
        PdfPCell cell9 = new PdfPCell(new Paragraph("NOTA", font2));
        cell9.setColspan(3);
        cell9.setPaddingTop(1);
        cell9.setBorderWidth((float) 0.1);
        cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell9.setVerticalAlignment(Element.ALIGN_CENTER);
        cell9.setMinimumHeight(11);
        table2.addCell(cell9);
        PdfPCell cell10 = new PdfPCell(new Paragraph("FREQ", font2));
        cell10.setColspan(3);
        cell10.setPaddingTop(1);
        cell10.setBorderWidth((float) 0.1);
        cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell10.setVerticalAlignment(Element.ALIGN_CENTER);
        cell10.setMinimumHeight(11);
        table2.addCell(cell10);
        PdfPCell cell11 = new PdfPCell(new Paragraph("MENÇÃO", font2));
        cell11.setColspan(3);
        cell11.setPaddingTop(1);
        cell11.setBorderWidth((float) 0.1);
        cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell11.setVerticalAlignment(Element.ALIGN_CENTER);
        cell11.setMinimumHeight(11);
        table2.addCell(cell11);
        
        document.add(table2);  
        
        // tabela com as disciplinas cursadas
        PdfPTable table3 = new PdfPTable(48);
        table3.setWidthPercentage(100);
        table3.setSpacingBefore((float) 0.5);
        
        // apresenta itens curriculares
        Iterator<MatriculaDisciplina> iterator = listaComponentes.iterator();
        while (iterator.hasNext()) {
        	MatriculaDisciplina matriculaDisciplina = iterator.next();
        	
            PdfPCell cell12= new PdfPCell(new Paragraph(matriculaDisciplina.getOferta().getSemestre().getPeriodo(), font2));
            cell12.setColspan(4);
            cell12.setPaddingTop(1);
            cell12.setBorderWidth((float) 0.1);
            cell12.setBorderColor(RGBColor.LIGHT_GRAY);
            cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell12.setVerticalAlignment(Element.ALIGN_CENTER);
            cell12.setMinimumHeight(11);
            table3.addCell(cell12);
            // se for aproveitamento de credito
            String sigla;
            if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("APROVE")) {
            	sigla = matriculaDisciplina.getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getSigla();
            }else {
            	sigla = matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla();
            }
            PdfPCell cell13= new PdfPCell(new Paragraph(sigla, font2));
            cell13.setColspan(4);
            cell13.setPaddingTop(1);
            cell13.setBorderWidth((float) 0.1);
            cell13.setBorderColor(RGBColor.LIGHT_GRAY);
            cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell13.setVerticalAlignment(Element.ALIGN_CENTER);
            cell13.setMinimumHeight(11);
            table3.addCell(cell13);
            
            String disciplina;
            if(matriculaDisciplina.getOferta().getCursoDisciplinaSubtitulo() != null) {
            	if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("APROVE")) {
            		disciplina = matriculaDisciplina.getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getNome();
            	} else {
                	disciplina = matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getNome() + " - " +
                			matriculaDisciplina.getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getNome();
            	}
            } else {
            	disciplina = matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getNome();
            }
            PdfPCell cell14 = new PdfPCell(new Paragraph(disciplina, font2));
            cell14.setColspan(20);
            cell14.setPaddingTop(1);
            cell14.setBorderWidth((float) 0.1);
            cell14.setBorderColor(RGBColor.LIGHT_GRAY);
            cell14.setHorizontalAlignment(Element.ALIGN_LEFT);
            cell14.setVerticalAlignment(Element.ALIGN_CENTER);
            cell14.setMinimumHeight(11);
            table3.addCell(cell14);

            float creditos = matriculaDisciplina.getCreditosComputados();
            // Crie um DecimalFormat para formatar com uma casa decimal
            DecimalFormat formato = new DecimalFormat("0.0");
            DecimalFormat formato2 = new DecimalFormat("0");
            
            PdfPCell cell15 = new PdfPCell(new Paragraph(formato.format(creditos), font2));
            cell15.setColspan(4);
            cell15.setPaddingTop(1);
            cell15.setBorderWidth((float) 0.1);
            cell15.setBorderColor(RGBColor.LIGHT_GRAY);
            cell15.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell15.setVerticalAlignment(Element.ALIGN_CENTER);
            cell15.setMinimumHeight(11);
            table3.addCell(cell15);
            
            PdfPCell cell15_1 = new PdfPCell(new Paragraph(creditos == 0 ? "--": formato2.format(creditos * 15) + "h", font2));
            cell15_1.setColspan(3);
            cell15_1.setPaddingTop(1);
            cell15_1.setBorderWidth((float) 0.1);
            cell15_1.setBorderColor(RGBColor.LIGHT_GRAY);
            cell15_1.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell15_1.setVerticalAlignment(Element.ALIGN_CENTER);
            cell15_1.setMinimumHeight(11);
            table3.addCell(cell15_1);

            String data = "--";
            if(flagData == 1 && matriculaDisciplina.getDataOpcaoac() != null) {
            	data = matriculaDisciplina.getDataOpcaoac().format(dtFormatter).toString();
            } else if(flagData == 2) {
            	if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("APROVE") ||
            		  matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("EQUALI") ||
            		  matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("ATIVCO") ||
            		  matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("DEFESA")) {

            		if(matriculaDisciplina.getDataMencao() != null) {
            			data = matriculaDisciplina.getDataMencao().format(dtFormatter).toString();	
            		}
            	}
            	
            	if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("TRANCA")) {

            		data = matriculaDisciplina.getMatricula().getDataTrancamento().format(dtFormatter).toString();
              	}
            }
            PdfPCell cell16 = new PdfPCell(new Paragraph(data, font2));
            cell16.setColspan(4);
            cell16.setPaddingTop(1);
            cell16.setBorderWidth((float) 0.1);
            cell16.setBorderColor(RGBColor.LIGHT_GRAY);
            cell16.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell16.setVerticalAlignment(Element.ALIGN_CENTER);
            cell16.setMinimumHeight(11);
            table3.addCell(cell16);
            
            String nota = "--";
            if(matriculaDisciplina.getNota() != null) {
            	nota = formato.format(matriculaDisciplina.getNota());
            }
            PdfPCell cell17 = new PdfPCell(new Paragraph(nota, font2));
            cell17.setColspan(3);
            cell17.setPaddingTop(1);
            cell17.setBorderWidth((float) 0.1);
            cell17.setBorderColor(RGBColor.LIGHT_GRAY);
            cell17.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell17.setVerticalAlignment(Element.ALIGN_CENTER);
            cell17.setMinimumHeight(11);
            table3.addCell(cell17);

            String freq = "--";
            if(matriculaDisciplina.getFrequencia() != null) {
            	freq = formato.format(matriculaDisciplina.getFrequencia()) + "%";
            }
            PdfPCell cell18 = new PdfPCell(new Paragraph(freq, font2));
            cell18.setColspan(3);
            cell18.setPaddingTop(1);
            cell18.setBorderWidth((float) 0.1);
            cell18.setBorderColor(RGBColor.LIGHT_GRAY);
            cell18.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell18.setVerticalAlignment(Element.ALIGN_CENTER);
            cell18.setMinimumHeight(11);
            table3.addCell(cell18);

            String mencao = "--";
            if(matriculaDisciplina.getMencao() != null) {
            	mencao = matriculaDisciplina.getMencao();
            }
            PdfPCell cell19 = new PdfPCell(new Paragraph(mencao, font2));
            cell19.setColspan(3);
            cell19.setPaddingTop(1);
            cell19.setBorderWidth((float) 0.1);
            cell19.setBorderColor(RGBColor.LIGHT_GRAY);
            cell19.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell19.setVerticalAlignment(Element.ALIGN_CENTER);
            cell19.setMinimumHeight(11);
            table3.addCell(cell19);
            
            // computa creditos como especial
            totalCreditos = totalCreditos + matriculaDisciplina.getCreditosComputados(); 
                
        }
        
        document.add(table3);
	}
	
	private void dadosTCC() {
		
		//DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);
        
        // fontes
        Font font1 = FontFactory.getFont(FontFactory.TIMES, 8, Font.BOLD);
        font1.setColor(RGBColor.BLUE);
        
        // Linha titulo do bloco
        PdfPCell cell1 = new PdfPCell(new Paragraph("TRABALHO DE CONCLUSÃO DE CURSO", font1));
        cell1.setColspan(12);
        cell1.setPaddingTop(0);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell1.setMinimumHeight(11);
        cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table.addCell(cell1);

        document.add(table);

		PdfPTable table2 = new PdfPTable(48);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(2);
        
        // fontes
        Font font2 = FontFactory.getFont(FontFactory.TIMES, 7);

        LocalDate dataReferencia;
        if(this.dataConclusao != null) {
        	dataReferencia = this.dataConclusao;
        } else {
        	dataReferencia = LocalDate.now();
        }
        
        // orientador
        if(this.alunoReg.getOrientador() != null) {
	        PdfPCell cell2= new PdfPCell(new Paragraph("Orientação:", font2));
	        cell2.setColspan(8);
	        cell2.setPaddingTop(1);
	        cell2.setBorderWidth((float) 0.1);
	        cell2.setBorderColor(RGBColor.LIGHT_GRAY);
	        cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
	        cell2.setVerticalAlignment(Element.ALIGN_CENTER);
	        cell2.setMinimumHeight(11);
	        table2.addCell(cell2);
	        PdfPCell cell3= new PdfPCell(new Paragraph(this.alunoReg.getOrientador().getPessoa().getNome(), font2));
	        cell3.setColspan(24);
	        cell3.setPaddingTop(1);
	        cell3.setBorderWidth((float) 0.1);
	        cell3.setBorderColor(RGBColor.LIGHT_GRAY);
	        cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
	        cell3.setVerticalAlignment(Element.ALIGN_CENTER);
	        cell3.setMinimumHeight(11);
	        table2.addCell(cell3);
	        
	        // buscar titulacao: maior titulo (grau) com data menor ou igual a this.dataConclusao
	        String titulo = "";
	        List<PessoaTitulo> pessoaTitulos = pessoasTitulos.findByPessoaAndDataTitulacaoLessThanEqualOrderByGrauCursoGrauDesc(this.alunoReg.getOrientador().getPessoa(), dataReferencia);
	        if(!pessoaTitulos.isEmpty()) {
	        	if(this.alunoReg.getOrientador().getPessoa().getSexo().equals(Sexo.M)) {
	        		titulo = pessoaTitulos.get(0).getGrauCurso().getTitulacao();	
	        	} else {
	        		titulo = pessoaTitulos.get(0).getGrauCurso().getTitulacaoFem();
	        	}
	        }
	        
	        PdfPCell cell4= new PdfPCell(new Paragraph("Titulação: " + titulo, font2));
	        cell4.setColspan(16);
	        cell4.setPaddingTop(1);
	        cell4.setBorderWidth((float) 0.1);
	        cell4.setBorderColor(RGBColor.LIGHT_GRAY);
	        cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
	        cell4.setVerticalAlignment(Element.ALIGN_CENTER);
	        cell4.setMinimumHeight(11);
	        table2.addCell(cell4);
        }

        
        // coorientador
        if(this.alunoReg.getCoorientador() != null) {
	        PdfPCell cell5= new PdfPCell(new Paragraph("Coorientação:", font2));
	        cell5.setColspan(8);
	        cell5.setPaddingTop(1);
	        cell5.setBorderWidth((float) 0.1);
	        cell5.setBorderColor(RGBColor.LIGHT_GRAY);
	        cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
	        cell5.setVerticalAlignment(Element.ALIGN_CENTER);
	        cell5.setMinimumHeight(11);
	        table2.addCell(cell5);
	        PdfPCell cell6= new PdfPCell(new Paragraph(this.alunoReg.getCoorientador().getNome(), font2));
	        cell6.setColspan(24);
	        cell6.setPaddingTop(1);
	        cell6.setBorderWidth((float) 0.1);
	        cell6.setBorderColor(RGBColor.LIGHT_GRAY);
	        cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
	        cell6.setVerticalAlignment(Element.ALIGN_CENTER);
	        cell6.setMinimumHeight(11);
	        table2.addCell(cell6);
	        
	        // buscar titulacao: maior titulo (grau) com data menor ou igual a this.dataConclusao
	        String titulo = "";
	        List<PessoaTitulo> pessoaTitulos = pessoasTitulos.findByPessoaAndDataTitulacaoLessThanEqualOrderByGrauCursoGrauDesc(this.alunoReg.getCoorientador(), dataReferencia);
	        if(!pessoaTitulos.isEmpty()) {
	        	if(this.alunoReg.getCoorientador().getSexo().equals(Sexo.M)) {
	        		titulo = pessoaTitulos.get(0).getGrauCurso().getTitulacao();	
	        	} else {
	        		titulo = pessoaTitulos.get(0).getGrauCurso().getTitulacaoFem();
	        	}
	        }

	        
	        PdfPCell cell7= new PdfPCell(new Paragraph("Titulação: " + titulo, font2));
	        cell7.setColspan(16);
	        cell7.setPaddingTop(1);
	        cell7.setBorderWidth((float) 0.1);
	        cell7.setBorderColor(RGBColor.LIGHT_GRAY);
	        cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
	        cell7.setVerticalAlignment(Element.ALIGN_CENTER);
	        cell7.setMinimumHeight(11);
	        table2.addCell(cell7);
        }
        
        
        // tcc
        PdfPCell cell8= new PdfPCell(new Paragraph("Título do TCC:", font2));
        cell8.setColspan(8);
        cell8.setPaddingTop(3);
        cell8.setBorderWidth((float) 0.1);
        cell8.setBorderColor(RGBColor.LIGHT_GRAY);
        cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell8.setVerticalAlignment(Element.ALIGN_CENTER);
        cell8.setMinimumHeight(11);
        table2.addCell(cell8);
        PdfPCell cell9= new PdfPCell(new Paragraph(this.alunoReg.getTituloTCC(), font2));
        cell9.setColspan(40);
        cell9.setPaddingTop(3);
        cell9.setBorderWidth((float) 0.1);
        cell9.setBorderColor(RGBColor.LIGHT_GRAY);
        cell9.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell9.setVerticalAlignment(Element.ALIGN_CENTER);
        cell9.setMinimumHeight(15);
        table2.addCell(cell9);
        
        document.add(table2);
	}
	
	
	private void conclusaoCurso() {

		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);
        
        // fontes
        Font font1 = FontFactory.getFont(FontFactory.TIMES, 8, Font.BOLD);
        font1.setColor(RGBColor.BLUE);
        
        // Linha titulo do bloco
        PdfPCell cell1 = new PdfPCell(new Paragraph("INTEGRALIZAÇÃO CURRICULAR", font1));
        cell1.setColspan(12);
        cell1.setPaddingTop(0);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell1.setMinimumHeight(11);
        cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table.addCell(cell1);

        document.add(table);
        
        
		PdfPTable table2 = new PdfPTable(12);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(2);
        
        // fontes
        Font font2 = FontFactory.getFont(FontFactory.TIMES, 7);

        // tcc
        String dtConclusao = "";
        if(this.dataConclusao != null) {
        	dtConclusao = this.dataConclusao.format(dtFormatter).toString();
        }
        
        PdfPCell cell6= new PdfPCell(new Paragraph("Conclusão do curso: " + dtConclusao, font2));
        cell6.setColspan(3);
        cell6.setPaddingTop(3);
        cell6.setBorderWidth((float) 0.1);
        cell6.setBorderColor(RGBColor.LIGHT_GRAY);
        cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell6.setVerticalAlignment(Element.ALIGN_CENTER);
        cell6.setMinimumHeight(15);
        table2.addCell(cell6);
        
        String dtHomologacao = "";
        if(this.alunoReg.getDataHomologacao() != null) {
        	dtHomologacao = this.alunoReg.getDataHomologacao().format(dtFormatter);
        }
        PdfPCell cell7= new PdfPCell(new Paragraph("Homologação: " + dtHomologacao, font2));
        cell7.setColspan(3);
        cell7.setPaddingTop(3);
        cell7.setBorderWidth((float) 0.1);
        cell7.setBorderColor(RGBColor.LIGHT_GRAY);
        cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell7.setVerticalAlignment(Element.ALIGN_CENTER);
        cell7.setMinimumHeight(15);
        table2.addCell(cell7);

        String dtExpedicaoDiploma = "";
        if(this.alunoReg.getDataExpedicaoDiploma() != null) {
        	dtExpedicaoDiploma = this.alunoReg.getDataExpedicaoDiploma().format(dtFormatter);
        }
        PdfPCell cell8= new PdfPCell(new Paragraph("Expedição " + this.aluno.getCurso().getGrau().getDocumento() + ": " + dtExpedicaoDiploma, font2));
        cell8.setColspan(3);
        cell8.setPaddingTop(3);
        cell8.setBorderWidth((float) 0.1);
        cell8.setBorderColor(RGBColor.LIGHT_GRAY);
        cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell8.setVerticalAlignment(Element.ALIGN_CENTER);
        cell8.setMinimumHeight(15);
        table2.addCell(cell8);
        
        String grau = "";
        if(this.dataConclusao != null) {
        	if(this.aluno.getPessoa().getSexo().equals(Sexo.F)) {
        		grau = this.aluno.getCurso().getGrau().getTitulacaoFem();
        	} else {
        		grau = this.aluno.getCurso().getGrau().getTitulacao();
        	}
        }
        PdfPCell cell9= new PdfPCell(new Paragraph("Grau obtido: " + grau, font2));
        cell9.setColspan(3);
        cell9.setPaddingTop(3);
        cell9.setBorderWidth((float) 0.1);
        cell9.setBorderColor(RGBColor.LIGHT_GRAY);
        cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell9.setVerticalAlignment(Element.ALIGN_CENTER);
        cell9.setMinimumHeight(15);
        table2.addCell(cell9);
        
        document.add(table2);
        
	}

	
	private void legenda() {
		
		PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);
        
        // fontes
        Font font1 = FontFactory.getFont(FontFactory.TIMES, 8, Font.BOLD);
        font1.setColor(RGBColor.BLUE);
        
        // Linha titulo do bloco
        PdfPCell cell1 = new PdfPCell(new Paragraph("LEGENDA", font1));
        cell1.setColspan(12);
        cell1.setPaddingTop(0);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell1.setMinimumHeight(11);
        cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table.addCell(cell1);

        document.add(table);
        
        
		PdfPTable table2 = new PdfPTable(12);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(2);
        
        // fontes
        Font font2 = FontFactory.getFont(FontFactory.TIMES, 7);

        // linha 1
        PdfPCell cell2= new PdfPCell(new Paragraph("AP: Aprovação", font2));
        cell2.setColspan(6);
        cell2.setPaddingTop(1);
        cell2.setBorderWidth((float) 0.1);
        cell2.setBorderColor(RGBColor.LIGHT_GRAY);
        cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell2.setVerticalAlignment(Element.ALIGN_CENTER);
        cell2.setMinimumHeight(11);
        table2.addCell(cell2);
        PdfPCell cell3= new PdfPCell(new Paragraph("RP: Reprovação", font2));
        cell3.setColspan(6);
        cell3.setPaddingTop(1);
        cell3.setBorderWidth((float) 0.1);
        cell3.setBorderColor(RGBColor.LIGHT_GRAY);
        cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell3.setVerticalAlignment(Element.ALIGN_CENTER);
        cell3.setMinimumHeight(11);
        table2.addCell(cell3);
        
        // linha 2
        PdfPCell cell4= new PdfPCell(new Paragraph("CC: Crédito concedido", font2));
        cell4.setColspan(6);
        cell4.setPaddingTop(1);
        cell4.setBorderWidth((float) 0.1);
        cell4.setBorderColor(RGBColor.LIGHT_GRAY);
        cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell4.setVerticalAlignment(Element.ALIGN_CENTER);
        cell4.setMinimumHeight(11);
        table2.addCell(cell4);
        PdfPCell cell5= new PdfPCell(new Paragraph("CS: Cancelamento de subscrição", font2));
        cell5.setColspan(6);
        cell5.setPaddingTop(1);
        cell5.setBorderWidth((float) 0.1);
        cell5.setBorderColor(RGBColor.LIGHT_GRAY);
        cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell5.setVerticalAlignment(Element.ALIGN_CENTER);
        cell5.setMinimumHeight(11);
        table2.addCell(cell5);
        
        document.add(table2);
        
	}
	
	
	private void emissao() {
		
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		PdfPTable table = new PdfPTable(12);
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);
        
        // fontes
        Font font1 = FontFactory.getFont(FontFactory.TIMES, 8, Font.BOLD);
        font1.setColor(RGBColor.BLUE);
        
        // Linha titulo do bloco
        PdfPCell cell1 = new PdfPCell(new Paragraph("EMISSÂO", font1));
        cell1.setColspan(12);
        cell1.setPaddingTop(0);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setVerticalAlignment(Element.ALIGN_CENTER);
        cell1.setMinimumHeight(11);
        cell1.setBackgroundColor(RGBColor.LIGHT_GRAY);
        table.addCell(cell1);

        document.add(table);
        
        
		PdfPTable table2 = new PdfPTable(12);
        table2.setWidthPercentage(100);
        table2.setSpacingBefore(2);
        
        // fontes
        Font font2 = FontFactory.getFont(FontFactory.TIMES, 7);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        Usuario usuario = usuarios.findByEmail(authentication.getName()).get();
        
        PdfPCell cell2= new PdfPCell(new Paragraph("Nome: " + usuario.getPessoa().getNome(), font2));
        cell2.setColspan(9);
        cell2.setPaddingTop(3);
        cell2.setBorderWidth((float) 0.1);
        cell2.setBorderColor(RGBColor.LIGHT_GRAY);
        cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell2.setVerticalAlignment(Element.ALIGN_CENTER);
        cell2.setMinimumHeight(15);
        table2.addCell(cell2);
        PdfPCell cell3= new PdfPCell(new Paragraph("Emissão em: " + LocalDate.now().format(dtFormatter), font2));
        cell3.setColspan(3);
        cell3.setPaddingTop(3);
        cell3.setBorderWidth((float) 0.1);
        cell3.setBorderColor(RGBColor.LIGHT_GRAY);
        cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell3.setVerticalAlignment(Element.ALIGN_CENTER);
        cell3.setMinimumHeight(15);
        table2.addCell(cell3);
        
        document.add(table2);
        
	}	
	
	
}
