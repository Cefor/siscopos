package br.leg.camara.copos.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.CursoDisciplina;
import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.model.enums.Turma;

public interface Ofertas extends JpaRepository<Oferta, Long> {
	
	public Optional<Oferta> findByCursoDisciplinaAndSemestreAndTurma(CursoDisciplina cursoDisciplina, SemestrePeriodo semestre, Turma turma);
	
	public Optional<Oferta> findByCursoDisciplinaAndSemestreAndCursoDisciplinaSubtitulo(CursoDisciplina cursoDisciplina, SemestrePeriodo semestre, CursoDisciplina cursoDisciplinaSubtitulo);
	
	public List<Oferta> findByCursoDisciplinaCursoAndSemestreAndDataCancelamentoOrderByCursoDisciplinaDisciplinaTipoAscCursoDisciplinaDisciplinaNomeAscTurmaAsc(Curso curso, SemestrePeriodo semestre, LocalDate dataCancelamento);
	
	public List<Oferta> findByCursoDisciplinaCursoAndCursoDisciplinaFlagObrigatoriaAndCursoDisciplinaDisciplinaTipoAndSemestreAndDataCancelamentoOrderByCursoDisciplinaDisciplinaNomeAscTurmaAsc(Curso curso, SimNao  flagObrigatoria, TipoDisciplina tipo, SemestrePeriodo semestre, LocalDate dataCancelamento);

}
