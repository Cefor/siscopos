package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "matricula")
public class Matricula {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_aluno")
	private Aluno aluno;
	
	@OneToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_alunoreg")
	private AlunoReg alunoReg;
	
	@OneToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_alunoesp")
	private AlunoEsp alunoEsp;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_semestre")
	private SemestrePeriodo semestre;
	
	@Column(name = "data_matricula")
	@NotNull(message = "Data da matrícula é obrigatória")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataMatricula;
	
	@Column(name = "data_trancamento")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataTrancamento;

	@OneToOne(optional = true, fetch = FetchType.LAZY)
	@JoinColumn(name = "id_responsavellancamento")
	private Pessoa responsavelLancemento;

		
	public Matricula() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Matricula(Aluno aluno, AlunoReg alunoReg, SemestrePeriodo semestre, LocalDate dataMatricula) {
		super();
		this.aluno = aluno;
		this.alunoReg = alunoReg;
		this.semestre = semestre;
		this.dataMatricula = dataMatricula;
	}

	public Matricula(Aluno aluno, AlunoEsp alunoEsp, SemestrePeriodo semestre, LocalDate dataMatricula) {
		super();
		this.aluno = aluno;
		this.alunoEsp = alunoEsp;
		this.semestre = semestre;
		this.dataMatricula = dataMatricula;
	}
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	public AlunoReg getAlunoReg() {
		return alunoReg;
	}

	public void setAlunoReg(AlunoReg alunoReg) {
		this.alunoReg = alunoReg;
	}

	public AlunoEsp getAlunoEsp() {
		return alunoEsp;
	}

	public void setAlunoEsp(AlunoEsp alunoEsp) {
		this.alunoEsp = alunoEsp;
	}

	public SemestrePeriodo getSemestre() {
		return semestre;
	}

	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}

	public LocalDate getDataMatricula() {
		return dataMatricula;
	}

	public void setDataMatricula(LocalDate dataMatricula) {
		this.dataMatricula = dataMatricula;
	}

	public LocalDate getDataTrancamento() {
		return dataTrancamento;
	}

	public void setDataTrancamento(LocalDate dataTrancamento) {
		this.dataTrancamento = dataTrancamento;
	}

	public Pessoa getResponsavelLancemento() {
		return responsavelLancemento;
	}

	public void setResponsavelLancemento(Pessoa responsavelLancemento) {
		this.responsavelLancemento = responsavelLancemento;
	}

	@Override
	public String toString() {
		return "Matricula [id=" + id + ", aluno=" + aluno + ", alunoReg=" + alunoReg + ", alunoEsp=" + alunoEsp
				+ ", semestre=" + semestre + ", dataMatricula=" + dataMatricula + ", dataTrancamento=" + dataTrancamento
				+ ", responsavelLancemento=" + responsavelLancemento + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(aluno, alunoEsp, alunoReg, dataMatricula, dataTrancamento, id, responsavelLancemento,
				semestre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Matricula other = (Matricula) obj;
		return Objects.equals(aluno, other.aluno) && Objects.equals(alunoEsp, other.alunoEsp)
				&& Objects.equals(alunoReg, other.alunoReg) && Objects.equals(dataMatricula, other.dataMatricula)
				&& Objects.equals(dataTrancamento, other.dataTrancamento) && Objects.equals(id, other.id)
				&& Objects.equals(responsavelLancemento, other.responsavelLancemento)
				&& Objects.equals(semestre, other.semestre);
	}
	
	
}
