package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

import br.leg.camara.copos.model.enums.Turma;

@Entity
@Table(name = "oferta")
public class Oferta {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Disciplina é obrigatória")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_curso_disciplina")
	private CursoDisciplina cursoDisciplina;
	
	@NotNull(message = "Semestre é obrigatório")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_semestre")
	private SemestrePeriodo semestre;
	
	@OneToOne(optional = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_curso_disciplina_subtitulo")
	private CursoDisciplina cursoDisciplinaSubtitulo;
	
	@Column(name = "turma", length = 1)
	@Enumerated(EnumType.STRING)
	private Turma turma;
	
	@Column(name = "vagas")
	private Integer vagas;
	
	@Column(name = "data_cancelamento")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataCancelamento;

	
	public boolean isNova() {
		return id == null;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public CursoDisciplina getCursoDisciplina() {
		return cursoDisciplina;
	}


	public void setCursoDisciplina(CursoDisciplina cursoDisciplina) {
		this.cursoDisciplina = cursoDisciplina;
	}


	public SemestrePeriodo getSemestre() {
		return semestre;
	}


	public void setSemestre(SemestrePeriodo semestre) {
		this.semestre = semestre;
	}


	public CursoDisciplina getCursoDisciplinaSubtitulo() {
		return cursoDisciplinaSubtitulo;
	}


	public void setCursoDisciplinaSubtitulo(CursoDisciplina cursoDisciplinaSubtitulo) {
		this.cursoDisciplinaSubtitulo = cursoDisciplinaSubtitulo;
	}


	public Turma getTurma() {
		return turma;
	}


	public void setTurma(Turma turma) {
		this.turma = turma;
	}


	public Integer getVagas() {
		return vagas;
	}


	public void setVagas(Integer vagas) {
		this.vagas = vagas;
	}


	public LocalDate getDataCancelamento() {
		return dataCancelamento;
	}


	public void setDataCancelamento(LocalDate dataCancelamento) {
		this.dataCancelamento = dataCancelamento;
	}


	@Override
	public String toString() {
		return "Oferta [id=" + id + ", cursoDisciplina=" + cursoDisciplina + ", semestre=" + semestre
				+ ", cursoDisciplinaSubtitulo=" + cursoDisciplinaSubtitulo + ", turma=" + turma + ", vagas=" + vagas
				+ ", dataCancelamento=" + dataCancelamento + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(cursoDisciplina, cursoDisciplinaSubtitulo, dataCancelamento, id, semestre, turma, vagas);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Oferta other = (Oferta) obj;
		return Objects.equals(cursoDisciplina, other.cursoDisciplina)
				&& Objects.equals(cursoDisciplinaSubtitulo, other.cursoDisciplinaSubtitulo)
				&& Objects.equals(dataCancelamento, other.dataCancelamento) && Objects.equals(id, other.id)
				&& Objects.equals(semestre, other.semestre) && turma == other.turma
				&& Objects.equals(vagas, other.vagas);
	}

	

	
}
