package br.leg.camara.copos.service.exception;

public class ExclusaoRegistroJaAssociadoException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public ExclusaoRegistroJaAssociadoException(String msg) {
		super(msg);
	}

}
