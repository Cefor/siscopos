package br.leg.camara.copos.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.bridge.AlunoEspNovo;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.enums.Sexo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.repository.AlunosEsp;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.filter.AlunoEspFilter;
import br.leg.camara.copos.service.AlunoEspService;
import br.leg.camara.copos.service.exception.AlunoJaCadastradoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.PessoaObrigatoriaException;

@Controller
@RequestMapping("/alunoesp")
public class AlunoEspController {

	@Autowired
	private AlunoEspService alunoEspService;

	@Autowired
	private Cursos cursos;
	
	@Autowired
	private Semestres semestres;
	
	@Autowired
	private AlunosEsp alunosEsp;
	
    @Value("${pasta.raiz.origem}")
    private String pastaRaizOrigem;
    
    @Value("${pasta.raiz.espelho}")
    private String pastaRaizEspelho;
    
    @Value("${pasta.pessoas}")
    private String pastaPessoas;
	
	
	@RequestMapping("/novo/{idCurso}")
	public ModelAndView novo(AlunoEspNovo alunoEspNovo, @PathVariable Long idCurso) {
		ModelAndView mv = new ModelAndView("alunoesp/CadastroAlunoEsp");
		
		alunoEspNovo.setCurso(cursos.findById(idCurso).get());
		mv.addObject("semestres", semestres.findByFlagMatriculaOrderByAnoDescSemestreDesc(SimNao.S));
		
		return mv;
	}
	
	
	@PostMapping("/salvarnovo")
	public ModelAndView salvar(@Valid AlunoEspNovo alunoEspNovo, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return novo(alunoEspNovo, alunoEspNovo.getCurso().getId());
		}
		
		try {
			alunoEspService.salvar(alunoEspNovo);
		} catch (PessoaObrigatoriaException e) {
			result.rejectValue("pessoa", e.getMessage(), e.getMessage());
			return novo(alunoEspNovo, alunoEspNovo.getCurso().getId());
		} catch (AlunoJaCadastradoException e) {
			result.rejectValue("pessoa", e.getMessage(), e.getMessage());
			return novo(alunoEspNovo, alunoEspNovo.getCurso().getId());
		}
		
		String artigo = "o";
		if(alunoEspNovo.getPessoa().getSexo().equals(Sexo.F)) {
			artigo = "a";
		}

		attributes.addFlashAttribute("mensagem", "Alun" + artigo + " especial " + alunoEspNovo.getPessoa().getNome() + " (" + alunoEspNovo.getMatricula() + ") salv" + artigo + " com sucesso!");
		return new ModelAndView("redirect:/alunoesp/novo/" + alunoEspNovo.getCurso().getId());
	}
	
	
	@GetMapping("/editar/{id}")
	public ModelAndView editar(AlunoEsp alunoEsp, @PathVariable Long id) {
		ModelAndView mv = new ModelAndView("alunoesp/EdicaoAlunoEsp");
	
		// alunoEsp tem campos vazios qdo vem do icone editar na pagina de pesquisa
		// e eh preciso instanciar alunoEsp a partir da PathVariable id.
		// Qdo vem de salvaEdicao, ja vem preenchido
		if(alunoEsp.isAlunoNovo()) { 
			alunoEsp = alunosEsp.findById(id).get();
		}
		
		mv.addObject(alunoEsp);

		return mv;
	}
	
	
	@PostMapping("/salvaredicao")
	public ModelAndView salvarEdicao(@Valid AlunoEsp alunoEsp, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return editar(alunoEsp, null);
		}
		
		try {
			alunoEspService.salvarEdicao(alunoEsp);
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return editar(alunoEsp, null);
		}
		
		attributes.addFlashAttribute("mensagem", "Aluno especial salvo com sucesso");
		return new ModelAndView("redirect:/alunoesp/novo/" + alunoEsp.getAluno().getCurso().getId());

	}
	
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") AlunoEsp alunoEsp) {
		try {
			alunoEspService.excluir(alunoEsp);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}

	
	@GetMapping
	public ModelAndView pesquisar(AlunoEspFilter alunoEspFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("alunoesp/PesquisaAlunoEsp");

		mv.addObject("cursos", cursos.findByLimiteOptativasEspecialGreaterThan(0));
		mv.addObject("semestres", semestres.findByOrderByAnoDescSemestreDesc());
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaPessoas", pastaPessoas);
	
		PageWrapper<AlunoEsp> paginaWrapper = new PageWrapper<>(alunoEspService.filtrar(alunoEspFilter, pageable),
				httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	
	@GetMapping("/semestre")
	public ModelAndView pesquisarPorMatriculaSemestre(
			AlunoEspFilter alunoEspFilter,
			BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, 
			HttpServletRequest httpServletRequest,
			HttpServletResponse response) throws IOException {
		
	    // Obter o formato solicitado (html ou csv) a partir do parâmetro da requisição
	    String formato = httpServletRequest.getParameter("formato");

	 // Obter os dados filtrados
		PageWrapper<Matricula> paginaWrapper = new PageWrapper<>(
				alunoEspService.filtrarMatriculaSemestre(alunoEspFilter, pageable),
				httpServletRequest);
	    
	    if ("csv".equalsIgnoreCase(formato)) {
	        // Carregar todos os registros ignorando a paginação
	        List<Matricula> todasAsMatriculas = alunoEspService.filtrarTodos(alunoEspFilter);
	        exportarParaCsv(response, todasAsMatriculas);
	        return null; // Encerrar a execução após exportar o arquivo
	    }
		
		ModelAndView mv = new ModelAndView("alunoesp/PesquisaAlunoEspSemestre");

		mv.addObject("cursos", cursos.findByLimiteOptativasEspecialGreaterThan(0));
		mv.addObject("semestres", semestres.findByOrderByAnoDescSemestreDesc());
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}

	/**
	 * Método auxiliar para exportar os dados para CSV.
	*/
	private void exportarParaCsv(HttpServletResponse response, List<Matricula> matriculas) throws IOException {
	    response.setContentType("text/csv");
	    response.setHeader("Content-Disposition", "attachment; filename=\"matriculasEspeciais.csv\"");

	    try (PrintWriter writer = response.getWriter()) {
	        // Cabeçalho do arquivo CSV
	        writer.println("Curso;Nome;CPF;Matrícula;Semestre;Telefone;e-mail");

	        // Iterar pelos registros de matrícula e escrever no arquivo CSV
	        for (Matricula matricula : matriculas) {
	            writer.println(String.format("%s;%s;%s;%s;%s;%s;%s",
	                    matricula.getAluno().getCurso().getSigla(),
	                    matricula.getAluno().getPessoa().getNome(),
	                    matricula.getAluno().getPessoa().getCpf(),
	                    matricula.getAlunoEsp().getMatricula(),
	                    matricula.getSemestre().getPeriodo(),
	                    matricula.getAluno().getPessoa().getTelefone(),
	                    matricula.getAluno().getPessoa().getEmail()
	            		));
	        }

	        writer.flush();
	    }
	}

	
		
}
