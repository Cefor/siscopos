package br.leg.camara.copos.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.filter.DashboardFilter;
import br.leg.camara.copos.service.DashboardService;


@Controller
public class DashboardController {

	@Autowired
	private Cursos cursos;
	
	@Autowired
	private DashboardService dashboardService;
	
	
	@GetMapping("/")
	public ModelAndView principal() {
		return new ModelAndView("redirect:/estatisticas");
	}

	@GetMapping("/estatisticas")
	public ModelAndView dashboard(DashboardFilter dashboardFilter) {
		ModelAndView mv = new ModelAndView("dashboard/Dashboard");
		
		List<Curso> listaCursos = cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc();
		mv.addObject("cursos", listaCursos);

		if(dashboardFilter.getCurso() == null) {
			if(listaCursos.size() > 0) {
				dashboardFilter.setCurso(listaCursos.get(0));	
			}
		}
		
		mv.addObject("ativos", dashboardService.regularesAtivos(dashboardFilter.getCurso()));
		mv.addObject("egressos", dashboardService.regularesEgressos(dashboardFilter.getCurso()));
		mv.addObject("desligados", dashboardService.regularesDesligados(dashboardFilter.getCurso()));
		mv.addObject("prazoEncerrado", dashboardService.regularesAtivosPrazoEncerrado(dashboardFilter.getCurso()));
		mv.addObject("total", dashboardService.regularesTotal(dashboardFilter.getCurso()));
		mv.addObject("qualificados", dashboardService.regularesAtivosQualificados(dashboardFilter.getCurso()));
		mv.addObject("emHomologacao", dashboardService.regularesEmHomologacao(dashboardFilter.getCurso()));
        mv.addObject("trancados", dashboardService.regularesTrancados(dashboardFilter.getCurso()));
        mv.addObject("atributosGrafico1", dashboardService.graficoRegulares(dashboardFilter.getCurso()));
        mv.addObject("atributosGrafico2", dashboardService.graficoEspeciais(dashboardFilter.getCurso()));
		
		return mv;
	}
	
	
	
	
}
