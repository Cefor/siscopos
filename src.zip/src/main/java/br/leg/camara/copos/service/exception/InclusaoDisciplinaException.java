package br.leg.camara.copos.service.exception;

public class InclusaoDisciplinaException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public InclusaoDisciplinaException(String message) {
		super(message);
	}

}
