package br.leg.camara.copos.repository.filter;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;

public class AlunoRegFilter {

	private Curso curso;
	private String nome;
	private String matricula;
	private String cpf;
	private String orientador;
	private SimNao pagante;
	private String linha;
	private boolean flagMatricula;
	private SemestrePeriodo semestreInicio;
	private SemestrePeriodo semestreFim;
	private SituacaoAlunoReg situacaoAlunoReg;
		
	public boolean isCursoVazio() {
		return curso ==  null;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getOrientador() {
		return orientador;
	}

	public void setOrientador(String orientador) {
		this.orientador = orientador;
	}

	public SimNao getPagante() {
		return pagante;
	}

	public void setPagante(SimNao pagante) {
		this.pagante = pagante;
	}

	public String getLinha() {
		return linha;
	}

	public void setLinha(String linha) {
		this.linha = linha;
	}

	public boolean isFlagMatricula() {
		return flagMatricula;
	}

	public void setFlagMatricula(boolean flagMatricula) {
		this.flagMatricula = flagMatricula;
	}

	public SemestrePeriodo getSemestreInicio() {
		return semestreInicio;
	}

	public void setSemestreInicio(SemestrePeriodo semestreInicio) {
		this.semestreInicio = semestreInicio;
	}

	public SemestrePeriodo getSemestreFim() {
		return semestreFim;
	}

	public void setSemestreFim(SemestrePeriodo semestreFim) {
		this.semestreFim = semestreFim;
	}

	public SituacaoAlunoReg getSituacaoAlunoReg() {
		return situacaoAlunoReg;
	}

	public void setSituacaoAlunoReg(SituacaoAlunoReg situacaoAlunoReg) {
		this.situacaoAlunoReg = situacaoAlunoReg;
	}

	
}
