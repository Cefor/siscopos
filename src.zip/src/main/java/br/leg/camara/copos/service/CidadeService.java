package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.Cidade;
import br.leg.camara.copos.repository.filter.CidadeFilter;

public interface CidadeService {
	
	public void salvar(Cidade cidade);
	
	public Page<Cidade> filtrar(CidadeFilter filtro, Pageable pageable);

	void excluir(Cidade cidade);

}
