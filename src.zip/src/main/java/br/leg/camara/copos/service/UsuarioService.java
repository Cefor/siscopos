package br.leg.camara.copos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.Usuario;
import br.leg.camara.copos.repository.filter.UsuarioFilter;

public interface UsuarioService {

	Optional<Usuario> porEmailEAtivo(String email);

	List<String> permissoes(Usuario usuario);

	Page<Usuario> filtrar(UsuarioFilter filtro, Pageable pageable);

	Usuario buscarComGrupos(Long codigo);
	
	public void salvar(Usuario usuario);
	
	public void alterarStatus(Long[] codigos, StatusUsuario statusUsuario);
	
	public void excluir(Usuario usuario);

}
