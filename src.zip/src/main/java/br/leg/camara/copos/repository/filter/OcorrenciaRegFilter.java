package br.leg.camara.copos.repository.filter;

import java.time.LocalDate;

import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.TipoOcorrenciaReg;

public class OcorrenciaRegFilter {

	private Curso curso;
	private TipoOcorrenciaReg tipoOcorrenciaReg;
	private String nomeAlunoReg;
	private LocalDate dataInicio;
	private LocalDate dataFim;
	
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public TipoOcorrenciaReg getTipoOcorrenciaReg() {
		return tipoOcorrenciaReg;
	}
	public void setTipoOcorrenciaReg(TipoOcorrenciaReg tipoOcorrenciaReg) {
		this.tipoOcorrenciaReg = tipoOcorrenciaReg;
	}
	public String getNomeAlunoReg() {
		return nomeAlunoReg;
	}
	public void setNomeAlunoReg(String nomeAlunoReg) {
		this.nomeAlunoReg = nomeAlunoReg;
	}
	public LocalDate getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(LocalDate dataInicio) {
		this.dataInicio = dataInicio;
	}
	public LocalDate getDataFim() {
		return dataFim;
	}
	public void setDataFim(LocalDate dataFim) {
		this.dataFim = dataFim;
	}
	
}
