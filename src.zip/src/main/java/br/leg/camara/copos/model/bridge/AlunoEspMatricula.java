package br.leg.camara.copos.model.bridge;

import java.time.LocalDate;

import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.Oferta;

public class AlunoEspMatricula {

	// Matricula
	private Long id;
	private AlunoEsp alunoEsp;
	private LocalDate dataMatricula;

	// MatriculaDisciplina
	private Oferta oferta;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public AlunoEsp getAlunoEsp() {
		return alunoEsp;
	}

	public void setAlunoEsp(AlunoEsp alunoEsp) {
		this.alunoEsp = alunoEsp;
	}

	public LocalDate getDataMatricula() {
		return dataMatricula;
	}

	public void setDataMatricula(LocalDate dataMatricula) {
		this.dataMatricula = dataMatricula;
	}

	public Oferta getOferta() {
		return oferta;
	}

	public void setOferta(Oferta oferta) {
		this.oferta = oferta;
	}

}
