package br.leg.camara.copos.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.bridge.AlunoRegMatricula;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.Matriculas;
import br.leg.camara.copos.repository.MatriculasDisciplinas;
import br.leg.camara.copos.repository.Ofertas;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.filter.AlunoRegFilter;
import br.leg.camara.copos.service.AlunoRegService;
import br.leg.camara.copos.service.MatriculaAlunoRegService;
import br.leg.camara.copos.service.exception.DataTrancamentoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.InclusaoDisciplinaException;

@Controller
@RequestMapping("/matriculasreg")
public class MatriculaAlunoRegController {

	
	@Autowired
	private Semestres semestres;
	
	@Autowired
	private AlunosReg alunosReg;
	
	@Autowired
	private MatriculasDisciplinas matriculasDisciplinas;
	
	@Autowired
	private Ofertas ofertas;
	
	@Autowired
	private MatriculaAlunoRegService matriculaAlunoRegService;

	@Autowired
	private AlunoRegService alunoRegService;
	
	@Autowired
	private Cursos cursos;
	
	@Autowired
	private Matriculas matriculas;

	
	
	@GetMapping("/nova/{id}")
	public ModelAndView nova(AlunoRegMatricula alunoRegMatricula, @PathVariable Long id) {

		ModelAndView mv = new ModelAndView("matriculareg/MatriculaAlunoReg");
		
		// AlunoRegMatricula alunoRegMatricula = new AlunoRegMatricula();
		alunoRegMatricula.setAlunoReg(alunosReg.findById(id).get());
		alunoRegMatricula.setDataMatricula(LocalDate.now());

		List<SemestrePeriodo> semestresLista = semestres.findByFlagMatriculaOrderByAnoDescSemestreDesc(SimNao.S);
		List<Oferta> ofertasLista = new ArrayList<>();
		
		for (SemestrePeriodo semestre : semestresLista) {
			ofertasLista.addAll(
					ofertas.findByCursoDisciplinaCursoAndSemestreAndDataCancelamentoOrderByCursoDisciplinaDisciplinaTipoAscCursoDisciplinaDisciplinaNomeAscTurmaAsc(
							alunoRegMatricula.getAlunoReg().getAluno().getCurso(), 
							semestre,
							null)
					);
		}
		
		mv.addObject(alunoRegMatricula);
		mv.addObject("semestresLista", semestresLista);
		mv.addObject("ofertas", ofertasLista);
		mv.addObject("matriculasDisciplinas", matriculasDisciplinas.findByMatriculaAlunoOrderByOfertaSemestreAscDataMencaoAscOfertaCursoDisciplinaDisciplinaSiglaAsc(alunoRegMatricula.getAlunoReg().getAluno()));

		return mv;
	}

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid AlunoRegMatricula alunoRegMatricula, BindingResult result, RedirectAttributes attributes) {

	
		try {
			matriculaAlunoRegService.salvar(alunoRegMatricula);	
		} catch (InclusaoDisciplinaException e) {
			//result.rejectValue(null, e.getMessage(), e.getMessage());
			// return nova(alunoRegMatricula, alunoRegMatricula.getAlunoReg().getId());
			
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/matriculasreg/nova/" + alunoRegMatricula.getAlunoReg().getId());
		} catch (Exception e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/matriculasreg/nova/" + alunoRegMatricula.getAlunoReg().getId());
			
		}
		
		
		
		attributes.addFlashAttribute("mensagem", "Matrícula efetivada: " +
				                      alunoRegMatricula.getOferta().getSemestre().getPeriodo() + 
				                      " - " +
		                              alunoRegMatricula.getOferta().getCursoDisciplina().getDisciplina().getNome() +
		                              ((alunoRegMatricula.getOferta().getTurma() != null) ? " - " + alunoRegMatricula.getOferta().getTurma() : "")
		                              );
		return new ModelAndView("redirect:/matriculasreg/nova/" + alunoRegMatricula.getAlunoReg().getId());
	}

	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") MatriculaDisciplina matriculaDisciplina) {
		try {
			matriculaAlunoRegService.excluir(matriculaDisciplina);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}


	
	@GetMapping
	public ModelAndView pesquisar(AlunoRegFilter alunoRegFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {

		ModelAndView mv = new ModelAndView("matriculareg/PesquisaAlunoRegMatricula");
		alunoRegFilter.setFlagMatricula(true);

		List<Curso> listaCursos = cursos.findByDataFimGreaterThanOrDataFimIsNull(LocalDate.now());
		mv.addObject("cursos", listaCursos);
		
		if(alunoRegFilter.getCurso() == null) {
			if(listaCursos.size() > 0) {
				alunoRegFilter.setCurso(listaCursos.get(0)); // Mestrado	
			}
		}
		
		mv.addObject("simnao", SimNao.values());
	
		PageWrapper<AlunoReg> paginaWrapper = new PageWrapper<>(alunoRegService.filtrar(alunoRegFilter, pageable),
				httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}

	
	@GetMapping("/editardatatrancamento/{id}")
	public ModelAndView editarDataTrancamento(@PathVariable Long id) {
		Matricula matricula = matriculas.findOne(id);
		
		ModelAndView mv = new ModelAndView("matriculareg/EdicaoDataTrancamento");
		mv.addObject(matricula);
		return mv;
	}
	
	@PostMapping("/salvardatatrancamento")
	public ModelAndView salvarDataTrancamento(@Valid Matricula matricula, BindingResult result, RedirectAttributes attributes) {

		try {
			matriculaAlunoRegService.salvarDataTrancamento(matricula);
		} catch (DataTrancamentoException e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/matriculasreg/nova/" + matricula.getAlunoReg().getId());
		} catch (Exception e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/matriculasreg/nova/" + matricula.getAlunoReg().getId());
		}
		
		attributes.addFlashAttribute("mensagem", "Data de trancamento alterada com sucesso");
		return new ModelAndView("redirect:/matriculasreg/nova/" + matricula.getAlunoReg().getId());
	}

		
}
