package br.leg.camara.copos.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.bridge.AlunoEspMatricula;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SimNao;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.repository.AlunosEsp;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.MatriculasDisciplinas;
import br.leg.camara.copos.repository.Ofertas;
import br.leg.camara.copos.repository.Semestres;
import br.leg.camara.copos.repository.filter.AlunoEspFilter;
import br.leg.camara.copos.service.MatriculaAlunoEspService;
import br.leg.camara.copos.service.exception.AtingiuLimiteDisciplinasException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.InclusaoDisciplinaException;

@Controller
@RequestMapping("/matriculaesp")
public class MatriculaAlunoEspController {

	
	@Autowired
	private Semestres semestres;
	
	@Autowired
	private AlunosEsp alunosEsp;
	
	@Autowired
	private MatriculasDisciplinas matriculasDisciplinas;
	
	@Autowired
	private Ofertas ofertas;
	
	@Autowired
	private MatriculaAlunoEspService matriculaAlunoEspService;

	@Autowired
	private Cursos cursos;

	@Autowired
	private AlunosReg alunosReg;

	
	
	@GetMapping("/nova/{id}")
	public ModelAndView nova(AlunoEspMatricula alunoEspMatricula, @PathVariable Long id) {

		ModelAndView mv = new ModelAndView("matriculaesp/MatriculaAlunoEsp");
		
		alunoEspMatricula.setAlunoEsp(alunosEsp.findById(id).get());
		alunoEspMatricula.setDataMatricula(LocalDate.now());
		
		List<SemestrePeriodo> semestresLista = semestres.findByFlagMatriculaOrderByAnoDescSemestreDesc(SimNao.S);
		List<Oferta> ofertasLista = new ArrayList<>();
		
		for (SemestrePeriodo semestre : semestresLista) {
			ofertasLista.addAll(
					ofertas.findByCursoDisciplinaCursoAndCursoDisciplinaFlagObrigatoriaAndCursoDisciplinaDisciplinaTipoAndSemestreAndDataCancelamentoOrderByCursoDisciplinaDisciplinaNomeAscTurmaAsc(
							alunoEspMatricula.getAlunoEsp().getAluno().getCurso(),
							SimNao.N,
							TipoDisciplina.DISC,
							semestre,
							null)
					);
		}

		// se o aluno especial já tiver sido aluno regular, 
		// desabilita edicao e exclusao de matricula do que foi cursado ate a finalizacao do curso
		Optional<AlunoReg> alunoReg = alunosReg.findByAluno(alunoEspMatricula.getAlunoEsp().getAluno());
		if(alunoReg.isPresent()) {
			if(alunoReg.get().getDataHomologacao() != null) {
				mv.addObject("periodoReg", alunoReg.get().getDataHomologacao().getYear() + "/" + (alunoReg.get().getDataHomologacao().getMonthValue() > 6 ? 2 : 1));		
			} else if(alunoReg.get().getDataDesligamento() != null) {
				mv.addObject("periodoReg", alunoReg.get().getDataDesligamento().getYear() + "/" + (alunoReg.get().getDataDesligamento().getMonthValue() > 6 ? 2 : 1));
			}
		}
		
		mv.addObject(alunoEspMatricula);
		mv.addObject("semestresLista", semestresLista);
		mv.addObject("ofertas", ofertasLista);
		mv.addObject("matriculasDisciplinas", matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaDisciplinaTipoOrderByOfertaSemestreAscDataMencaoAscOfertaCursoDisciplinaDisciplinaSiglaAsc(alunoEspMatricula.getAlunoEsp().getAluno(), TipoDisciplina.DISC));

		return mv;
	}
	
	
	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid AlunoEspMatricula alunoEspMatricula, BindingResult result, RedirectAttributes attributes) {
	
		if (result.hasErrors()) {
			return nova(alunoEspMatricula, alunoEspMatricula.getAlunoEsp().getId());
		}

		
		try {
			matriculaAlunoEspService.salvar(alunoEspMatricula);	
		} catch (InclusaoDisciplinaException e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/matriculaesp/nova/" + alunoEspMatricula.getAlunoEsp().getId());
		} catch (AtingiuLimiteDisciplinasException e) {
			attributes.addFlashAttribute("mensagemerro", e.getMessage());
			return new ModelAndView("redirect:/matriculaesp/nova/" + alunoEspMatricula.getAlunoEsp().getId());
		}
		
		attributes.addFlashAttribute("mensagem", "Matrícula efetivada: " +
				                      alunoEspMatricula.getOferta().getSemestre().getPeriodo() + 
				                      " - " +
		                              alunoEspMatricula.getOferta().getCursoDisciplina().getDisciplina().getNome() +
		                              ((alunoEspMatricula.getOferta().getTurma() != null) ? " - " + alunoEspMatricula.getOferta().getTurma() : "")
		                              );
		return new ModelAndView("redirect:/matriculaesp/nova/" + alunoEspMatricula.getAlunoEsp().getId());
	}

	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") MatriculaDisciplina matriculaDisciplina) {
		try {
			matriculaAlunoEspService.excluir(matriculaDisciplina);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}

	
	@GetMapping
	public ModelAndView pesquisar(AlunoEspFilter alunoEspFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("matriculaesp/PesquisaAlunoEspMatricula");

		List<Curso> listaCurso = cursos.findByLimiteOptativasEspecialGreaterThanAndDataFimGreaterThanOrDataFimIsNull(0, LocalDate.now());
		
		if(alunoEspFilter.isCursoVazio()){
			if(listaCurso.size() > 0) {
				alunoEspFilter.setCurso(listaCurso.get(0));	
			}
		}
		
		mv.addObject("cursos", listaCurso);
		
				
		PageWrapper<AlunoEsp> paginaWrapper = new PageWrapper<>(matriculaAlunoEspService.filtrar(alunoEspFilter, pageable),
				httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}

		
}
