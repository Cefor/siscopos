package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "ocorrenciareg")
public class OcorrenciaReg {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_alunoreg")
	private AlunoReg alunoReg;
	
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_tipoocorrenciareg")
	private TipoOcorrenciaReg tipoOcorrenciaReg;
	
	@NotNull(message = "Data da ocorrência é obrigatória")
	@Column(name = "data_ocorrencia")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataOcorrencia;	
	
	@Column(name = "descricao", length = 255)
	@NotBlank(message = "Descrição da ocorrência é obrigatória")
	private String descricao;

	public boolean isNova() {
		return id == null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public AlunoReg getAlunoReg() {
		return alunoReg;
	}

	public void setAlunoReg(AlunoReg alunoReg) {
		this.alunoReg = alunoReg;
	}

	public TipoOcorrenciaReg getTipoOcorrenciaReg() {
		return tipoOcorrenciaReg;
	}

	public void setTipoOcorrenciaReg(TipoOcorrenciaReg tipoOcorrenciaReg) {
		this.tipoOcorrenciaReg = tipoOcorrenciaReg;
	}

	public LocalDate getDataOcorrencia() {
		return dataOcorrencia;
	}

	public void setDataOcorrencia(LocalDate dataOcorrencia) {
		this.dataOcorrencia = dataOcorrencia;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public String toString() {
		return "OcorrenciaReg [id=" + id + ", alunoReg=" + alunoReg + ", tipoOcorrenciaReg=" + tipoOcorrenciaReg
				+ ", dataOcorrencia=" + dataOcorrencia + ", descricao=" + descricao + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(alunoReg, dataOcorrencia, descricao, id, tipoOcorrenciaReg);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OcorrenciaReg other = (OcorrenciaReg) obj;
		return Objects.equals(alunoReg, other.alunoReg) && Objects.equals(dataOcorrencia, other.dataOcorrencia)
				&& Objects.equals(descricao, other.descricao) && Objects.equals(id, other.id)
				&& Objects.equals(tipoOcorrenciaReg, other.tipoOcorrenciaReg);
	}
	
}
