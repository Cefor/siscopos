package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.InstituicaoParceira;
import br.leg.camara.copos.repository.InstituicoesParceiras;
import br.leg.camara.copos.repository.filter.InstituicaoParceiraFilter;
import br.leg.camara.copos.service.InstituicaoParceiraService;
import br.leg.camara.copos.service.exception.CnpjJaCadastradoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Controller
@RequestMapping("/instituicao")
public class InstituicaoParceiraController {


	@Autowired
	private InstituicaoParceiraService instituicaoParceiraService;

	@Autowired
	private InstituicoesParceiras instituicoesParceiras;
	

	@RequestMapping("/nova")
	public ModelAndView nova(InstituicaoParceira instituicaoParceira) {
		ModelAndView mv = new ModelAndView("instituicaoparceira/CadastroInstituicaoParceira");
		
		return mv;
	}

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid InstituicaoParceira instituicaoParceira, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(instituicaoParceira);
		}
	
		try {
			instituicaoParceiraService.salvar(instituicaoParceira);
		} catch (CnpjJaCadastradoException e) {
			result.rejectValue("cnpj", e.getMessage(), e.getMessage());
			return nova(instituicaoParceira);
		} 
		
		
		attributes.addFlashAttribute("mensagem", "Curso salvo com sucesso!");
		return new ModelAndView("redirect:/instituicao/nova");
	}	
	

	@GetMapping("/editar/{id}")
	public ModelAndView editar(@PathVariable Long id) {
		InstituicaoParceira instituicaoParceira = instituicoesParceiras.findOne(id);
		
		ModelAndView mv = nova(instituicaoParceira);
		mv.addObject(instituicaoParceira);
		return mv;
	}
	
		
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") InstituicaoParceira instituicaoParceira){
		try {
			instituicaoParceiraService.excluir(instituicaoParceira);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}

	
	@GetMapping
	public ModelAndView pesquisar(InstituicaoParceiraFilter instituicaoParceiraFilter,BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("instituicaoparceira/PesquisaInstituicaoParceira");

		PageWrapper<InstituicaoParceira> paginaWrapper = new PageWrapper<>(instituicaoParceiraService.filtrar(instituicaoParceiraFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		
		return mv;
	}
	
	
	
}
