package br.leg.camara.copos.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Aluno;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.Curso;
import br.leg.camara.copos.model.entity.CursoDisciplina;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.model.entity.SemestrePeriodo;
import br.leg.camara.copos.model.enums.SituacaoAlunoReg;
import br.leg.camara.copos.model.enums.TipoDisciplina;

public interface MatriculasDisciplinas extends JpaRepository<MatriculaDisciplina, Long> {
	
	public List<MatriculaDisciplina> findByMatriculaAlunoOrderByOfertaSemestreAscDataMencaoAscOfertaCursoDisciplinaDisciplinaSiglaAsc(Aluno aluno);
	
	public List<MatriculaDisciplina> findByMatriculaAlunoAndOfertaCursoDisciplinaDisciplinaTipoOrderByOfertaSemestreAscDataMencaoAscOfertaCursoDisciplinaDisciplinaSiglaAsc(Aluno aluno, TipoDisciplina tipoDisciplina);
	
	// uso em: verifica se estah se matriculando em subtitulo que ja foi optativa
	public List<MatriculaDisciplina> findByMatriculaAlunoAndOfertaCursoDisciplinaAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(Aluno aluno, CursoDisciplina cursoDisciplina);
	
	// uso em: verifica se a disciplina ja foi cadastrada
	public List<MatriculaDisciplina> findByMatriculaAlunoAndOfertaCursoDisciplinaAndOfertaCursoDisciplinaSubtituloAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(Aluno aluno, CursoDisciplina cursoDisciplina, CursoDisciplina cursoDisciplinaSubtitulo);
	
	// uso em: verifica se estah se matriculando em optativa que ja foi subtitulo
    public List<MatriculaDisciplina> findByMatriculaAlunoAndOfertaCursoDisciplinaSubtituloAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(Aluno aluno, CursoDisciplina cursoDisciplina);

	// uso em: verifica se houve duas reprovacoes como aluno regular
	public List<MatriculaDisciplina> findByMatriculaAlunoRegAndMencao(AlunoReg alunoReg, String mencao);
		
	// uso em: verificacao de semestre trancado
	public List<MatriculaDisciplina> findByMatriculaAlunoRegAndOfertaCursoDisciplinaDisciplinaSiglaOrderByOfertaSemestreDesc(AlunoReg alunoReg, String siglaDisciplina);
	
	public List<MatriculaDisciplina> findByOfertaOrderByMatriculaAlunoPessoaNomeAsc(Oferta oferta);
	
	// uso em: nao deixa trancar semestre quando houver disciplina com mencao lancada
	public List<MatriculaDisciplina> findByMatriculaAlunoRegAndOfertaSemestre(AlunoReg alunoReg, SemestrePeriodo semestre);

	
	// uso em: verifica se ja cursou o limite de optativas como especial para o curso
	public List<MatriculaDisciplina> findByMatriculaAlunoEspAndMencaoIn(AlunoEsp alunoEsp, List<String> mencoes);
	
	// uso em: verifica se ja se matriculou no limite de optativas como especial para o semestre
	public List<MatriculaDisciplina> findByMatriculaAlunoEspAndOfertaSemestre(AlunoEsp alunoEsp, SemestrePeriodo semestre);

	
	public Optional<MatriculaDisciplina> findByMatriculaAndOferta(Matricula matricula, Oferta oferta);
	
	// uso em: verifica se ainda existem disciplinas no semestre corrente para o aluno
	public List<MatriculaDisciplina> findByMatriculaAlunoAndOfertaSemestre(Aluno aluno, SemestrePeriodo semestre);
	
	// usado em: quantos regulares ja qualificaram e defenderam
	public List<MatriculaDisciplina> findByMatriculaAlunoCursoAndMatriculaAlunoRegIsNotNullAndMatriculaAlunoRegSituacaoAlunoRegAndOfertaCursoDisciplinaDisciplinaSiglaAndMencao(Curso curso, SituacaoAlunoReg situacaoAlunoReg, String sigla, String mencao);
	
	// usado em: quantos regulares ja defenderam e aguardam homologacao
	public List<MatriculaDisciplina> findByMatriculaAlunoCursoAndMatriculaAlunoRegIsNotNullAndOfertaCursoDisciplinaDisciplinaSiglaAndMencaoAndMatriculaAlunoRegDataHomologacaoIsNull(Curso curso, String sigla, String Mencao);

}
