package br.leg.camara.copos.service.exception;

public class PessoaObrigatoriaException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public PessoaObrigatoriaException(String message) {
		super(message);
	}

}
