package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.OfertaProfessor;
import br.leg.camara.copos.model.entity.Professor;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.CursosLinhasPesquisa;
import br.leg.camara.copos.repository.Professores;
import br.leg.camara.copos.repository.filter.DisciplinaMinistradaFilter;
import br.leg.camara.copos.repository.filter.OrientacaoFilter;
import br.leg.camara.copos.repository.filter.ProfessorFilter;
import br.leg.camara.copos.service.ProfessorService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Controller
@RequestMapping("/professores")
public class ProfessorController {

	@Autowired
	private ProfessorService professorService;

	@Autowired
	private Cursos cursos;

	@Autowired
	private Professores professores;
	
	@Autowired
	private CursosLinhasPesquisa cursosLinhasPesquisa;
	
    @Value("${pasta.raiz.origem}")
    private String pastaRaizOrigem;
    
    @Value("${pasta.raiz.espelho}")
    private String pastaRaizEspelho;
    
    @Value("${pasta.pessoas}")
    private String pastaPessoas;
    
		
	@GetMapping
	public ModelAndView pesquisar(ProfessorFilter professorFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("professor/PesquisaProfessor");
		
		mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
		mv.addObject("pastaRaizOrigem", pastaRaizOrigem);
		mv.addObject("pastaRaizEspelho", pastaRaizEspelho);
		mv.addObject("pastaPessoas", pastaPessoas);

		PageWrapper<Professor> paginaWrapper = new PageWrapper<>(professorService.filtrar(professorFilter, pageable),
				httpServletRequest);
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	
	@GetMapping("/orientacoes/{idProfessor}") // chamado na pesquisa de professores
	public ModelAndView orientacoes(OrientacaoFilter orientacaoFilter, 
			@PathVariable Long idProfessor,
			@PageableDefault(size = 10) Pageable pageable,
			HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("professor/ProfessorOrientacoes");
		
		orientacaoFilter.setIdProfessor(idProfessor);
		
		// recupera o professor
		Professor professor = professores.findOne(orientacaoFilter.getIdProfessor());

		mv.addObject("professor", professor);
		mv.addObject("cursos", professor.getCurso());
		
		
		PageWrapper<AlunoReg> paginaWrapper = new PageWrapper<>(professorService.orientacoes(orientacaoFilter, pageable),
				httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	@GetMapping("/orientacoes") // chamado no botao Pesquisar
	public ModelAndView orientacoes2(OrientacaoFilter orientacaoFilter, 
			@PageableDefault(size = 10) Pageable pageable,
			HttpServletRequest httpServletRequest) {
		
		return orientacoes(orientacaoFilter, orientacaoFilter.getIdProfessor(), pageable, httpServletRequest);
		
	}


	@GetMapping("/disciplinas/{idProfessor}") // chamado na pesquisa de professores
	public ModelAndView disciplinas(DisciplinaMinistradaFilter disciplinaMinistradaFilter, 
			@PathVariable Long idProfessor,
			@PageableDefault(size = 10) Pageable pageable,
			HttpServletRequest httpServletRequest) {
		ModelAndView mv = new ModelAndView("professor/ProfessorDisciplinas");
		
		disciplinaMinistradaFilter.setIdProfessor(idProfessor);
		
		// recupera o professor
		Professor professor = professores.findOne(idProfessor);
		
		mv.addObject("professor", professor);
		mv.addObject("cursos", professor.getCurso());
		
		PageWrapper<OfertaProfessor> paginaWrapper = new PageWrapper<>(professorService.disciplinas(disciplinaMinistradaFilter, pageable),
				httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
	
	@GetMapping("/disciplinas") // chamado no botao Pesquisar
	public ModelAndView disciplinas2(DisciplinaMinistradaFilter disciplinaMinistradaFilter,
			@PageableDefault(size = 10) Pageable pageable,
			HttpServletRequest httpServletRequest) {
		
		return disciplinas(disciplinaMinistradaFilter, disciplinaMinistradaFilter.getIdProfessor(), pageable, httpServletRequest);
	
	}
	
	
	
	
	@RequestMapping("/novo/{idCurso}")
	public ModelAndView novo(Professor professor, @PathVariable Long idCurso) {
		ModelAndView mv = new ModelAndView("professor/CadastroProfessor");
		
		professor.setCurso(cursos.findById(idCurso).get());
		mv.addObject("cursoLinhas", cursosLinhasPesquisa.findByCurso(professor.getCurso()));

		
		return mv;
	}
	
	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid Professor professor, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return novo(professor, professor.getCurso().getId());
		}
		
		try {
			professorService.salvar(professor);
		} catch (DuplicidadeIndiceUnicoException e) {
			result.rejectValue("pessoa", e.getMessage(), e.getMessage());
			return novo(professor, professor.getCurso().getId()); 
		} catch (Exception e) {
			result.rejectValue("pessoa", e.getMessage(), e.getMessage());
			return novo(professor, professor.getCurso().getId());
		}
		
		
		attributes.addFlashAttribute("mensagem", "Professor(a) " +
				                                  professor.getPessoa().getNome() + 
				                                  " foi inserido(a) com sucesso no curso " +
		                                          professor.getCurso().getSigla());
		return new ModelAndView("redirect:/professores/novo/" + professor.getCurso().getId());
		
	}
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") Professor professor){
	
		try {
			professorService.excluir(professor);
		} catch (ExclusaoRegistroJaAssociadoException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}

		
		return ResponseEntity.ok().build();
	}
	
	
}





