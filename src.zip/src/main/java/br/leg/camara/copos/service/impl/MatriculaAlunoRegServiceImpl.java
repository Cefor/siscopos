package br.leg.camara.copos.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import br.leg.camara.copos.model.bridge.AlunoRegMatricula;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.model.enums.TipoDisciplina;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.Matriculas;
import br.leg.camara.copos.repository.MatriculasDisciplinas;
import br.leg.camara.copos.service.MatriculaAlunoRegService;
import br.leg.camara.copos.service.exception.DataTrancamentoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.InclusaoDisciplinaException;

@Service
public class MatriculaAlunoRegServiceImpl implements MatriculaAlunoRegService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private Matriculas matriculas;
	
	@Autowired
	private MatriculasDisciplinas matriculasDisciplinas;
	
	@Autowired
	private AlunosReg alunosReg;
	
	
	@Override
	@Transactional
	public void salvar(AlunoRegMatricula alunoRegMatricula) {

		// verifica se existe semestre trancado
		List<MatriculaDisciplina> matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoRegAndOfertaCursoDisciplinaDisciplinaSiglaOrderByOfertaSemestreDesc(
				                                              alunoRegMatricula.getAlunoReg(),
				                                              "TRANCA");
		// caso haja semestre trancado ...
		for(MatriculaDisciplina matDisciplina : matDisciplinas) {
			
			// verifica se eh tentatativa de novo trancamento de matricula
			if(alunoRegMatricula.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("TRANCA")) {
				throw new InclusaoDisciplinaException("Não é permitido trancamento de matrícula por mais de um semestre");
			}
			
			// verifica se eh tentativa de matricula em semestre trancado 
			if(alunoRegMatricula.getOferta().getSemestre().equals(matDisciplina.getOferta().getSemestre())) {
				throw new InclusaoDisciplinaException("O semestre " + 
			                                           matDisciplina.getOferta().getSemestre().getPeriodo() +
			                                           " está trancado e não admite matrícula");
			}
		}
		
		
		// verifica se existe registro na entidade Matricula para o semestre
		Optional<Matricula> matricula = matriculas.findByAlunoAndSemestre(
				alunoRegMatricula.getAlunoReg().getAluno(),
				alunoRegMatricula.getOferta().getSemestre());
		
		if(!matricula.isPresent()) { // se nao existir
			matricula = Optional.ofNullable(new Matricula(
					alunoRegMatricula.getAlunoReg().getAluno(),
					alunoRegMatricula.getAlunoReg(),
					alunoRegMatricula.getOferta().getSemestre(),
					LocalDate.now()
					));
			
			// grava novo registro em Matricula
			matriculas.save(matricula.get());
		} else { // se existir, verifica se eh matricula de aluno regular
			
			if(matricula.get().getAlunoEsp() != null) {
				throw new InclusaoDisciplinaException("Já existe matrícula como aluno especial no semestre " + 
						                               alunoRegMatricula.getOferta().getSemestre().getPeriodo() +
						                               ", o que não é permitido. Reveja a situação do aluno.");
			}
		}

	
		// verifica se a disciplina ja foi cadastrada ...
		//matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaOrderByOfertaSemestreDesc(
		//	    alunoRegMatricula.getAlunoReg().getAluno(), 
		//	    alunoRegMatricula.getOferta().getCursoDisciplina());
		
		// verifica se a disciplina ja foi cadastrada ...		
		matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaAndOfertaCursoDisciplinaSubtituloAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(
			  alunoRegMatricula.getAlunoReg().getAluno(), 
			  alunoRegMatricula.getOferta().getCursoDisciplina(),
			  alunoRegMatricula.getOferta().getCursoDisciplinaSubtitulo());
		
		
		// para o registro mais recente, verifica se houve aprovacao ou se ja esta matriculado na disciplina sendo inserida
		if(matDisciplinas.size() > 0) {
			if((matDisciplinas.get(0).getMencao() == null) ||     // ja esta matriculado na disciplina
				matDisciplinas.get(0).getMencao().isEmpty() ||    // ja esta matriculado na disciplina
				matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("ATIVCO") ||  // so aceita um registro de ATIVCO
				matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("DEFESA")) {  // so aceita um registro de DEFESA

				// se for DISC, envia mensagem de erro com Turma
				if(matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getTipo().equals(TipoDisciplina.DISC)) {
						throw new InclusaoDisciplinaException("Registro de matrícula existente: " + 
								matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
								matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getNome() + " - " +
								matDisciplinas.get(0).getOferta().getTurma() + 
								(matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo() != null ? " - " + matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getSigla() : "")
								);
					
				} else {
					// se for outro componente curricular, envia mensagem de erro sem turma, ou, 
					// permite matricular em mais de um semestre se for ATIVOR 
					if(! (matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("ATIVOR") &&
						  !matDisciplinas.get(0).getOferta().getSemestre().getPeriodo().equals(alunoRegMatricula.getOferta().getSemestre().getPeriodo())
						 )	
					  ) {
						throw new InclusaoDisciplinaException("Registro de matrícula existente: " + 
								matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
								matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getNome()
								);
					}
				}
				
			} else if(matDisciplinas.get(0).getMencao().equals("AP")) {  // ja foi aprovado na disciplina
				throw new InclusaoDisciplinaException("Disciplina cursada com aprovação: " +
						matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getNome() + 
						(matDisciplinas.get(0).getOferta().getTurma() != null ? (" - " + matDisciplinas.get(0).getOferta().getTurma()) : "") +
						(matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo() != null ? " - " + matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getSigla() : "")
						);
			} 
		}

		
		// se for aproveitamento de estudos no mesmo semestre, tem que ser em turma diferente
		for(MatriculaDisciplina matDisciplina : matDisciplinas) {
			if(matDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("APROVE")) {
				if(alunoRegMatricula.getOferta().getTurma().equals(matDisciplina.getOferta().getTurma())) {
					throw new InclusaoDisciplinaException("Aproveitamentos de estudos no mesmo semestre devem ser lançados em turmas diferentes");
				}
			}
		}
		
		// verifica se eh trancamento de semestre
		if(alunoRegMatricula.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("TRANCA")) {
			
			// nao pode trancar semestre qdo houver disciplina com mencao lancada
			// exceto se for "CC" ou "CS" ou a disciplina for qualificacao
			matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoRegAndOfertaSemestre(alunoRegMatricula.getAlunoReg(), alunoRegMatricula.getOferta().getSemestre());
			for(MatriculaDisciplina matDisciplina : matDisciplinas) {
				if(!"CC".equals(matDisciplina.getMencao()) && 
						!"CS".equals(matDisciplina.getMencao()) && 
						matDisciplina.getMencao() != null &&
						!matDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("EQUALI")) {
					throw new InclusaoDisciplinaException("O semestre " + alunoRegMatricula.getOferta().getSemestre().getPeriodo() + " não pode ser trancado, pois já existem disciplinas com menção lançada.");
				}
			}
			
			// inserir data trancamento
			//matricula.get().setDataTrancamento(LocalDate.now());
			String dataString = matricula.get().getSemestre().getAno() + "-0";
			if(matricula.get().getSemestre().getSemestre().equals("1")) {
				dataString = dataString + "1-01";
			} else {
				dataString = dataString + "7-01";
			}
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			matricula.get().setDataTrancamento(LocalDate.parse(dataString, formatter));
			matriculas.save(matricula.get());

			
			// alterar prazo conclusao alunoReg para prazo_conclusao curso + 6 meses
			alunoRegMatricula.getAlunoReg().setPrazoConclusao(alunoRegMatricula.getAlunoReg().getSemestre().getDia1().plusMonths( alunoRegMatricula.getAlunoReg().getAluno().getCurso().getPrazoConclusao() + 6 ).minusDays(1));
			alunosReg.save(alunoRegMatricula.getAlunoReg());
		}

		
		// verifica se estah se matriculando em optativa que ja foi subtitulo
		matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaSubtituloAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(
			    alunoRegMatricula.getAlunoReg().getAluno(), 
			    alunoRegMatricula.getOferta().getCursoDisciplina());

		if(matDisciplinas.size() > 0) {
			if(matDisciplinas.get(0).getMencao().equals("AP")){
				throw new InclusaoDisciplinaException("Disciplina já cursada com aprovação: " + 
						matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getSigla() + " - " +
						matDisciplinas.get(0).getOferta().getTurma() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplinaSubtitulo().getDisciplina().getSigla()
						);
			}
		}
		
		// verifica se estah se matriculando em subtitulo que ja foi optativa		
		matDisciplinas = matriculasDisciplinas.findByMatriculaAlunoAndOfertaCursoDisciplinaAndOfertaDataCancelamentoIsNullOrderByOfertaSemestreDesc(
			    alunoRegMatricula.getAlunoReg().getAluno(), 
			    alunoRegMatricula.getOferta().getCursoDisciplinaSubtitulo());
		
		if(matDisciplinas.size() > 0) {
			if(matDisciplinas.get(0).getMencao().equals("AP")){
				throw new InclusaoDisciplinaException("Disciplina já cursada com aprovação: " + 
						matDisciplinas.get(0).getOferta().getSemestre().getPeriodo() + " - " +
						matDisciplinas.get(0).getOferta().getCursoDisciplina().getDisciplina().getSigla() + " - " +
						matDisciplinas.get(0).getOferta().getTurma()
						);
			}
		}
		

		
		// verifica violacao de indice unico: (matricula, oferta)
		if(matriculasDisciplinas.findByMatriculaAndOferta(matricula.get(), alunoRegMatricula.getOferta()).isPresent()) {
			throw new InclusaoDisciplinaException("Disciplina '" +
												   alunoRegMatricula.getOferta().getCursoDisciplina().getDisciplina().getNome() +
												  "' já cadastrada no semestre " +
												  alunoRegMatricula.getOferta().getSemestre().getPeriodo());
		}
		
		// verifica se houve duas reprovacoes
		// ESSA SITUACAO devera ser tratada no lancamento da mencao
		// qdo houver dupla reprovacao, lanca data de DESLIGAMENTO (INSERIR CAMPO EM ALUNO REG)
		
		
		
		MatriculaDisciplina matriculaDisciplina = new MatriculaDisciplina(
					matricula.get(),
					alunoRegMatricula.getOferta(),
					(float) 0
				);   
		
		matriculasDisciplinas.save(matriculaDisciplina);
		
	}

	
	@Override
	@Transactional
	public void excluir(MatriculaDisciplina matriculaDisciplina) {
		try {
			matriculasDisciplinas.delete(matriculaDisciplina);
			matriculasDisciplinas.flush();
			
			if(matriculaDisciplina.getOferta().getCursoDisciplina().getDisciplina().getSigla().equals("TRANCA")) {
				matriculaDisciplina.getMatricula().getAlunoReg().setPrazoConclusao(matriculaDisciplina.getMatricula().getAlunoReg().getSemestre().getDia1().plusMonths( matriculaDisciplina.getOferta().getCursoDisciplina().getCurso().getPrazoConclusao() ).minusDays(1));
				matriculaDisciplina.getMatricula().setDataTrancamento(null);
				alunosReg.save(matriculaDisciplina.getMatricula().getAlunoReg());
			}
			
			// se nao existirem mais disciplinas no semestre corrente para o aluno, apaga o registro em matricula
			if(matriculasDisciplinas.findByMatriculaAlunoAndOfertaSemestre(matriculaDisciplina.getMatricula().getAluno(), matriculaDisciplina.getOferta().getSemestre()).size() == 0) {
				matriculas.delete(matriculaDisciplina.getMatricula());
				matriculas.flush();
			}
			
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Disciplina já foi associada a outra entidade.");
		}
	}
	
	
	@Override
	@Transactional
	public void salvarDataTrancamento(Matricula matricula) {

		if(matricula.getDataTrancamento() == null) {
			throw new DataTrancamentoException("Campo data de trancamento não pode ser nulo ou vazio.");
			
		} else if(matricula.getDataTrancamento().isAfter(LocalDate.now())) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			throw new DataTrancamentoException("Data de trancamento (" + matricula.getDataTrancamento().format(formatter) + ") não pode maior que a data de hoje (" + LocalDate.now().format(formatter) +").");
			
		} else {
			
			String periodo = matricula.getDataTrancamento().getYear() + "/";
			
			if(matricula.getDataTrancamento().getMonthValue() <= 6) {
				periodo = periodo + "1";
			} else {
				periodo = periodo + "2";
			}
			
			if(matricula.getSemestre().getPeriodo().equals(periodo)) {
				matriculas.save(matricula);	
			} else {
				throw new DataTrancamentoException("Data de trancamento deve ocorrer dentro do semestre a ser trancado.");	
			}
		}
	}
	
}
