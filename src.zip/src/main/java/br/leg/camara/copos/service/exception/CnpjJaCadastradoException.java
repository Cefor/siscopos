package br.leg.camara.copos.service.exception;

public class CnpjJaCadastradoException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public CnpjJaCadastradoException(String message) {
		super(message);
	}

}
