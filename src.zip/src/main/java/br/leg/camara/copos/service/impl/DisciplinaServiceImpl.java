package br.leg.camara.copos.service.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.Disciplina;
import br.leg.camara.copos.repository.Disciplinas;
import br.leg.camara.copos.repository.filter.DisciplinaFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.DisciplinaService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;

@Service
public class DisciplinaServiceImpl implements DisciplinaService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;
	
	@Autowired
	private Disciplinas disciplinas;

	
	
	@Override
	@Transactional
	public void salvar(Disciplina disciplina) {

		Optional<Disciplina> disciplinaAux;
		
		disciplinaAux = disciplinas.findByGrauCursoAndSiglaAndHoras(disciplina.getGrauCurso() , disciplina.getSigla(), disciplina.getHoras());
		
		if(disciplinaAux.isPresent() && disciplina.isNova()) {
			throw new DuplicidadeIndiceUnicoException("Sigla de disciplina já existente para o grau " + disciplina.getGrauCurso().getDescricao() + " com " + disciplina.getHoras() + " horas. Altere a sigla.");
		}
		
		disciplinaAux = disciplinas.findByGrauCursoAndNomeAndHoras(disciplina.getGrauCurso() , disciplina.getNome(), disciplina.getHoras());
		if(disciplinaAux.isPresent() && disciplina.isNova()) {
			throw new DuplicidadeIndiceUnicoException("Nome de disciplina já existente para o grau " + disciplina.getGrauCurso().getDescricao() + " com " + disciplina.getHoras() + " horas. Altere o nome.");
		}

		disciplinas.save(disciplina);
	}
	
	
	
	@Override
	@Transactional
	public void excluir(Disciplina disciplina) {
		try {
			disciplinas.delete(disciplina);
			disciplinas.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Disciplina já foi associada a outra entidade.");
		}
		
	}
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Disciplina> filtrar(DisciplinaFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Disciplina.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<Disciplina> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	private void adicionarFiltro(DisciplinaFilter filtro, Criteria criteria) {
		
		if (filtro != null) {
			
			if (!StringUtils.isEmpty(filtro.getSigla())) {
				criteria.add(Restrictions.ilike("sigla", filtro.getSigla(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getNome())) {
				criteria.add(Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getTipo())) {
				criteria.add(Restrictions.eq("tipo", filtro.getTipo()));
			}
			
			if (!StringUtils.isEmpty(filtro.getGrauCurso())) {
				criteria.add(Restrictions.eq("grauCurso", filtro.getGrauCurso()));
			}

		}
	}
	
	private Long total(DisciplinaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Disciplina.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação
	
}
