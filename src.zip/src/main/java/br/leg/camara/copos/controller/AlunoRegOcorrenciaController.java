package br.leg.camara.copos.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.controller.page.PageWrapper;
import br.leg.camara.copos.model.entity.AlunoReg;
import br.leg.camara.copos.model.entity.OcorrenciaReg;
import br.leg.camara.copos.repository.TiposOcorrenciasReg;
import br.leg.camara.copos.repository.filter.OcorrenciaRegFilter;
import br.leg.camara.copos.service.OcorrenciaRegService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.repository.AlunosReg;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.OcorrenciasReg;

@Controller
@RequestMapping("/ocorrenciareg")
public class AlunoRegOcorrenciaController {
	
	@Autowired
	private TiposOcorrenciasReg tiposOcorrenciasReg;

	@Autowired
	private AlunosReg alunosReg;
	
	@Autowired
	private OcorrenciasReg ocorrenciasReg;
	
	@Autowired
	private OcorrenciaRegService ocorrenciaRegService;
	
	@Autowired
	private Cursos cursos;

	
	
	@RequestMapping("/nova/{idAlunoReg}")
	public ModelAndView nova(OcorrenciaReg ocorrenciaReg, @PathVariable Long idAlunoReg) {
		
		ModelAndView mv = new ModelAndView("ocorrenciareg/CadastroOcorrenciaReg");
		
		AlunoReg alunoReg = alunosReg.getOne(idAlunoReg);
		ocorrenciaReg.setAlunoReg(alunoReg);
		
		mv.addObject("tiposOcorrenciasReg", tiposOcorrenciasReg.findAll(new Sort(Sort.Direction.ASC, "descricao")));
		
		return mv;
	}
	

	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid OcorrenciaReg ocorrenciaReg, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(ocorrenciaReg, ocorrenciaReg.getAlunoReg().getId());
		}

		try {
			ocorrenciaRegService.salvar(ocorrenciaReg);
		} catch (DuplicidadeIndiceUnicoException e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return nova(ocorrenciaReg, ocorrenciaReg.getAlunoReg().getId());
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return nova(ocorrenciaReg, ocorrenciaReg.getAlunoReg().getId());
		} 

		attributes.addFlashAttribute("mensagem", "Ocorrência salva com sucesso.");
		return new ModelAndView("redirect:/ocorrenciareg/nova/" + ocorrenciaReg.getAlunoReg().getId());
		
	}


	@GetMapping("/editar/{id}")
	public ModelAndView editar(OcorrenciaReg ocorrenciaReg, @PathVariable Long id) {
		
		ocorrenciaReg = ocorrenciasReg.findOne(id);
		
		ModelAndView mv = nova(ocorrenciaReg,  ocorrenciaReg.getAlunoReg().getId());
		
		mv.addObject(ocorrenciaReg);
		
		return mv;
	}


	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") OcorrenciaReg ocorrenciaReg) {
		try {
			ocorrenciaRegService.excluir(ocorrenciaReg);
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok().build();
	}
	
	
	@GetMapping("/pesquisaraluno/{idAlunoReg}")
	public ModelAndView pesquisar(@PathVariable Long idAlunoReg) {
		
		ModelAndView mv = new ModelAndView("ocorrenciareg/PesquisaOcorrenciaRegAluno");
		
		AlunoReg alunoReg = alunosReg.findOne(idAlunoReg);
		
		mv.addObject(alunoReg);
		mv.addObject("ocorrenciasReg", ocorrenciasReg.findByAlunoRegOrderByDataOcorrencia(alunoReg));
		
		return mv;
	}

	
	@GetMapping("/pesquisar")
	public ModelAndView pesquisar(OcorrenciaRegFilter ocorrenciaRegFilter, BindingResult result,
			@PageableDefault(size = 15) Pageable pageable, HttpServletRequest httpServletRequest) {
		
		ModelAndView mv = new ModelAndView("ocorrenciareg/PesquisaOcorrenciaReg");


		mv.addObject("cursos", cursos.findAllByOrderByGrauNivelDescNomeAscSiglaAsc());
		mv.addObject("tiposOcorrenciasReg", tiposOcorrenciasReg.findAllByOrderByDescricaoAsc());
		
	
		PageWrapper<OcorrenciaReg> paginaWrapper = new PageWrapper<>(ocorrenciaRegService.filtrar(ocorrenciaRegFilter, pageable),
				httpServletRequest);
		
		mv.addObject("pagina", paginaWrapper);
		return mv;
	}
}
