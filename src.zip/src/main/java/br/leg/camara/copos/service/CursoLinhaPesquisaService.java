package br.leg.camara.copos.service;

import br.leg.camara.copos.model.entity.CursoLinhaPesquisa;

public interface CursoLinhaPesquisaService {

	void salvar(CursoLinhaPesquisa cursoLinhaPesquisa);

	void excluir(CursoLinhaPesquisa cursoLinhaPesquisa);
	

}
