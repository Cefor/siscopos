package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "curso")
public class Curso {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	

	@Column(name = "sigla", length = 10)
	@NotBlank(message = "Sigla obrigatória")
	private String sigla;
	
	@Column(name = "nome", length = 100)
	@NotBlank(message = "Nome obrigatório")
	private String nome;
	
	@Column(name = "codigo", length = 50)
	@NotBlank(message = "Código obrigatório")
	private String codigo;
	
	@Column(name = "area", length = 100)
	@NotBlank(message = "Área obrigatória")
	private String area;
		
	@NotNull(message = "Grau do curso é obrigatório")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_grau_curso")
	private GrauCurso grau;

	@NotNull(message = "Nota mínima para aprovação obrigatória")
	@Max(value = 10, message = "O valor máximo permitido para a nota é 10")
	@Column(name = "nota_minima")
	private Float notaMinima;
	
	@NotNull(message = "Frequência mínima para aprovação obrigatória")
	@Max(value = 100, message = "O valor máximo permitido para a frequência é 100%")
	@Column(name = "frequencia_minima")
	private Float frequenciaMinima;
	
	@NotNull(message = "Limite de optativas como aluno especial obrigatório")
	@Column(name = "limite_optativas_especial")
	private Integer limiteOptativasEspecial;
	
	@NotNull(message = "Limite de optativas por semestre como aluno especial obrigatório")
	@Column(name = "limite_optativas_especial_semestre")
	private Integer limiteOptativasEspecialSemestre;
	
	@NotNull(message = "Carga horária obrigatória")
	@Column(name = "carga_horaria")
	private Integer cargaHoraria;
	
	@NotNull(message = "Informe o prazo de conclusão em meses")
	@Column(name = "prazo_conclusao")
	private Integer prazoConclusao;
	
	@NotNull(message = "Data de início obrigatória")
	@Column(name = "data_inicio")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataInicio;
		
	@Column(name = "data_fim")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataFim;
	
	@Column(name = "normativo", length = 255)
	@NotBlank(message = "Normativo obrigatório")
	private String normativo;

	
	public boolean isNovo() {
		return id == null;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getSigla() {
		return sigla;
	}


	public void setSigla(String sigla) {
		this.sigla = sigla;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCodigo() {
		return codigo;
	}


	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}


	public String getArea() {
		return area;
	}


	public void setArea(String area) {
		this.area = area;
	}


	public GrauCurso getGrau() {
		return grau;
	}


	public void setGrau(GrauCurso grau) {
		this.grau = grau;
	}


	public Float getNotaMinima() {
		return notaMinima;
	}


	public void setNotaMinima(Float notaMinima) {
		this.notaMinima = notaMinima;
	}


	public Float getFrequenciaMinima() {
		return frequenciaMinima;
	}


	public void setFrequenciaMinima(Float frequenciaMinima) {
		this.frequenciaMinima = frequenciaMinima;
	}


	public Integer getLimiteOptativasEspecial() {
		return limiteOptativasEspecial;
	}


	public void setLimiteOptativasEspecial(Integer limiteOptativasEspecial) {
		this.limiteOptativasEspecial = limiteOptativasEspecial;
	}


	public Integer getLimiteOptativasEspecialSemestre() {
		return limiteOptativasEspecialSemestre;
	}


	public void setLimiteOptativasEspecialSemestre(Integer limiteOptativasEspecialSemestre) {
		this.limiteOptativasEspecialSemestre = limiteOptativasEspecialSemestre;
	}


	public Integer getCargaHoraria() {
		return cargaHoraria;
	}


	public void setCargaHoraria(Integer cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}


	public Integer getPrazoConclusao() {
		return prazoConclusao;
	}


	public void setPrazoConclusao(Integer prazoConclusao) {
		this.prazoConclusao = prazoConclusao;
	}


	public LocalDate getDataInicio() {
		return dataInicio;
	}


	public void setDataInicio(LocalDate dataInicio) {
		this.dataInicio = dataInicio;
	}


	public LocalDate getDataFim() {
		return dataFim;
	}


	public void setDataFim(LocalDate dataFim) {
		this.dataFim = dataFim;
	}


	public String getNormativo() {
		return normativo;
	}


	public void setNormativo(String normativo) {
		this.normativo = normativo;
	}


	@Override
	public String toString() {
		return "Curso [id=" + id + ", sigla=" + sigla + ", nome=" + nome + ", codigo=" + codigo + ", area=" + area
				+ ", grau=" + grau + ", notaMinima=" + notaMinima + ", frequenciaMinima=" + frequenciaMinima
				+ ", limiteOptativasEspecial=" + limiteOptativasEspecial + ", limiteOptativasEspecialSemestre="
				+ limiteOptativasEspecialSemestre + ", cargaHoraria=" + cargaHoraria + ", prazoConclusao="
				+ prazoConclusao + ", dataInicio=" + dataInicio + ", dataFim=" + dataFim + ", normativo=" + normativo
				+ "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(area, cargaHoraria, codigo, dataFim, dataInicio, frequenciaMinima, grau, id,
				limiteOptativasEspecial, limiteOptativasEspecialSemestre, nome, normativo, notaMinima, prazoConclusao,
				sigla);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Curso other = (Curso) obj;
		return Objects.equals(area, other.area) && Objects.equals(cargaHoraria, other.cargaHoraria)
				&& Objects.equals(codigo, other.codigo) && Objects.equals(dataFim, other.dataFim)
				&& Objects.equals(dataInicio, other.dataInicio)
				&& Objects.equals(frequenciaMinima, other.frequenciaMinima) && Objects.equals(grau, other.grau)
				&& Objects.equals(id, other.id)
				&& Objects.equals(limiteOptativasEspecial, other.limiteOptativasEspecial)
				&& Objects.equals(limiteOptativasEspecialSemestre, other.limiteOptativasEspecialSemestre)
				&& Objects.equals(nome, other.nome) && Objects.equals(normativo, other.normativo)
				&& Objects.equals(notaMinima, other.notaMinima) && Objects.equals(prazoConclusao, other.prazoConclusao)
				&& Objects.equals(sigla, other.sigla);
	}


}
