package br.leg.camara.copos.model.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "situacaoprofessor")
public class SituacaoProfessor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "situacao", length = 30)
	@NotBlank(message = "Situação obrigatória")
	private String situacao;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	@Override
	public String toString() {
		return "SituacaoProfessor [id=" + id + ", situacao=" + situacao + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, situacao);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SituacaoProfessor other = (SituacaoProfessor) obj;
		return Objects.equals(id, other.id) && Objects.equals(situacao, other.situacao);
	}


	
}
