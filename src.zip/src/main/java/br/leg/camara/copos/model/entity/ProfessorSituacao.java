package br.leg.camara.copos.model.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@Entity
@Table(name = "professor_situacao")
public class ProfessorSituacao {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "Obrigatório informar professor")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_professor")
	private Professor professor;
	
	@NotNull(message = "Obrigatório informar situação do professor")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_situacaoprofessor")
	private SituacaoProfessor situacaoProfessor;
	
	@NotNull(message = "Obrigatório informar linha de pesquisa")
	@OneToOne(optional = false, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_curso_linhapesquisa")
	private CursoLinhaPesquisa cursoLinhaPesquisa;

	@NotNull(message = "Data de início é obrigatória")
	@Column(name = "data_inicio")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataInicio;

	@Column(name = "data_fim")
	@Convert(converter = Jsr310JpaConverters.LocalDateConverter.class)
	private LocalDate dataFim;
	
	@Column(name = "observacao")
	private String observacao;

	public boolean isNova() {
		return id == null;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public SituacaoProfessor getSituacaoProfessor() {
		return situacaoProfessor;
	}

	public void setSituacaoProfessor(SituacaoProfessor situacaoProfessor) {
		this.situacaoProfessor = situacaoProfessor;
	}

	public CursoLinhaPesquisa getCursoLinhaPesquisa() {
		return cursoLinhaPesquisa;
	}

	public void setCursoLinhaPesquisa(CursoLinhaPesquisa cursoLinhaPesquisa) {
		this.cursoLinhaPesquisa = cursoLinhaPesquisa;
	}

	public LocalDate getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(LocalDate dataInicio) {
		this.dataInicio = dataInicio;
	}

	public LocalDate getDataFim() {
		return dataFim;
	}

	public void setDataFim(LocalDate dataFim) {
		this.dataFim = dataFim;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	@Override
	public String toString() {
		return "ProfessorSituacao [id=" + id + ", professor=" + professor + ", situacaoProfessor=" + situacaoProfessor
				+ ", cursoLinhaPesquisa=" + cursoLinhaPesquisa + ", dataInicio=" + dataInicio + ", dataFim=" + dataFim
				+ ", observacao=" + observacao + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cursoLinhaPesquisa, dataFim, dataInicio, id, observacao, professor, situacaoProfessor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfessorSituacao other = (ProfessorSituacao) obj;
		return Objects.equals(cursoLinhaPesquisa, other.cursoLinhaPesquisa) && Objects.equals(dataFim, other.dataFim)
				&& Objects.equals(dataInicio, other.dataInicio) && Objects.equals(id, other.id)
				&& Objects.equals(observacao, other.observacao) && Objects.equals(professor, other.professor)
				&& Objects.equals(situacaoProfessor, other.situacaoProfessor);
	}

	
	

}
