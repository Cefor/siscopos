package br.leg.camara.copos.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.bridge.AlunoEspNovo;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.Matricula;
import br.leg.camara.copos.repository.filter.AlunoEspFilter;

public interface AlunoEspService {
	
	Page<AlunoEsp> filtrar(AlunoEspFilter filtro, Pageable pageable);

	void salvar(AlunoEspNovo alunoEspNovo);

	void salvarEdicao(AlunoEsp alunoEsp);

	void excluir(AlunoEsp alunoEsp);

	Page<Matricula> filtrarMatriculaSemestre(AlunoEspFilter filtro, Pageable pageable);

	List<Matricula> filtrarTodos(AlunoEspFilter filtro);

}
