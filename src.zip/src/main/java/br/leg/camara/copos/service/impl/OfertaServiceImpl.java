package br.leg.camara.copos.service.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.Oferta;
import br.leg.camara.copos.repository.Ofertas;
import br.leg.camara.copos.repository.filter.OfertaFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.OfertaService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.IncompatibilidadeCargaHorariaException;

@Service
public class OfertaServiceImpl implements OfertaService{
	
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private PaginacaoUtil paginacaoUtil;

	@Autowired
	private Ofertas ofertas;

	
	@Override
	@Transactional
	public void salvar(Oferta oferta) {
		
		Optional<Oferta> ofertaExistente = ofertas.findByCursoDisciplinaAndSemestreAndTurma(
		        oferta.getCursoDisciplina(), oferta.getSemestre(),
		        oferta.getTurma());
		
		// se ja existir e oferta for nova, vai dar duplicidade
		if(ofertaExistente.isPresent() && oferta.isNova()) {
			throw new DuplicidadeIndiceUnicoException("Oferta já existente para o semestre");	
		} 
		
		// carga horaria de APROVE deve ser menor ou igual ah carga horaria de subtitulo
		if(oferta.getCursoDisciplina().getDisciplina().getSigla().equals("APROVE")) {
			if(oferta.getCursoDisciplina().getDisciplina().getHoras() > oferta.getCursoDisciplinaSubtitulo().getDisciplina().getHoras()) {
				throw new IncompatibilidadeCargaHorariaException(
						"Subtítulo '" + 
						oferta.getCursoDisciplinaSubtitulo().getDisciplina().getNome() + 
						" (" + oferta.getCursoDisciplinaSubtitulo().getDisciplina().getHoras() + "h)' " +
						"tem carga horária menor que '" + 
						oferta.getCursoDisciplina().getDisciplina().getNome() + 
						" (" + oferta.getCursoDisciplina().getDisciplina().getHoras() + "h)'"
						);
			}
		}
		
		// se for APROVEitamemto, ao checar a duplicidade, incluir na chave o atributo cursoDisciplinaSubtitulo
		// ja passou pelo crivo da turma, ou seja, sao turmas diferentes
		if(oferta.getCursoDisciplina().getDisciplina().getSigla().equals("APROVE")) {

			Optional<Oferta> ofertaExistente2 = ofertas.findByCursoDisciplinaAndSemestreAndCursoDisciplinaSubtitulo(
			        oferta.getCursoDisciplina(), oferta.getSemestre(),
			        oferta.getCursoDisciplinaSubtitulo());
			
			// se ja existir e oferta for nova, vai dar duplicidade
			if(ofertaExistente2.isPresent()) {
				throw new DuplicidadeIndiceUnicoException("Oferta já existente para o semestre");	
			} 
		}
		
		ofertas.save(oferta);
		
		/*
		// edicao
		if(ofertaExistente.isPresent() && !oferta.isNova()) { // edicao
				
		}
				
		// se nao existe e oferta eh nova
		if(!ofertaExistente.isPresent() && oferta.isNova()) { // inclusao
		
		}
		
		// se nao existe e oferta eh nova
		if(!ofertaExistente.isPresent() && !oferta.isNova()) { // impossivel
		
		}
		*/
		
		
	}
	
	
	@Override
	@Transactional
	public void excluir(Oferta oferta) {
		try {
			ofertas.delete(oferta);
			ofertas.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Oferta já foi associada a outra entidade.");
		}
	}
	
	
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<Oferta> filtrar(OfertaFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Oferta.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<Oferta> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	private void adicionarFiltro(OfertaFilter filtro, Criteria criteria) {
		
		Criteria cursoDisciplinaCrit  = criteria.createCriteria("cursoDisciplina");
		Criteria cursoCrit  = cursoDisciplinaCrit.createCriteria("curso");
		Criteria disciplinaCrit  = cursoDisciplinaCrit.createCriteria("disciplina");
		
		cursoCrit.addOrder(Order.asc("sigla"));
		criteria.addOrder(Order.desc("semestre"));
		disciplinaCrit.addOrder(Order.asc("tipo"));
		disciplinaCrit.addOrder(Order.asc("sigla"));
		criteria.addOrder(Order.asc("turma"));
		
		if (filtro != null) {
	
			if (!StringUtils.isEmpty(filtro.getCurso())) {
				cursoDisciplinaCrit.add(Restrictions.eq("curso", filtro.getCurso()));
			}

			if (!StringUtils.isEmpty(filtro.getSemestre())) {
				criteria.add(Restrictions.eq("semestre", filtro.getSemestre()));
			}
			
			if (!StringUtils.isEmpty(filtro.getDisciplinaSigla())) {
				disciplinaCrit.add(Restrictions.ilike("sigla", filtro.getDisciplinaSigla(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getTipo())) {
				disciplinaCrit.add(Restrictions.eq("tipo", filtro.getTipo()));
			}
		}
	}
	
	private Long total(OfertaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(Oferta.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação

}
