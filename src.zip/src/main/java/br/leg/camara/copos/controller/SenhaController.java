package br.leg.camara.copos.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.model.entity.Usuario;
import br.leg.camara.copos.repository.Grupos;
import br.leg.camara.copos.repository.Usuarios;
import br.leg.camara.copos.service.UsuarioService;

@Controller
@RequestMapping("/trocarsenha")
public class SenhaController {

	
    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
	private Usuarios usuarios;
    
    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
	private Grupos grupos;
    
    @RequestMapping("/preparacao")
	public ModelAndView preparacao(Usuario usuario) {
		ModelAndView mv = new ModelAndView("senha/TrocarSenha");
		mv.addObject("grupos", grupos.findAll());
		return mv;
	}

    
    @GetMapping("/{codigo}")
    public ModelAndView trocarSenha(@PathVariable Long codigo) {
    	Usuario usuario = usuarios.findOne(codigo);
    	ModelAndView mv = preparacao(usuario);
    	mv.addObject(usuario);
        return mv;
    }
	

    @PostMapping("/salvar")
    public ModelAndView salvar(@Valid Usuario usuario,
					    		BindingResult result, 
					    		@RequestParam("senhaAtual") String senhaAtual,
					    		RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return preparacao(usuario);
		}
		
		if(usuario.getSenha().isEmpty()) {
			result.rejectValue("senha", "Obrigatório informar a senha.", "Obrigatório informar a senha.");
            return preparacao(usuario);
		}
		
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	    String username;
	    if (principal instanceof UserDetails) {
	    	username = ((UserDetails)principal).getUsername();
	    } else {
	        username = principal.toString();
	    }
	
	    UserDetails user = userDetailsService.loadUserByUsername(username);
		
		if (!passwordEncoder.matches(senhaAtual, user.getPassword())) {
			result.rejectValue(null, "Senha atual incorreta.", "Senha atual incorreta.");
            return preparacao(usuario);
        }
		
		try {
			usuarioService.salvar(usuario);
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return preparacao(usuario);
		}
		
		attributes.addFlashAttribute("mensagem", "Senha trocada com sucesso.");
		return new ModelAndView("redirect:/trocarsenha/preparacao");
    }

	
	
}
