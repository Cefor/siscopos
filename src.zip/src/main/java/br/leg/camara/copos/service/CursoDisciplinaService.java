package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.entity.CursoDisciplina;
import br.leg.camara.copos.repository.filter.CursoDisciplinaFilter;

public interface CursoDisciplinaService {

	Page<CursoDisciplina> filtrar(CursoDisciplinaFilter filtro, Pageable pageable);

	void salvar(CursoDisciplina cursoDisciplina);

	void excluir(CursoDisciplina cursoDisciplina);
	

}
