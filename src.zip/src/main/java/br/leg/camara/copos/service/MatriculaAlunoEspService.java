package br.leg.camara.copos.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.leg.camara.copos.model.bridge.AlunoEspMatricula;
import br.leg.camara.copos.model.entity.AlunoEsp;
import br.leg.camara.copos.model.entity.MatriculaDisciplina;
import br.leg.camara.copos.repository.filter.AlunoEspFilter;

public interface MatriculaAlunoEspService {

	void salvar(AlunoEspMatricula alunoEspMatricula);

	void excluir(MatriculaDisciplina matriculaDisciplina);

	Page<AlunoEsp> filtrar(AlunoEspFilter filtro, Pageable pageable);

}
