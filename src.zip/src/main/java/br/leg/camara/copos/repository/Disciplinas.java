package br.leg.camara.copos.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.leg.camara.copos.model.entity.Disciplina;
import br.leg.camara.copos.model.entity.GrauCurso;

public interface Disciplinas extends JpaRepository<Disciplina, Long> {
	
	public Optional<Disciplina> findByGrauCursoAndSiglaAndHoras(GrauCurso grauCurso, String sigla, int horas);
	
	public Optional<Disciplina> findByGrauCursoAndNomeAndHoras(GrauCurso grauCurso, String nome, int horas);
	
	public List<Disciplina> findByGrauCursoNivelGreaterThanEqualOrderByNomeAsc(int nivel);
	
}
