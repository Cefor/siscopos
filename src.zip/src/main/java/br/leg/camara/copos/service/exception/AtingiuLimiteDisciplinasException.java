package br.leg.camara.copos.service.exception;

public class AtingiuLimiteDisciplinasException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public AtingiuLimiteDisciplinasException(String message) {
		super(message);
	}

}
