package br.leg.camara.copos.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.leg.camara.copos.model.entity.CursoLinhaPesquisa;
import br.leg.camara.copos.repository.Cursos;
import br.leg.camara.copos.repository.CursosLinhasPesquisa;
import br.leg.camara.copos.repository.LinhasPesquisa;
import br.leg.camara.copos.service.CursoLinhaPesquisaService;

@Controller
@RequestMapping("/cursolinhapesquisa")
public class CursoLinhaPesquisaController {


	@Autowired
	private CursosLinhasPesquisa cursosLinhasPesquisa;	

	@Autowired
	private Cursos cursos;
	
	@Autowired
	private LinhasPesquisa linhasPesquisa;
	
	@Autowired
	private CursoLinhaPesquisaService cursoLinhaPesquisaService;	
	
	
	@RequestMapping("/nova/{idCurso}")
	public ModelAndView nova(CursoLinhaPesquisa cursoLinhaPesquisa, @PathVariable Long idCurso) {
		ModelAndView mv = new ModelAndView("cursolinhapesquisa/CursoLinhaPesquisa");
		
		cursoLinhaPesquisa.setCurso(cursos.getOne(idCurso));
		
		mv.addObject("linhasPesquisa", linhasPesquisa.findAll());
		mv.addObject("cursoLinhasPesquisa", cursosLinhasPesquisa.findByCurso(cursoLinhaPesquisa.getCurso()));
		
		return mv;
	}

	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid CursoLinhaPesquisa cursoLinhaPesquisa, BindingResult result, RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return nova(cursoLinhaPesquisa, cursoLinhaPesquisa.getCurso().getId());
		}
		
		try {
			cursoLinhaPesquisaService.salvar(cursoLinhaPesquisa);
		} catch (Exception e) {
			result.rejectValue(null, e.getMessage(), e.getMessage());
			return nova(cursoLinhaPesquisa, cursoLinhaPesquisa.getCurso().getId());
		}
		
		attributes.addFlashAttribute("mensagem", "Linha de pesquisa salva com sucesso!");
		return new ModelAndView("redirect:/cursolinhapesquisa/nova/" + cursoLinhaPesquisa.getCurso().getId());
	}
	
	
	@DeleteMapping("/excluir/{id}")
	public @ResponseBody ResponseEntity<?> excluir(@PathVariable("id") CursoLinhaPesquisa cursoLinhaPesquisa){

		try {
			cursoLinhaPesquisaService.excluir(cursoLinhaPesquisa);
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}

		return ResponseEntity.ok().build();
		
	}

	
}
