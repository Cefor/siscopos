package br.leg.camara.copos.service.exception;

public class SemestreJaCadastradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public SemestreJaCadastradoException(String message) {
		super(message);
	}

}
