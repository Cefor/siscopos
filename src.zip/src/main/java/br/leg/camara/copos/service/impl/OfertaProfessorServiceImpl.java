package br.leg.camara.copos.service.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.leg.camara.copos.model.entity.OfertaProfessor;
import br.leg.camara.copos.repository.OfertasProfessores;
import br.leg.camara.copos.repository.filter.OfertaFilter;
import br.leg.camara.copos.repository.paginacao.PaginacaoUtil;
import br.leg.camara.copos.service.OfertaProfessorService;
import br.leg.camara.copos.service.exception.DuplicidadeIndiceUnicoException;
import br.leg.camara.copos.service.exception.ExclusaoRegistroJaAssociadoException;
import br.leg.camara.copos.service.exception.IncompatibilidadeCargaHorariaException;

@Service
public class OfertaProfessorServiceImpl implements OfertaProfessorService{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private PaginacaoUtil paginacaoUtil;

	@Autowired
	private OfertasProfessores ofertasProfessores;
	

	
	@Override
	@Transactional
	public void salvar(OfertaProfessor ofertaProfessor) {

		if(ofertasProfessores.findByOfertaAndProfessor(ofertaProfessor.getOferta(), ofertaProfessor.getProfessor()).isPresent() &&
				ofertaProfessor.isNova()) {
			throw new DuplicidadeIndiceUnicoException("Professor já associado à oferta.");
		}
		
		if(ofertaProfessor.getCargahoraria() != null &&
				ofertaProfessor.getCargahoraria() >
		   			ofertaProfessor.getOferta().getCursoDisciplina().getDisciplina().getHoras()) {
			throw new IncompatibilidadeCargaHorariaException("Carga horária do professor ("+
					                                          ofertaProfessor.getCargahoraria() +
					                                          "h) não pode ser maior que a carga horária da disciplina (" +
					                                          ofertaProfessor.getOferta().getCursoDisciplina().getDisciplina().getHoras() +
					                                          "h).");
		}
		
		ofertasProfessores.save(ofertaProfessor);
	}
	
	
	@Override
	@Transactional
	public void excluir(OfertaProfessor ofertaProfessor) {
		try {
			ofertasProfessores.delete(ofertaProfessor);
			ofertasProfessores.flush();
		} catch (DataIntegrityViolationException e) {
			throw new ExclusaoRegistroJaAssociadoException("Impossível excluir. Oferta já foi associada a outra entidade.");
		}
	}
	
	
	
	// Filtrar e paginação
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	@Override
	public Page<OfertaProfessor> filtrar(OfertaFilter filtro, Pageable pageable) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(OfertaProfessor.class);

		paginacaoUtil.preparar(criteria, pageable);
		adicionarFiltro(filtro, criteria);
		
		List<OfertaProfessor> filtrados = criteria.list();
		
		return new PageImpl<>(filtrados, pageable, total(filtro));
	}
	
	private void adicionarFiltro(OfertaFilter filtro, Criteria criteria) {

		Criteria ofertaCrit  = criteria.createCriteria("oferta");
		Criteria cursoDisciplinaCrit  = ofertaCrit.createCriteria("cursoDisciplina");
		Criteria cursoCrit  = cursoDisciplinaCrit.createCriteria("curso");
		Criteria disciplinaCrit  = cursoDisciplinaCrit.createCriteria("disciplina");

		Criteria professorCrit  = criteria.createCriteria("professor");
		Criteria pessoaCrit  = professorCrit.createCriteria("pessoa");
		
		cursoCrit.addOrder(Order.asc("sigla"));
		ofertaCrit.addOrder(Order.desc("semestre"));
		disciplinaCrit.addOrder(Order.asc("sigla"));
		pessoaCrit.addOrder(Order.asc("nome"));
		
		if (filtro != null) {
	
			if (!StringUtils.isEmpty(filtro.getCurso())) {
				cursoDisciplinaCrit.add(Restrictions.eq("curso", filtro.getCurso()));
			}

			if (!StringUtils.isEmpty(filtro.getSemestre())) {
				ofertaCrit.add(Restrictions.eq("semestre", filtro.getSemestre()));
			}
			
			if (!StringUtils.isEmpty(filtro.getDisciplinaSigla())) {
				disciplinaCrit.add(Restrictions.ilike("sigla", filtro.getDisciplinaSigla(), MatchMode.ANYWHERE));
			}
			
			if (!StringUtils.isEmpty(filtro.getProfessor())) {
				pessoaCrit.add(Restrictions.ilike("nome", filtro.getProfessor(), MatchMode.ANYWHERE));
			}
		}
		
	}
	
	private Long total(OfertaFilter filtro) {
		Criteria criteria = manager.unwrap(Session.class).createCriteria(OfertaProfessor.class);
		adicionarFiltro(filtro, criteria);
		criteria.setProjection(Projections.rowCount());
		return (Long) criteria.uniqueResult();
	}
	// Filtrar e paginação
	
	
	
	
	
	
}
