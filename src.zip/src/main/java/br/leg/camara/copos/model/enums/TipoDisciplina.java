package br.leg.camara.copos.model.enums;

public enum TipoDisciplina {

	DISC("Disciplina"),
	CCCM("Componente curricular com menção"),
	CCSM("Componente curricular sem menção");

	private String descricao;
	
	TipoDisciplina(String descricao) {
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return descricao;
	}

}

