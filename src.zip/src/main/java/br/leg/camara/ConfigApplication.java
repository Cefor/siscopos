package br.leg.camara;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.format.datetime.standard.DateTimeFormatterRegistrar;
import org.springframework.format.number.NumberStyleFormatter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import br.leg.camara.copos.controller.converter.CidadeConverter;
import br.leg.camara.copos.controller.converter.EstadoConverter;
import br.leg.camara.copos.controller.converter.GrupoConverter;
import br.leg.camara.copos.thymeleaf.CoposDialect;

@Configuration
@EnableCaching
public class ConfigApplication extends WebMvcConfigurerAdapter {

	@Override
	public void addFormatters(FormatterRegistry registry) {
		
		registry.addConverter( cidadeConverter() );
		registry.addConverter( estadoConverter() );
		registry.addConverter( grupoConverter() );

		NumberStyleFormatter bigDecimalFormatter = new NumberStyleFormatter("#,##0.00");
		registry.addFormatterForFieldType(BigDecimal.class, bigDecimalFormatter);

		NumberStyleFormatter integerFormatter = new NumberStyleFormatter("#,##0");
		registry.addFormatterForFieldType(Integer.class, integerFormatter);
		
		DateTimeFormatterRegistrar dateTimeFormatter = new DateTimeFormatterRegistrar();
		dateTimeFormatter.setDateFormatter(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		dateTimeFormatter.setTimeFormatter(DateTimeFormatter.ofPattern("HH:mm"));
		dateTimeFormatter.registerFormatters(registry);
		
		super.addFormatters(registry);
	}

	@Bean
	public CoposDialect coposDialect() {
	    return new CoposDialect();
	}
	
	// Início conversores
    @Bean
    public CidadeConverter cidadeConverter(){
    	return new CidadeConverter();
    }
    
    @Bean
    public EstadoConverter estadoConverter(){
    	return new EstadoConverter();
    }
    
    @Bean
    public GrupoConverter grupoConverter(){
    	return new GrupoConverter();
    }
	// Fim conversores    
}
